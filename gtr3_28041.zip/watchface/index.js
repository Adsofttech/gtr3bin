﻿
    /*
    ** huamiOS bundle tool v1.0.17
    * *huamiOS watchface js version v1.0.1
    * *Copyright © Huami. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start
        let normal$_$background$_$bg = ''
        let normal$_$weather$_$image_progress$_$img_level = ''
        let normal$_$temperature$_$current$_$text_img = ''
        let normal$_$temperature$_$high$_$text_img = ''
        let normal$_$temperature$_$low$_$text_img = ''
        let normal$_$digital_clock$_$img_time = ''
        let normal$_$week$_$week = ''
        let normal$_$date$_$img_date = ''
        let normal$_$battery$_$text$_$text_img = ''
        let normal$_$battery$_$image_progress$_$img_level = ''
        let normal$_$step$_$current$_$text_img = ''
        let normal$_$step$_$image_progress$_$img_level = ''
        let normal$_$SPO2$_$text$_$text_img = ''
        let normal$_$SLEEP$_$text$_$text_img = ''
        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$component_0$_$component = ''
        let normal$_$aqi$_$text$_$component_0$_$text_img = ''
        let normal$_$aqi$_$icon$_$component_0$_$img = ''
        let normal$_$humidity$_$text$_$component_0$_$text_img = ''
        let normal$_$humidity$_$icon$_$component_0$_$img = ''
        let normal$_$uvi$_$text$_$component_0$_$text_img = ''
        let normal$_$uvi$_$icon$_$component_0$_$img = ''
        let normal$_$component_1$_$component = ''
        let normal$_$FAT_BURN$_$text$_$component_1$_$text_img = ''
        let normal$_$FAT_BURN$_$icon$_$component_1$_$img = ''
        let normal$_$STAND$_$text$_$component_1$_$text_img = ''
        let normal$_$STAND$_$icon$_$component_1$_$img = ''
        let normal$_$component_2$_$component = ''
        let normal$_$heart_rate$_$text$_$component_2$_$text_img = ''
        let normal$_$heart_rate$_$icon$_$component_2$_$img = ''
        let normal$_$heart_rate$_$image_progress$_$component_2$_$img_level = ''
        let normal$_$calorie$_$current$_$component_2$_$text_img = ''
        let normal$_$calorie$_$icon$_$component_2$_$img = ''
        let normal$_$calorie$_$image_progress$_$component_2$_$img_level = ''
        let normal$_$pai$_$weekly$_$component_2$_$text_img = ''
        let normal$_$pai$_$icon$_$component_2$_$img = ''
        let normal$_$pai$_$image_progress$_$component_2$_$img_level = ''
        let normal$_$distance$_$text$_$component_2$_$text_img = ''
        let normal$_$distance$_$icon$_$component_2$_$img = ''
        let normal$_$component$_$cover = ''
        let normal$_$component$_$mask = ''
		let dateText = null;
        //dynamic modify end
    
       let nongli = null;

    let zodiacs = ['鼠', '牛', '虎', '兔', '龙', '蛇', '马', '羊', '猴', '鸡', '狗', '猪']
    let Gan = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
    let Zhi = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
    let weekday = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日']

    let now = null
    let countDownTimer = null
    //用于计算农历年月日的数据
    let GY = 0
    let GM = 0
    let GD = 0

    let year = 0
    let month = 0
    let date = 0
    let hours = 0
    let minutes = 0
    let seconds = 0

    const calendar = {
      gregorianYear: null,          //公历年
      gregorianMonth: null,         //公历月
      gregorianDay: null,           //公历日
      weekday: null,                //星期
      hours: null,
      minutes: null,
      seconds: null,

      lunarYear: null,              //农历年
      lunarMonth: null,             //农历月
      lunarDay: null,               //农历日

      lunarYearCn: '',              //农历天干地支纪年
      lunarMonthCn: '',             //农历中文月
      lunarDayCn: '',               //农历中文日
      zodiacYear: '',               //农历生肖年

      solarTerm: '',                //节气
      gregorianFestival: '',        //公历节日
      lunarFestival: ''             //农历节日
    }

    let lunarInfo = [
      0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,
      0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,
      0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,
      0x06566, 0x0d4a0, 0x0ea50, 0x06e95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,
      0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,
      0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5d0, 0x14573, 0x052d0, 0x0a9a8, 0x0e950, 0x06aa0,
      0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,
      0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b5a0, 0x195a6,
      0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,
      0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x055c0, 0x0ab60, 0x096d5, 0x092e0,
      0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,
      0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,
      0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,
      0x05aa0, 0x076a3, 0x096d0, 0x04bd7, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,
      0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0]

    /**
             * 阳历节日
             */
    let festival = {
      '1-1': { title: '元旦' },
      '2-2': { title: '世界湿地日' },
      '2-14': { title: '情人节' },
      '3-8': { title: '妇女节' },
      '3-12': { title: '植树节' },
      '3-15': { title: '消权日' },
      '4-1': { title: '愚人节' },
      '4-22': { title: '地球日' },
      '5-1': { title: '劳动节' },
      '5-16': { title: '教师节' },
      '6-1': { title: '国际儿童节' },
      '8-31': { title: '国庆日' },
      '9-16': { title: '马来西亚日' },
      '10-31': { title: '万圣前夜' },
      '11-1': { title: '万圣节' },
      '12-24': { title: '平安夜' },
      '12-25': { title: '圣诞节' }
    }

    /**
    * 农历节日
    */
    let lfestival = {
      //'12-30': { title: '除夕' },
      '1-1': { title: '春节' },
      '1-15': { title: '元宵节' },
      '2-2': { title: '龙抬头' },
      '5-5': { title: '端午节' },
      '7-7': { title: '七夕节' },
      '7-15': { title: '中元节' },
      '8-15': { title: '中秋节' },
      '9-9': { title: '重阳节' },
      '12-8': { title: '腊八节' },
      '12-23': { title: '北方小年' },
      '12-24': { title: '南方小年' },
      '2-19': { title: '观音诞' },
      '6-19': { title: '观音诞' },
      '9-19': { title: '观音诞' }
    }

    //母亲节和父亲节、感恩节
    function getMotherOrFatherDay(year, month, day) {
      if (month != 5 && month != 6 && month != 11) return null;
      if ((month == 5 && (day < 8 || day > 14)) || (month == 6 && (day < 15 || day > 21)) || (month == 11 && (day < 22 || day > 28))) return null;
      var d = new Date(year, month - 1, 1, 1, 1, 1, 0)
      var weekDate = (d.getDay() == 0 ? 7 : d.getDay()) - 1;

      switch (month) {
        case 5:
          weekDate = 7 - weekDate;
          if (day == 7 + weekDate) {
            return "母亲节";
          }
          break;
        case 6:
          weekDate = 7 - weekDate;
          if (day == 14 + weekDate) {
            return "父亲节";
          }
          break;
        case 11:
          weekDate = weekDate >= 4 ? (11 - weekDate) : (4 - weekDate)
          if (day == 21 + weekDate) {
            return "感恩节"
          }
          break;
      }
      return null;
    }

    //==== 传入 offset 传回干支, 0=甲子
    function cyclical(num) {
      return (Gan[num % 10] + Zhi[num % 12])
    }

    //==== 传回农历 year年的总天数
    function lYearDays(year) {
      let i, sum = 348
      for (i = 0x8000; i > 0x8; i >>= 1) {
        sum += (lunarInfo[year - 1900] & i) ? 1 : 0
      }
      return (sum + leapDays(year))
    }

    //==== 传回农历 year年闰月的天数
    function leapDays(year) {
      if (leapMonth(year)) {
        return ((lunarInfo[year - 1900] & 0x10000) ? 30 : 29)
      }
      else {
        return 0
      }
    }

    //==== 传回农历 year年闰哪个月 1-12 , 没闰传回 0
    function leapMonth(year) {
      return (lunarInfo[year - 1900] & 0xf)
    }

    //==== 传回农历 year年month月的总天数
    function monthDays(year, month) {
      return ((lunarInfo[year - 1900] & (0x10000 >> month)) ? 30 : 29)
    }

    //==== 算出农历, 传入日期对象, 传回农历日期对象
    //     该对象属性有 农历年year 农历月month 农历日day 是否闰年isLeap yearCyl dayCyl monCyl
    function Lunar(objDate) {
      let i, temp = 0
      let baseDate = new Date(1900, 0, 31)
      let offset = Math.floor((objDate - baseDate) / 86400000)

      let dayCyl = offset + 40
      let monCyl = 14

      for (i = 1900; i < 2050 && offset > 0; i++) {
        temp = lYearDays(i)
        offset -= temp
        monCyl += 12
      }
      if (offset < 0) {
        offset += temp;
        i--;
        monCyl -= 12
      }
      //农历年
      let year = i
      let yearCyl = i - 1864

      let leap = leapMonth(i) //闰哪个月
      let isLeap = false  //是否闰年

      for (i = 1; i < 13 && offset > 0; i++) {
        //闰月
        if (leap > 0 && i === (leap + 1) && isLeap === false) {
          --i; isLeap = true; temp = leapDays(year);
        }
        else {
          temp = monthDays(year, i);
        }

        //解除闰月
        if (isLeap === true && i === (leap + 1)) {
          isLeap = false
        }

        offset -= temp
        if (isLeap === false) {
          monCyl++
        }
      }

      if (offset === 0 && leap > 0 && i === leap + 1)
        if (isLeap) {
          isLeap = false
        }
        else {
          isLeap = true
          --i
          --monCyl
        }

      if (offset < 0) {
        offset += temp
        --i
        --monCyl
      }
      //农历月
      let month = i
      //农历日
      let day = offset + 1
      let dateStr = '' + month + "-" + day
      let holidayTemp = lfestival[dateStr]
      let holiday = holidayTemp ? holidayTemp.title : null
      if (holiday == null && month == 12 && ((temp == 29 && day == 29) || (temp == 30 && day == 30))) {
        holiday = '除夕';
      }

      return {
        year: year,
        month: month,
        day: day,
        isLeap: isLeap,
        leap: leap,
        yearCyl: yearCyl,
        dayCyl: dayCyl,
        monCyl: monCyl,
        holiday: holiday
      }
    }

    //==== 中文日期 m为传入月份，d为传入日期
    function cDay(m, d) {
      let nStrMonth = ['正', '二', '三', '四', '五', '六', '七', '八', '九', '十', '冬', '腊']
      let nStr1 = ['日', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十']
      let nStr2 = ['初', '十', '廿', '卅', '']
      //农历中文月
      let lunarMonthCn
      //农历中文日
      let lunarDayCn

      lunarMonthCn = nStrMonth[m - 1]

      lunarMonthCn += '月'

      switch (d) {
        case 10: lunarDayCn = '初十'; break;
        case 20: lunarDayCn = '二十'; break;
        case 30: lunarDayCn = '三十'; break;
        default: lunarDayCn = nStr2[Math.floor(d / 10)] + nStr1[d % 10]
      }
      return {
        lunarMonthCn: lunarMonthCn,
        lunarDayCn: lunarDayCn
      }
    }

    //节气
    function getSolarTerm() {
      let sTermInfo = [
        0, 21208, 42467, 63836, 85337, 107014,
        128867, 150921, 173149, 195551, 218072, 240693,
        263343, 285989, 308563, 331033, 353350, 375494,
        397447, 419210, 440795, 462224, 483532, 504758
      ]
      let solarTerm = [
        '小寒', '大寒', '立春', '雨水', '惊蛰', '春分',
        '清明', '谷雨', '立夏', '小满', '芒种', '夏至',
        '小暑', '大暑', '立秋', '处暑', '白露', '秋分',
        '寒露', '霜降', '立冬', '小雪', '大雪', '冬至'
      ]

      let solarTerms = ''
      let tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2 + 1] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      let tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2 + 1]
      tmp1 = new Date(
        (31556925974.7 * (GY - 1900) + sTermInfo[GM * 2] * 60000) + Date.UTC(1900, 0, 6, 2, 5)
      )
      tmp2 = tmp1.getUTCDate()
      if (tmp2 === GD) solarTerms = solarTerm[GM * 2]

      return solarTerms
    }

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
        
          now = hmSensor.createSensor(hmSensor.id.TIME);

        function add0(v) {
          if (v < 10) return "0" + v;
          else return v;
        }

        function updateCalendar() {
          if (now == null) {
            now = hmSensor.createSensor(hmSensor.id.TIME)
          }
          //用于计算农历年月日的数据
          GY = now.year
          GM = now.month - 1
          GD = now.day

          year = now.year
          month = now.month - 1 + 1
          date = now.day
          hours = now.hour
          minutes = now.minute
          seconds = now.second
		  
		  if (year != calendar.gregorianYear || month != calendar.gregorianMonth || date != calendar.gregorianDay) {
          let dateStr = '' + month + "-" + date
          let holidayTemp = festival[dateStr]
          let holiday = holidayTemp ? holidayTemp.title : null
          calendar.gregorianFestival = holiday
          if (calendar.gregorianFestival == '' || calendar.gregorianFestival == null) {
            calendar.gregorianFestival = getMotherOrFatherDay(year, month, date)
          }
          // month = month.toString().padStart(2, '0')
          // date = date.toString().padStart(2, '0')
          // hours = hours.toString().padStart(2, '0')
          // minutes = minutes.toString().padStart(2, '0')
          // seconds = seconds.toString().padStart(2, '0')
          //公历年月日、星期、时分秒
          calendar.gregorianYear = year
          calendar.gregorianMonth = month
          calendar.gregorianDay = date
          calendar.weekday = weekday[now.week - 1]
          calendar.hours = hours
          calendar.minutes = minutes
          calendar.seconds = seconds

          //去掉时分秒的日期
          let sDObj = new Date(GY, GM, GD);
          let lDObj = new Lunar(sDObj);

          //农历年月日、生肖年,数字
          calendar.lunarYear = lDObj.year
          calendar.lunarMonth = lDObj.month
          calendar.lunarDay = lDObj.day
          calendar.zodiacYear = zodiacs[(GY - 4) % 12]

          //农历中文年月日
          calendar.lunarYearCn = cyclical(GY - 1900 + 36)
          calendar.lunarMonthCn = cDay(lDObj.month, lDObj.day).lunarMonthCn
          calendar.lunarDayCn = cDay(lDObj.month, lDObj.day).lunarDayCn
          calendar.lunarFestival = lDObj.holiday

          //节气
          calendar.solarTerm = getSolarTerm()
		  if (dateText != null) {
                dateText.setProperty(hmUI.prop.TEXT, " " + add0(now.month) + "月" + add0(now.day) + "日 " + calendar.weekday);
            }
			
          if (nongli != null) {
            var str = "" + calendar.lunarMonthCn + "" + calendar.lunarDayCn + "\n";
            if (calendar.solarTerm != '') {//节气
              str += "" + calendar.solarTerm;
            }
            if (calendar.lunarFestival != null) {//农历节日
              str += " " + calendar.lunarFestival;
            }
            if (calendar.gregorianFestival != null) {//公历节日纪念日
              str += " " + calendar.gregorianFestival;
            }

            nongli.setProperty(hmUI.prop.TEXT, str);
          }
		   
        }
		}
            //dynamic modify start
                    
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
     //农历数值 
     nongli = hmUI.createWidget(hmUI.widget.TEXT, {
          x: 127,
          y: 285,
          w: 200,//文本容器宽度,文本会居中显示
          h: 100,//文本容器高度
          color: 0xe7e8e8,
          text_size: 24,
          line_space: 0,
          text: " ",
          align_h: h.ALIGN.CENTER_H,
          text_style: hmUI.text_style.WRAP,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
		
        updateCalendar();

        //创建一个监听器，每次表盘显示时更新
        var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
          resume_call: (function () {//表盘显示
            console.log('ui resume');
            updateCalendar()

          }),
          pause_call: (function () {
            console.log('ui pause');
          }),

        });
  
            //天气图标        
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 150,
              image_array: ["3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 
            //月份日期数值        
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 214,
              month_sc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_tc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_en_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 2,
              month_is_character: false,
              day_startX: 344,
              day_startY: 214,
              day_sc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_tc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_en_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
  
             //星期数值        
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 260,
              week_en: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              week_tc: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              week_sc: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
   
            //心率数值        
            normal$_$heart_rate$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 140,
              y: 112,
              type: hmUI.data_type.HEART,
              font_array:["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '59.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
            //卡路里数值        
            normal$_$calorie$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 142,
              type: hmUI.data_type.CAL,
              font_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
			    invalid_image: '59.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
            //步数数值        
            normal$_$step$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 317,
              y: 162,
              type: hmUI.data_type.STEP,
              font_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
			    invalid_image: '59.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });
  
             
            //距离数值        
            normal$_$distance$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 360,
              type: hmUI.data_type.DISTANCE,
              font_array: ["49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png"],
              align_h: hmUI.align.LEFT,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
			  unit_sc: '61.png',//单位
              unit_tc: '61.png',//单位
              unit_en: '61.png',//单位
			  imperial_unit_sc:"62.png",//单位
			  imperial_unit_tc:"62.png",//单位
			  imperial_unit_en:"62.png",//单位
              dot_image: '60.png', //小数点图片
			    invalid_image: '59.png',// 无数据时显示的图片
              padding: false,
              isCharacter: false
            });

            //电量图标        
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png","77.png","78.png","79.png","80.png","81.png","82.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            //电量百分数        
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 77,
              type: hmUI.data_type.BATTERY,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: "93.png",//单位
              unit_tc: "93.png",//单位
              unit_en: "93.png",//单位
              padding: false,
              isCharacter: false
            });
  
 
            //时钟指针数值        
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 227,
              hour_path: '94.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 227,
              minute_path: '95.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 25,
              second_posY: 212,
              second_path: '96.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
 
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '97.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            //天气图标        
            normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 60,
              y: 150,
              image_array: ["98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

 
            //月份日期数值        
            normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 214,
              month_sc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_tc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_en_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 1,
              month_follow: 0,
              month_space: 2,
              month_is_character: false,
              day_startX: 344,
              day_startY: 214,
              day_sc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_tc_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_en_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 2,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });
 
             //星期数值        
            normal$_$week$_$week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 300,
              y: 260,
              week_en: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png"],
              week_tc: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png"],
              week_sc: ["127.png","128.png","129.png","130.png","131.png","132.png","133.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });
   

            //电量图标        
            normal$_$battery$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["134.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png","143.png","144.png","145.png","146.png","147.png","148.png","149.png","150.png","151.png","152.png","153.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });


            //电量百分数        
            normal$_$battery$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 77,
              type: hmUI.data_type.BATTERY,
              font_array: ["83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_AOD,
              unit_sc: "154.png",//单位
              unit_tc: "154.png",//单位
              unit_en: "154.png",//单位
              padding: false,
              isCharacter: false
            });
  
  
            //时钟指针数值        
            normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 227,
              hour_path: '155.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 25,
              minute_posY: 227,
              minute_path: '156.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
  
            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  