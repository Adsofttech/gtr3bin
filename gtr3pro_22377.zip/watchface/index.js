﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_progress = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''


        //dynamic modify end

        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
      /**
     * 在合适的层级调用此方法即可
     */
        function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
      }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          pos_x: 480 / 2 - 15,
          pos_y: 480 / 2 - 218,
          center_x: 240,
          center_y: 240,
          src: '0114.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
      }
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘
          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
          } else {
            duration = 0;
          }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
          stopSecAnim();
        }),
      });
    }

        function startSecAnim() {
         let sec = now.second * 6;
         secAnim["anim_from"] = sec;
         secAnim["anim_to"] = sec + animDuration * 6 / 1000;

          secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
        function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 89,
              y: 176,
              font_array: ["0101.png","0102.png","0103.png","0104.png","0105.png","0106.png","0107.png","0108.png","0109.png","0110.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0062.png',
              unit_tc: '0062.png',
              unit_en: '0062.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [66,61,81,126,107],
              y: [199,228,270,229,199],
              image_array: ["0131.png","0132.png","0133.png","0134.png","0135.png"],
              image_length: 5,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 354,
              y: 228,
              week_en: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
              week_tc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
              week_sc: ["0121.png","0122.png","0123.png","0124.png","0125.png","0126.png","0127.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 354,
              month_startY: 170,
              month_sc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              month_tc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              month_en_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 405,
              day_startY: 170,
              day_sc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              day_tc_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              day_en_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 80,
              font_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 296,
              font_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              padding: false,
              h_space: 0,
              invalid_image: '0041.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 182,
              hour_startY: 351,
              hour_array: ["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 248,
              minute_startY: 349,
              minute_array: ["0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 357,
              second_array: ["0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0004.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 152,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0005.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 40,
              minute_posY: 198,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            setSec()

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   second_path: '0114.png',
            //   second_centerX: 240,
            //   second_centerY: 240,
            //   second_posX: 15,
            //   second_posY: 218,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  