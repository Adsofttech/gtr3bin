﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


// Start main change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 5

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

            hmUI.showToast({text: "Color Screen " + parseInt(colornumber) });

                  normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
          
            }


      // Start handclock change
        let btncbackground = ''
        let cbackgroundnumber = 1
        let ctotalpictures = 4

        function click_cBackground() {

            if(cbackgroundnumber==ctotalpictures) {
            cbackgroundnumber=1;
                cUpdateBackgroundOne();
                }
            else {
                cbackgroundnumber=cbackgroundnumber+1;
                if(cbackgroundnumber==2) {
                  cUpdateBackgroundTwo();
                }
	if(cbackgroundnumber==3) {
                  cUpdateBackgroundThree();
                }
	if(cbackgroundnumber==4) {
                  cUpdateBackgroundFour();
                }

            }
            if(cbackgroundnumber==1) hmUI.showToast({text: 'Color Hand clock 1'});
            if(cbackgroundnumber==2) hmUI.showToast({text: 'Color Hand clock 2'});
            if(cbackgroundnumber==3) hmUI.showToast({text: 'Color Hand clock 3'});
            if(cbackgroundnumber==4) hmUI.showToast({text: 'Color Hand clock 4'});
        }

  


       //Hand clock change
        function cUpdateBackgroundOne(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H1.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 17,
                 hour_posY: 227,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M1.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 20,
                  minute_posY: 223,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S1.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 17,
                  second_posY: 223,
              second_cover_path: 'Hand_Center.png',
              second_cover_x: 210,
              second_cover_y: 210,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
               
        }

  
        function cUpdateBackgroundTwo(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H2.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 17,
                 hour_posY: 227,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M2.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 20,
                  minute_posY: 223,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S2.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 17,
                  second_posY: 223,
              second_cover_path: 'Hand_Center.png',
              second_cover_x: 210,
              second_cover_y: 210,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
               
        }
      


        function cUpdateBackgroundThree(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H3.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 17,
                 hour_posY: 227,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M3.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 20,
                  minute_posY: 223,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S3.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 17,
                  second_posY: 223,
              second_cover_path: 'Hand_Center.png',
              second_cover_x: 210,
              second_cover_y: 210,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
               
        }

        function cUpdateBackgroundFour(){

                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'Hand_H4.png',
                 hour_centerX: 227,
                  hour_centerY: 227,
                  hour_posX: 17,
                 hour_posY: 227,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'Hand_M4.png',
                  minute_centerX: 227,
                  minute_centerY: 227,
                  minute_posX: 20,
                  minute_posY: 223,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});

               normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'Hand_S4.png',
                  second_centerX: 227,
                  second_centerY: 227,
                  second_posX: 17,
                  second_posY: 223,
              second_cover_path: 'Hand_Center.png',
              second_cover_x: 210,
              second_cover_y: 210,
                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
               
        }



      // Start Day color change
        let btnDbackground = ''
        let Dbackgroundnumber = 1
        let Dtotalpictures = 4

        function click_DBackground() {

            if(Dbackgroundnumber==Dtotalpictures) {
            Dbackgroundnumber=1;
                DUpdateBackgroundOne();
                }
            else {
                Dbackgroundnumber=Dbackgroundnumber+1;
                if(Dbackgroundnumber==2) {
                  DUpdateBackgroundTwo();
                }
	if(Dbackgroundnumber==3) {
                  DUpdateBackgroundThree();
                }
	if(Dbackgroundnumber==4) {
                  DUpdateBackgroundFour();
                }

            }
            if(Dbackgroundnumber==1) hmUI.showToast({text: 'Color Day Red'});
            if(Dbackgroundnumber==2) hmUI.showToast({text: 'Color Day Green'});
            if(Dbackgroundnumber==3) hmUI.showToast({text: 'Color Day Yellow'});
            if(Dbackgroundnumber==4) hmUI.showToast({text: 'Color Day Blue'});
   const result = hmSetting.setScreenOff();
        }
 

       //color day change
        function DUpdateBackgroundOne(){

                normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
                day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_tc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_en_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,

                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
              
        }

  
        function DUpdateBackgroundTwo(){

                normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
                day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_2_01.png","Date_2_02.png","Date_2_03.png","Date_2_04.png","Date_2_05.png","Date_2_06.png","Date_2_07.png","Date_2_08.png","Date_2_09.png","Date_2_10.png"],
              day_tc_array: ["Date_2_01.png","Date_2_02.png","Date_2_03.png","Date_2_04.png","Date_2_05.png","Date_2_06.png","Date_2_07.png","Date_2_08.png","Date_2_09.png","Date_2_10.png"],
              day_en_array: ["Date_2_01.png","Date_2_02.png","Date_2_03.png","Date_2_04.png","Date_2_05.png","Date_2_06.png","Date_2_07.png","Date_2_08.png","Date_2_09.png","Date_2_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,

                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
              
        }

               
 


        function DUpdateBackgroundThree(){

                normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
                day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_3_01.png","Date_3_02.png","Date_3_03.png","Date_3_04.png","Date_3_05.png","Date_3_06.png","Date_3_07.png","Date_3_08.png","Date_3_09.png","Date_3_10.png"],
              day_tc_array: ["Date_3_01.png","Date_3_02.png","Date_3_03.png","Date_3_04.png","Date_3_05.png","Date_3_06.png","Date_3_07.png","Date_3_08.png","Date_3_09.png","Date_3_10.png"],
              day_en_array: ["Date_3_01.png","Date_3_02.png","Date_3_03.png","Date_3_04.png","Date_3_05.png","Date_3_06.png","Date_3_07.png","Date_3_08.png","Date_3_09.png","Date_3_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,

                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
              
        }

        function DUpdateBackgroundFour(){

                normal_date_img_date_day.setProperty(hmUI.prop.MORE, {
                day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_4_01.png","Date_4_02.png","Date_4_03.png","Date_4_04.png","Date_4_05.png","Date_4_06.png","Date_4_07.png","Date_4_08.png","Date_4_09.png","Date_4_10.png"],
              day_tc_array: ["Date_4_01.png","Date_4_02.png","Date_4_03.png","Date_4_04.png","Date_4_05.png","Date_4_06.png","Date_4_07.png","Date_4_08.png","Date_4_09.png","Date_4_10.png"],
              day_en_array: ["Date_4_01.png","Date_4_02.png","Date_4_03.png","Date_4_04.png","Date_4_05.png","Date_4_06.png","Date_4_07.png","Date_4_08.png","Date_4_09.png","Date_4_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,

                  show_level: hmUI.show_level.ONLY_NORMAL,
	});
              
        }



 

        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'MAIN1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 142,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'small_16.png',
              unit_tc: 'small_16.png',
              unit_en: 'small_16.png',
              negative_image: 'small_15.png',
              invalid_image: 'small_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 101,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_tc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_en_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 236,
              month_startY: 184,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 254,
              y: 216,
              week_en: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_tc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_sc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 113,
              y: 342,
              src: 'system_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 347,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 145,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_12.png',
              unit_tc: 'small_12.png',
              unit_en: 'small_12.png',
              imperial_unit_sc: 'small_13.png',
              imperial_unit_tc: 'small_13.png',
              imperial_unit_en: 'small_13.png',
              dot_image: 'small_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 213,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 279,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 347,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 154,
              y: 375,
              image_array: ["steps01.png","steps02.png","steps03.png","steps04.png","steps05.png","steps06.png","steps07.png","steps08.png","steps09.png","steps10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 76,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_14.png',
              unit_tc: 'small_14.png',
              unit_en: 'small_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 154,
              y: 53,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png","batt08.png","batt09.png","batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 194,
              hour_startY: 257,
              hour_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'big_11.png',
              hour_unit_tc: 'big_11.png',
              hour_unit_en: 'big_11.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 369,
              am_y: 258,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 369,
              pm_y: 258,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 17,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 20,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 17,
              second_posY: 233,
              second_cover_path: 'Hand_Center.png',
              second_cover_x: 210,
              second_cover_y: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 272,
              y: 265,
              w: 32,
              h: 58,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 207,
              y: 196,
              w: 43,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 338,
              w: 48,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 310,
              y: 95,
              w: 52,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 315,
              y: 139,
              w: 55,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 128,
              y: 202,
              w: 59,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 13,
              y: 274,
              w: 56,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 274,
              w: 93,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 167,
              y: 347,
              w: 135,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main5.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 142,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: -2,
              unit_sc: 'small_16.png',
              unit_tc: 'small_16.png',
              unit_en: 'small_16.png',
              negative_image: 'small_15.png',
              invalid_image: 'small_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 101,
              image_array: ["weather_icons_01.png","weather_icons_02.png","weather_icons_03.png","weather_icons_04.png","weather_icons_05.png","weather_icons_06.png","weather_icons_07.png","weather_icons_08.png","weather_icons_09.png","weather_icons_10.png","weather_icons_11.png","weather_icons_12.png","weather_icons_13.png","weather_icons_14.png","weather_icons_15.png","weather_icons_16.png","weather_icons_17.png","weather_icons_18.png","weather_icons_19.png","weather_icons_20.png","weather_icons_21.png","weather_icons_22.png","weather_icons_23.png","weather_icons_24.png","weather_icons_25.png","weather_icons_26.png","weather_icons_27.png","weather_icons_28.png","weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 246,
              day_startY: 128,
              day_sc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_tc_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_en_array: ["Date_1_01.png","Date_1_02.png","Date_1_03.png","Date_1_04.png","Date_1_05.png","Date_1_06.png","Date_1_07.png","Date_1_08.png","Date_1_09.png","Date_1_10.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 236,
              month_startY: 184,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 254,
              y: 216,
              week_en: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_tc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              week_sc: ["Week_dayi_icon_01.png","Week_dayi_icon_02.png","Week_dayi_icon_03.png","Week_dayi_icon_04.png","Week_dayi_icon_05.png","Week_dayi_icon_06.png","Week_dayi_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 113,
              y: 342,
              src: 'system_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 316,
              y: 347,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 22,
              y: 145,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_12.png',
              unit_tc: 'small_12.png',
              unit_en: 'small_12.png',
              imperial_unit_sc: 'small_13.png',
              imperial_unit_tc: 'small_13.png',
              imperial_unit_en: 'small_13.png',
              dot_image: 'small_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 65,
              y: 213,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 279,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 347,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: -2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 154,
              y: 375,
              image_array: ["steps01.png","steps02.png","steps03.png","steps04.png","steps05.png","steps06.png","steps07.png","steps08.png","steps09.png","steps10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 76,
              font_array: ["small_01.png","small_02.png","small_03.png","small_04.png","small_05.png","small_06.png","small_07.png","small_08.png","small_09.png","small_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'small_14.png',
              unit_tc: 'small_14.png',
              unit_en: 'small_14.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 154,
              y: 53,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png","batt08.png","batt09.png","batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 194,
              hour_startY: 257,
              hour_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'big_11.png',
              hour_unit_tc: 'big_11.png',
              hour_unit_en: 'big_11.png',
              hour_align: hmUI.align.RIGHT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["big_01.png","big_02.png","big_03.png","big_04.png","big_05.png","big_06.png","big_07.png","big_08.png","big_09.png","big_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 369,
              am_y: 258,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 369,
              pm_y: 258,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_H1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 17,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_M1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 20,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 17,
              second_posY: 233,
              second_cover_path: 'aod_overlay.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });


//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change HandClock shortcut start

            btncbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 404,
              y: 199,
              text: '',
              w: 46,
              h: 59,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_cBackground();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change handclock shortcut end


//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change day color  shortcut start

            btnDbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 245,
              y: 129,
              text: '',
              w: 51,
              h: 43,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_DBackground();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnDbackground.setProperty(hmUI.prop.VISIBLE, true);
   
            // Change day color shortcut end



//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change main background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 204,
              y: 406,
              text: '',
              w: 52,
              h: 41,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end



            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  