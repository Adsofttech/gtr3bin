﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_system_clock_img = ''
        let normal_system_disconnect_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_sun_low_text_img = ''
        let idle_sun_low_separator_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_high_separator_img = ''
        let idle_system_clock_img = ''
        let idle_system_disconnect_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_text_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_calorie_circle_scale = ''
        let idle_calorie_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'HS732-Analog.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 120,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 3,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 120,
              src: 'Sun0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 120,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 3,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 120,
              src: 'Sun0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 165,
              y: 400,
              src: 'a2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 400,
              src: 'new0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 208,
              font_array: ["25PTWhite0001.png","25PTWhite0002.png","25PTWhite0003.png","25PTWhite0004.png","25PTWhite0005.png","25PTWhite0006.png","25PTWhite0007.png","25PTWhite0008.png","25PTWhite0009.png","25PTWhite0010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Celsius.png',
              unit_tc: 'Celsius.png',
              unit_en: 'Celsius.png',
              negative_image: 'Minus.png',
              invalid_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 230,
              image_array: ["Weatherl0001.png","Weatherl0002.png","Weatherl0003.png","Weatherl0004.png","Weatherl0005.png","Weatherl0006.png","Weatherl0007.png","Weatherl0008.png","Weatherl0009.png","Weatherl0010.png","Weatherl0011.png","Weatherl0012.png","Weatherl0013.png","Weatherl0014.png","Weatherl0015.png","Weatherl0016.png","Weatherl0017.png","Weatherl0018.png","Weatherl0019.png","Weatherl0020.png","Weatherl0021.png","Weatherl0022.png","Weatherl0023.png","Weatherl0024.png","Weatherl0025.png","Weatherl0026.png","Weatherl0027.png","Weatherl0028.png","Weatherl0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 315,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'BPM.png',
              unit_tc: 'BPM.png',
              unit_en: 'BPM.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 345,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 315,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'KM.png',
              unit_tc: 'KM.png',
              unit_en: 'KM.png',
              dot_image: '20PTDot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 345,
              src: 'Distance (4).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 342,
              // center_y: 226,
              // start_angle: 15,
              // end_angle: 347,
              // radius: 63,
              // line_width: 10,
              // color: 0xFF00BB00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 185,
              font_array: ["15PTDarkWhite0001.png","15PTDarkWhite0002.png","15PTDarkWhite0003.png","15PTDarkWhite0004.png","15PTDarkWhite0005.png","15PTDarkWhite0006.png","15PTDarkWhite0007.png","15PTDarkWhite0008.png","15PTDarkWhite0009.png","15PTDarkWhite0010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 110,
              // center_y: 226,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 48,
              // line_width: 6,
              // color: 0xFFFF8000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 233,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 110,
              // center_y: 226,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 63,
              // line_width: 10,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 210,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 253,
              image_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 145,
              month_sc_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_tc_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_en_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 112,
              day_sc_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_tc_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_en_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 88,
              week_en: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              week_tc: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              week_sc: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Asset 20.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 28,
              hour_posY: 177,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Asset 19.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 28,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 18,
              second_posY: 226,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 325,
              w: 20,
              h: 20,
              src: 'new0023.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 205,
              w: 20,
              h: 20,
              src: 'new0023.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'HS732-Analog.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 120,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 3,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 345,
              y: 120,
              src: 'Sun0001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 105,
              y: 120,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 3,
              dot_image: '20PTSeprator.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 80,
              y: 120,
              src: 'Sun0002.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 165,
              y: 400,
              src: 'a2.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 275,
              y: 400,
              src: 'new0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 208,
              font_array: ["25PTWhite0001.png","25PTWhite0002.png","25PTWhite0003.png","25PTWhite0004.png","25PTWhite0005.png","25PTWhite0006.png","25PTWhite0007.png","25PTWhite0008.png","25PTWhite0009.png","25PTWhite0010.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Celsius.png',
              unit_tc: 'Celsius.png',
              unit_en: 'Celsius.png',
              negative_image: 'Minus.png',
              invalid_image: 'Minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 320,
              y: 230,
              image_array: ["Weatherl0001.png","Weatherl0002.png","Weatherl0003.png","Weatherl0004.png","Weatherl0005.png","Weatherl0006.png","Weatherl0007.png","Weatherl0008.png","Weatherl0009.png","Weatherl0010.png","Weatherl0011.png","Weatherl0012.png","Weatherl0013.png","Weatherl0014.png","Weatherl0015.png","Weatherl0016.png","Weatherl0017.png","Weatherl0018.png","Weatherl0019.png","Weatherl0020.png","Weatherl0021.png","Weatherl0022.png","Weatherl0023.png","Weatherl0024.png","Weatherl0025.png","Weatherl0026.png","Weatherl0027.png","Weatherl0028.png","Weatherl0029.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 100,
              y: 315,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'BPM.png',
              unit_tc: 'BPM.png',
              unit_en: 'BPM.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 110,
              y: 345,
              src: 'Heart.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 315,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'KM.png',
              unit_tc: 'KM.png',
              unit_en: 'KM.png',
              dot_image: '20PTDot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 320,
              y: 345,
              src: 'Distance (4).png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 342,
              // center_y: 226,
              // start_angle: 15,
              // end_angle: 347,
              // radius: 63,
              // line_width: 10,
              // color: 0xFF00BB00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 325,
              y: 185,
              font_array: ["15PTDarkWhite0001.png","15PTDarkWhite0002.png","15PTDarkWhite0003.png","15PTDarkWhite0004.png","15PTDarkWhite0005.png","15PTDarkWhite0006.png","15PTDarkWhite0007.png","15PTDarkWhite0008.png","15PTDarkWhite0009.png","15PTDarkWhite0010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Percent.png',
              unit_tc: 'Percent.png',
              unit_en: 'Percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 110,
              // center_y: 226,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 48,
              // line_width: 6,
              // color: 0xFFFF8000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 233,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 110,
              // center_y: 226,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 63,
              // line_width: 10,
              // color: 0xFF0080FF,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 210,
              font_array: ["20PTdarkWhite0001.png","20PTdarkWhite0002.png","20PTdarkWhite0003.png","20PTdarkWhite0004.png","20PTdarkWhite0005.png","20PTdarkWhite0006.png","20PTdarkWhite0007.png","20PTdarkWhite0008.png","20PTdarkWhite0009.png","20PTdarkWhite0010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 158,
              y: 253,
              image_array: ["79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png","87.png","88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 200,
              month_startY: 145,
              month_sc_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_tc_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_en_array: ["30PTMonth0001.png","30PTMonth0002.png","30PTMonth0003.png","30PTMonth0004.png","30PTMonth0005.png","30PTMonth0006.png","30PTMonth0007.png","30PTMonth0008.png","30PTMonth0009.png","30PTMonth0010.png","30PTMonth0011.png","30PTMonth0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 207,
              day_startY: 112,
              day_sc_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_tc_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_en_array: ["40PtRED0001.png","40PtRED0002.png","40PtRED0003.png","40PtRED0004.png","40PtRED0005.png","40PtRED0006.png","40PtRED0007.png","40PtRED0008.png","40PtRED0009.png","40PtRED0010.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 205,
              y: 88,
              week_en: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              week_tc: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              week_sc: ["new0034.png","new0035.png","new0036.png","new0037.png","new0038.png","new0039.png","new0040.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Asset 20.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 28,
              hour_posY: 177,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Asset 19.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 28,
              minute_posY: 218,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0004.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 18,
              second_posY: 226,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -75;
                  let end_angle_normal_battery = 257;
                  let center_x_normal_battery = 342;
                  let center_y_normal_battery = 226;
                  let radius_normal_battery = 63;
                  let line_width_cs_normal_battery = 10;
                  let color_cs_normal_battery = 0xFF00BB00;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 270;
                  let center_x_normal_calorie = 110;
                  let center_y_normal_calorie = 226;
                  let radius_normal_calorie = 48;
                  let line_width_cs_normal_calorie = 6;
                  let color_cs_normal_calorie = 0xFFFF8000;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 110;
                  let center_y_normal_step = 226;
                  let radius_normal_step = 63;
                  let line_width_cs_normal_step = 10;
                  let color_cs_normal_step = 0xFF0080FF;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -75;
                  let end_angle_idle_battery = 257;
                  let center_x_idle_battery = 342;
                  let center_y_idle_battery = 226;
                  let radius_idle_battery = 63;
                  let line_width_cs_idle_battery = 10;
                  let color_cs_idle_battery = 0xFF00BB00;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale
                  // initial parameters
                  let start_angle_idle_calorie = -90;
                  let end_angle_idle_calorie = 270;
                  let center_x_idle_calorie = 110;
                  let center_y_idle_calorie = 226;
                  let radius_idle_calorie = 48;
                  let line_width_cs_idle_calorie = 6;
                  let color_cs_idle_calorie = 0xFFFF8000;
                  
                  // calculated parameters
                  let arcX_idle_calorie = center_x_idle_calorie - radius_idle_calorie;
                  let arcY_idle_calorie = center_y_idle_calorie - radius_idle_calorie;
                  let CircleWidth_idle_calorie = 2 * radius_idle_calorie;
                  let angle_offset_idle_calorie = end_angle_idle_calorie - start_angle_idle_calorie;
                  angle_offset_idle_calorie = angle_offset_idle_calorie * progress_cs_idle_calorie;
                  let end_angle_idle_calorie_draw = start_angle_idle_calorie + angle_offset_idle_calorie;
                  
                  idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_calorie,
                    y: arcY_idle_calorie,
                    w: CircleWidth_idle_calorie,
                    h: CircleWidth_idle_calorie,
                    start_angle: start_angle_idle_calorie,
                    end_angle: end_angle_idle_calorie_draw,
                    color: color_cs_idle_calorie,
                    line_width: line_width_cs_idle_calorie,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 270;
                  let center_x_idle_step = 110;
                  let center_y_idle_step = 226;
                  let radius_idle_step = 63;
                  let line_width_cs_idle_step = 10;
                  let color_cs_idle_step = 0xFF0080FF;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  