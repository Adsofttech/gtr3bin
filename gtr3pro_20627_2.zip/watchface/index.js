try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const WIDGET_LEFT_ID = 101;
        const WIDGET_TOP_ID = 102;
        const WIDGET_BOTTOM_ID = 103;
        const WIDGET_BG_ID = 105;
        const WIDGET_TOP = 1;
        const WIDGET_LEFT = 2;
        const WIDGET_BOTTOM = 3;
        const WIDGET_EDIT_SIZE = 140;
        const WIDGET_TIPS_WIDTH = 104;
        const ROOTPATH = "images/";
        const WIDGET_BG_PATH = ROOTPATH + "widget/bg/";
        const WIDGET_ICON_PATH = ROOTPATH + "widget/icon/";
        const WIDGET_POINTER_PATH = ROOTPATH + "widget/pointer.png";
        const WIDGET_FONT_ARRAY = [
            ROOTPATH + "widget/font/0.png",
            ROOTPATH + "widget/font/1.png",
            ROOTPATH + "widget/font/2.png",
            ROOTPATH + "widget/font/3.png",
            ROOTPATH + "widget/font/4.png",
            ROOTPATH + "widget/font/5.png",
            ROOTPATH + "widget/font/6.png",
            ROOTPATH + "widget/font/7.png",
            ROOTPATH + "widget/font/8.png",
            ROOTPATH + "widget/font/9.png",
        ];
        const WEATHER_ARRAY = [
            ROOTPATH + "weather/00.png",
            ROOTPATH + "weather/01.png",
            ROOTPATH + "weather/02.png",
            ROOTPATH + "weather/03.png",
            ROOTPATH + "weather/04.png",
            ROOTPATH + "weather/05.png",
            ROOTPATH + "weather/06.png",
            ROOTPATH + "weather/07.png",
            ROOTPATH + "weather/08.png",
            ROOTPATH + "weather/09.png",
            ROOTPATH + "weather/10.png",
            ROOTPATH + "weather/11.png",
            ROOTPATH + "weather/12.png",
            ROOTPATH + "weather/13.png",
            ROOTPATH + "weather/14.png",
            ROOTPATH + "weather/15.png",
            ROOTPATH + "weather/16.png",
            ROOTPATH + "weather/17.png",
            ROOTPATH + "weather/18.png",
            ROOTPATH + "weather/19.png",
            ROOTPATH + "weather/20.png",
            ROOTPATH + "weather/21.png",
            ROOTPATH + "weather/22.png",
            ROOTPATH + "weather/23.png",
            ROOTPATH + "weather/24.png",
            ROOTPATH + "weather/25.png",
            ROOTPATH + "weather/26.png",
            ROOTPATH + "weather/27.png",
            ROOTPATH + "weather/28.png",
        ];
        const pointPath = ROOTPATH + "pointer/";
        const widgetPreview = ROOTPATH + "widget_preview/"
        const TIPS_ROOT = ROOTPATH + "tips/"
        const WIDGET_TIPS_PATH = TIPS_ROOT + "widget_tips.png";
        const BGROOT = ROOTPATH + "bg_edit/"
        let select = null

        let editBg = null
        let topWidget = null
        let leftWidget = null
        let bottomWidget = null
        let mask = null

        let pointer;
        let week = null;
        let day = null;

        let secondPic = null;
        let now = null;
        let timer_sec_anim = null;
        let lastTime = 0;
        let animDuration = 5000;
        var secAnim = {
            "anim_rate": 'linear',
            "anim_duration": animDuration,
            "anim_from": 0,
            "anim_to": 360,
            "repeat_count": 1,
            "anim_fps": 25,
            "anim_key": "angle",
            "anim_status": 1,
        }
        /**
         * 在合适的层级调用此方法即可
         */
        function setSec() {
            if (now == null) {
                now = hmSensor.createSensor(hmSensor.id.TIME);
            }
            var screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
                stopSecAnim();
            } else {
                secondPic = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    pos_x: 480 / 2 - 13,
                    pos_y: 480 / 2 - 245,
                    center_x: 240,
                    center_y: 240,
                    src: pointPath + "hand_all_s.png",
                    angle: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
            }
            var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                resume_call: (function () {//划入表盘
                    console.log('ui resume');
                    if (timer_sec_anim != null && timer_sec_anim != 0) return;
                    let duration = now.utc - lastTime;
                    if (duration < animDuration) {
                        duration = animDuration - duration;
                    } else {
                        duration = 0;
                    }
                    timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
                        lastTime = now.utc;
                        startSecAnim();
                    }));
                }),
                pause_call: (function () {
                    console.log('ui pause');
                    stopSecAnim();
                }),
            });
        }

        function startSecAnim() {
            let sec = now.second * 6;
            secAnim["anim_from"] = sec;
            secAnim["anim_to"] = sec + animDuration * 6 / 1000;

            secondPic.setProperty(hmUI.prop.ANIM, secAnim);
        }

        /**
         * onDestroy()中要调用一下这个方法
         */
        function stopSecAnim() {
            timer.stopTimer(timer_sec_anim);
            timer_sec_anim = 0;
        }


        const logger = DeviceRuntimeCore.HmLogger.getLogger("sanjiao");
        __$$module$$__.module = DeviceRuntimeCore.Page({
            parseWidgetConfig(editType) {
                let config = {
                    bgPath: null, //背景图
                    iconPath: null, //图标
                    dataType: null,//数据类型
                    nonePath: null,//无数据的图片
                    negativeImage: null,
                    unitEnPath: null,//单位
                    unitScPath: null,
                    unitTcPath: null,
                    spPath: null,
                    pointerType: null,
                    startAngle: 0, //指针开始角度
                    endAngle: 360, //指针结束角度
                };
                switch (editType) {
                    case hmUI.edit_type.STEP:
                        config.bgPath = "bg2.png";
                        config.iconPath = "step.png";
                        config.dataType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.CAL:
                        config.bgPath = "bg2.png";
                        config.iconPath = "kcal.png";
                        config.dataType = hmUI.data_type.CAL;
                        break;
                    case hmUI.edit_type.PAI:
                        config.bgPath = "bg2.png";
                        config.iconPath = "pai.png";
                        config.dataType = hmUI.data_type.PAI_WEEKLY;
                        break;
                    case hmUI.edit_type.DISTANCE:
                        config.bgPath = "bg2.png";
                        config.iconPath = "distance.png";
                        config.dataType = hmUI.data_type.DISTANCE;
                        config.spPath = ROOTPATH + "widget/font/dian.png";
                        config.pointerType = hmUI.data_type.STEP;
                        break;
                    case hmUI.edit_type.HEART:
                        config.bgPath = "bg3.png";
                        config.iconPath = "heart.png";
                        config.dataType = hmUI.data_type.HEART;
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        break;
                    case hmUI.edit_type.BATTERY:
                        config.bgPath = "bg1.png";
                        config.iconPath = "battery.png";
                        config.dataType = hmUI.data_type.BATTERY;
                        config.unitEnPath = ROOTPATH + "widget/font/u.png";
                        config.unitScPath = ROOTPATH + "widget/font/u.png";
                        config.unitTcPath = ROOTPATH + "widget/font/u.png";
                        config.startAngle = 180;
                        config.endAngle = 540;
                        break;
                    case hmUI.edit_type.STAND:
                        config.bgPath = "bg4.png";
                        config.iconPath = "stand.png";
                        config.dataType = hmUI.data_type.STAND;
                        config.spPath = ROOTPATH + "widget/font/sp.png";
                        break;
                    case hmUI.edit_type.SPO2:
                        config.bgPath = "bg2.png";
                        config.iconPath = "spo2.png";
                        config.dataType = hmUI.data_type.SPO2;
                        config.unitEnPath = ROOTPATH + "widget/font/u.png";
                        config.unitScPath = ROOTPATH + "widget/font/u.png";
                        config.unitTcPath = ROOTPATH + "widget/font/u.png";
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        break;
                    // case hmUI.edit_type.STRESS:
                    //     config.bgPath = "bg2.png";
                    //     config.iconPath = "stress.png";
                    //     config.dataType = hmUI.data_type.STRESS;
                    //     break;
                    case hmUI.edit_type.FAT_BURN:
                        config.bgPath = "bg2.png";
                        config.iconPath = "sport.png";
                        config.unitEnPath = ROOTPATH + "widget/font/m.png";
                        config.unitScPath = ROOTPATH + "widget/font/m.png";
                        config.unitTcPath = ROOTPATH + "widget/font/m.png";
                        config.dataType = hmUI.data_type.FAT_BURN;
                        break;
                    case hmUI.edit_type.SLEEP:
                        config.bgPath = "bg2.png";
                        config.iconPath = "sleep.png";
                        config.dataType = hmUI.data_type.SLEEP;
                        config.spPath = ROOTPATH + "widget/font/dian.png";
                        config.unitEnPath = ROOTPATH + "widget/font/h.png";
                        config.unitScPath = ROOTPATH + "widget/font/h.png";
                        config.unitTcPath = ROOTPATH + "widget/font/h.png";
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        break;
                    case hmUI.edit_type.HUMIDITY:
                        config.bgPath = "bg2.png";
                        config.iconPath = "hum.png";
                        config.dataType = hmUI.data_type.HUMIDITY;
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        config.unitEnPath = ROOTPATH + "widget/font/u.png";
                        config.unitScPath = ROOTPATH + "widget/font/u.png";
                        config.unitTcPath = ROOTPATH + "widget/font/u.png";
                        break;
                    case hmUI.edit_type.UVI:
                        config.bgPath = "bg2.png";
                        config.iconPath = "uvi.png";
                        config.dataType = hmUI.data_type.UVI;
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        break;
                    case hmUI.edit_type.WIND:
                        config.bgPath = "bg2.png";
                        config.iconPath = "wind.png";
                        config.dataType = hmUI.data_type.WIND;
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        break;
                    // case hmUI.edit_type.AQI:
                    //     config.bgPath = "bg2.png";
                    //     config.iconPath = "aqi.png";
                    //     config.dataType = hmUI.data_type.AQI;
                    //     config.nonePath = ROOTPATH + "widget/font/none.png";
                    //     break;
                    case hmUI.edit_type.WIND_DIRECTION:
                        config.bgPath = "bg5.png";
                        config.iconPath = "wind_direction.png";
                        config.dataType = hmUI.data_type.WIND_DIRECTION;
                        break;
                    case hmUI.edit_type.WEATHER:
                        config.bgPath = "bg3.png";
                        config.dataType = hmUI.data_type.WEATHER_CURRENT;
                        config.negativeImage = ROOTPATH + "widget/font/fu.png";
                        config.nonePath = ROOTPATH + "widget/font/none.png";
                        config.unitEnPath = ROOTPATH + "widget/font/w_u.png";
                        config.unitScPath = ROOTPATH + "widget/font/w_u.png";
                        config.unitTcPath = ROOTPATH + "widget/font/w_u.png";
                        config.spPath = ROOTPATH + "widget/font/sp.png";
                        break;
                    default:
                        console.log("invalid editType type=" + editType);
                        return config;
                }
                if (config.bgPath != null) {
                    config.bgPath = WIDGET_BG_PATH + config.bgPath;
                }
                if (config.iconPath != null) {
                    config.iconPath = WIDGET_ICON_PATH + config.iconPath;
                }
                if (config.pointerType == null) {
                    config.pointerType = config.dataType;
                }
                return config;
            },
            drawWidget(widgetType, editType) {
                let bgX = 0;
                let bgY = 0;
                switch (widgetType) {
                    case WIDGET_TOP:
                        bgX = 173;
                        bgY = 67;
                        break;
                    case WIDGET_LEFT:
                        bgX = 67;
                        bgY = 173;
                        break;
                    case WIDGET_BOTTOM:
                        bgX = 173;
                        bgY = 279;
                        break;
                    default:
                        console.log("invalid widgetType type=" + widgetType);
                        return;
                }
                const bgSize = 134;
                const iconX = bgX + 51;
                const iconY = bgY + 17;
                const textX = bgX;
                const textY = bgY + 78;
                const textWidth = 134;
                const textHeight = 34;
                const iconSize = 32;
                const config = this.parseWidgetConfig(editType);

                if (config.dataType == null) {
                    console.log("invalid arg dataType is null");
                    return;
                }
                if (config.bgPath == null) {
                    console.log("invalid arg bgpath is null");
                    return;
                }
                if (config.iconPath == null && config.dataType != hmUI.data_type.WEATHER_CURRENT) {
                    console.log("invalid arg iconPath is null");
                    return;
                }

                //widgetbg
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: bgX,
                    y: bgY,
                    w: bgSize,
                    h: bgSize,
                    src: config.bgPath,
                });
                if (config.iconPath == null && config.dataType == hmUI.data_type.WEATHER_CURRENT) {
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: iconX,
                        y: iconY,
                        image_array: WEATHER_ARRAY,
                        image_length: WEATHER_ARRAY.length,
                        type: hmUI.data_type.WEATHER,
                    });
                } else {
                    //icon
                    hmUI.createWidget(hmUI.widget.IMG, {
                        x: iconX,
                        y: iconY,
                        w: iconSize,
                        h: iconSize,
                        src: config.iconPath,
                    });
                }

                if (config.dataType != hmUI.data_type.WIND_DIRECTION) {
                    let dataProp = {
                        x: textX,
                        y: textY,
                        w: textWidth,
                        h: textHeight,
                        align_h: hmUI.align.CENTER_H,
                        type: config.dataType,
                        h_space: 1,
                        font_array: WIDGET_FONT_ARRAY,
                    };
                    if (config.unitEnPath != null) {
                        dataProp.unit_en = config.unitEnPath;
                    }
                    if (config.unitScPath != null) {
                        dataProp.unit_sc = config.unitScPath;
                    }
                    if (config.unitTcPath != null) {
                        dataProp.unit_tc = config.unitTcPath;
                    }
                    if (config.nonePath != null) {
                        dataProp.invalid_image = config.nonePath;
                    }
                    if (config.spPath != null) {
                        dataProp.dot_image = config.spPath;
                    }
                    if (config.negativeImage != null) {
                        dataProp.negative_image = config.negativeImage;
                    }
                    //数据
                    hmUI.createWidget(hmUI.widget.TEXT_IMG, dataProp);
                } else {
                    let array = null;
                    if (hmSetting.getLanguage() == 0) {
                        array = [
                            ROOTPATH + "win_d_sc/1.png",
                            ROOTPATH + "win_d_sc/2.png",
                            ROOTPATH + "win_d_sc/3.png",
                            ROOTPATH + "win_d_sc/4.png",
                            ROOTPATH + "win_d_sc/5.png",
                            ROOTPATH + "win_d_sc/6.png",
                            ROOTPATH + "win_d_sc/7.png",
                            ROOTPATH + "win_d_sc/8.png",
                        ];
                    } else {
                        array = [
                            ROOTPATH + "win_d_en/1.png",
                            ROOTPATH + "win_d_en/2.png",
                            ROOTPATH + "win_d_en/3.png",
                            ROOTPATH + "win_d_en/4.png",
                            ROOTPATH + "win_d_en/5.png",
                            ROOTPATH + "win_d_en/6.png",
                            ROOTPATH + "win_d_en/7.png",
                            ROOTPATH + "win_d_en/8.png",
                        ];
                    }
                    hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                        x: bgX + 44,
                        y: bgY + 80,
                        image_array: array,
                        image_length: array.length,
                        type: config.dataType,
                    });
                }

                //指针
                hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    center_x: bgX + bgSize / 2,
                    center_y: bgY + bgSize / 2,
                    x: 6,
                    y: 52,
                    src: WIDGET_POINTER_PATH,
                    type: config.pointerType,
                    start_angle: config.startAngle,
                    end_angle: config.endAngle,
                });
            },
            init_view() {
                let fontArray = [
                    ROOTPATH + "date/date_0.png",
                    ROOTPATH + "date/date_1.png",
                    ROOTPATH + "date/date_2.png",
                    ROOTPATH + "date/date_3.png",
                    ROOTPATH + "date/date_4.png",
                    ROOTPATH + "date/date_5.png",
                    ROOTPATH + "date/date_6.png",
                    ROOTPATH + "date/date_7.png",
                    ROOTPATH + "date/date_8.png",
                    ROOTPATH + "date/date_9.png",
                ];

                select = ROOTPATH + "select/"

                editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
                    edit_id: WIDGET_BG_ID,
                    x: 0,
                    y: 0,
                    bg_config: [
                        { id: 1, preview: BGROOT + "bg_edit_1.png", path: BGROOT + "preview_1.png" },
                        { id: 2, preview: BGROOT + "bg_edit_2.png", path: BGROOT + "preview_2.png" },
                        { id: 3, preview: BGROOT + "bg_edit_3.png", path: BGROOT + "preview_3.png" },
                        { id: 4, preview: BGROOT + "bg_edit_4.png", path: BGROOT + "preview_4.png" },
                        { id: 5, preview: BGROOT + "bg_edit_5.png", path: BGROOT + "preview_5.png" },
                    ],
                    count: 5,
                    default_id: 1,
                    fg: BGROOT + "fg.png",
                    tips_x: 178,
                    tips_y: 428,
                    tips_bg: TIPS_ROOT + "bg_tips.png",
                });


                let widgetOptionalArray = [
                    { type: hmUI.edit_type.STEP, preview: widgetPreview + "step.png" },
                    { type: hmUI.edit_type.CAL, preview: widgetPreview + "kcal.png" },
                    { type: hmUI.edit_type.PAI, preview: widgetPreview + "pai.png" },
                    { type: hmUI.edit_type.DISTANCE, preview: widgetPreview + "distance.png" },
                    { type: hmUI.edit_type.HEART, preview: widgetPreview + "heart.png" },
                    { type: hmUI.edit_type.BATTERY, preview: widgetPreview + "battery.png" },
                    { type: hmUI.edit_type.STAND, preview: widgetPreview + "stand.png" },
                    { type: hmUI.edit_type.SPO2, preview: widgetPreview + "spo2.png" },
                    // { type: hmUI.edit_type.STRESS, preview: widgetPreview + "stress.png" },
                    { type: hmUI.edit_type.FAT_BURN, preview: widgetPreview + "sport.png" },
                    { type: hmUI.edit_type.SLEEP, preview: widgetPreview + "sleep.png" },
                    { type: hmUI.edit_type.HUMIDITY, preview: widgetPreview + "hum.png" },
                    { type: hmUI.edit_type.UVI, preview: widgetPreview + "uvi.png" },
                    // { type: hmUI.edit_type.AQI, preview: widgetPreview + "aqi.png" },
                    { type: hmUI.edit_type.WIND, preview: widgetPreview + "wind.png" },
                    { type: hmUI.edit_type.WIND_DIRECTION, preview: widgetPreview + "winddertion.png" },
                    { type: hmUI.edit_type.WEATHER, preview: widgetPreview + "weather.png" },

                ];
                let groupX = 170;
                let groupY = 64;
                //可编辑组件
                topWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_TOP_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.STEP,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 188 - groupX,
                    tips_y: 24 - groupY,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                var editType = topWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_TOP, editType);




                groupX = 64;
                groupY = 170;
                leftWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_LEFT_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.BATTERY,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 84 - groupX,
                    tips_y: 130 - groupY,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                editType = leftWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_LEFT, editType);

                groupX = 170;
                groupY = 276;
                bottomWidget = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
                    edit_id: WIDGET_BOTTOM_ID,
                    x: groupX,
                    y: groupY,
                    w: WIDGET_EDIT_SIZE,
                    h: WIDGET_EDIT_SIZE,
                    select_image: select + "select.png",
                    un_select_image: select + "unselect.png",
                    default_type: hmUI.edit_type.HEART,
                    optional_types: widgetOptionalArray,
                    count: widgetOptionalArray.length,
                    tips_BG: WIDGET_TIPS_PATH,
                    tips_x: 188 - groupX,
                    tips_y: 236 - groupY,
                    tips_width: WIDGET_TIPS_WIDTH,
                });
                editType = bottomWidget.getProperty(hmUI.prop.CURRENT_TYPE);
                this.drawWidget(WIDGET_BOTTOM, editType);




                let weekArray = [
                    ROOTPATH + "week/week_1.png",
                    ROOTPATH + "week/week_2.png",
                    ROOTPATH + "week/week_3.png",
                    ROOTPATH + "week/week_4.png",
                    ROOTPATH + "week/week_5.png",
                    ROOTPATH + "week/week_6.png",
                    ROOTPATH + "week/week_7.png",
                ];
                week = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    x: 293,
                    y: 226,
                    week_tc: weekArray,
                    week_sc: weekArray,
                    week_en: weekArray,
                });
                day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONAL_AOD,
                    day_startX: 375,
                    day_startY: 226,
                    day_zero: true,
                    day_en_array: fontArray,
                });




                const centerXValue = 240;
                const centerYValue = 240;
                const secondProp = {
                    centerX: centerXValue,
                    centerY: centerYValue,
                    posX: 13,
                    posY: 245,
                    path: pointPath + "hand_all_s.png",
                };
                const pointerConfig = [
                    {
                        id: 1,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 12,
                            posY: 172,
                            path: pointPath + "hand_4_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 229,
                            path: pointPath + "hand_4_m.png",
                        },
                        //second: secondProp,
                        preview: pointPath + "preview1.png",
                    },
                    {
                        id: 2,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 17,
                            posY: 173,
                            path: pointPath + "hand_1_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 239,
                            path: pointPath + "hand_1_m.png",
                        },
                        //second: secondProp,
                        preview: pointPath + "preview2.png",
                    },
                    {
                        id: 3,
                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 17,
                            posY: 173,
                            path: pointPath + "hand_2_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 239,
                            path: pointPath + "hand_2_m.png",
                        },
                        //second: secondProp,
                        preview: pointPath + "preview3.png",
                    },
                    {
                        id: 4,

                        hour: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 12,
                            posY: 172,
                            path: pointPath + "hand_3_h.png",
                        },
                        minute: {
                            centerX: centerXValue,
                            centerY: centerYValue,
                            posX: 18,
                            posY: 229,
                            path: pointPath + "hand_3_m.png",
                        },
                        //second: secondProp,
                        preview: pointPath + "preview4.png",
                    },
                ];

                let pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
                    edit_id: 120,
                    x: 0,
                    y: 0,
                    config: pointerConfig,
                    count: pointerConfig.length,
                    default_id: 1,
                    fg: ROOTPATH + "pointer/fg.png",
                    tips_x: 178,
                    tips_y: 428,
                    tips_bg: TIPS_ROOT + "bg_tips.png",
                });
                const screenType = hmSetting.getScreenType();
                const aodModel = screenType == hmSetting.screen_type.AOD;
                const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
                pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
                setSec();

                mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: ROOTPATH + "mask70.png",
                    show_level: hmUI.show_level.ONLY_EDIT,
                });








            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();
            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke')
                stopSecAnim()
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
