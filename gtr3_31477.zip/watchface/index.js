﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''

        let normal_temperature_icon_img = ''
        let normal_2_temperature_icon_img = ''
        let normal_3_temperature_icon_img = ''
        let normal_4_temperature_icon_img = ''
        let normal_5_temperature_icon_img = ''
        let normal_6_temperature_icon_img = ''
        let normal_7_temperature_icon_img = ''

        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_pai_day_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''

        let normal_analog_clock_time_pointer_second = ''
        let normal_2_analog_clock_time_pointer_second = ''
        let normal_3_analog_clock_time_pointer_second = ''
        let normal_4_analog_clock_time_pointer_second = ''
        let normal_5_analog_clock_time_pointer_second = ''
        let normal_6_analog_clock_time_pointer_second = ''
        let normal_7_analog_clock_time_pointer_second = ''


        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
//////////////////////////////////////////////////////////////////////////////////////////////////

        // color time select
        let btncolorfont = ''
        let colornumber = 1
        let totalcolorpictures = 7

        function click_color() {
            if(colornumber>=totalcolorpictures) {
            colornumber=1;
                UpdatecolorOne();
                }
            else {
                colornumber=colornumber+1;
                if(colornumber==2) {
                  UpdatecolorTwo();
                }
                if(colornumber==3) {
                  UpdatecolorThree();
                }
                if(colornumber==4) {
                  UpdatecolorFour();
                }
                if(colornumber==5) {
                  UpdatecolorFive();
                }
                if(colornumber==6) {
                  UpdatecolorSix();
                }
                if(colornumber==7) {
                  UpdatecolorSeven();
                }
 
            }
          if(colornumber==1) hmUI.showToast({text: 'White'});
          if(colornumber==2) hmUI.showToast({text: 'Lemon'});
          if(colornumber==3) hmUI.showToast({text: 'Green'});
          if(colornumber==4) hmUI.showToast({text: 'Blue'});
          if(colornumber==5) hmUI.showToast({text: 'Red'});
          if(colornumber==6) hmUI.showToast({text: 'Orange'});
          if(colornumber==7) hmUI.showToast({text: 'Purple'});

        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //color time
        function UpdatecolorOne(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }

        function UpdatecolorTwo(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }


        function UpdatecolorThree(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }

        function UpdatecolorFour(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }

        function UpdatecolorFive(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }

        function UpdatecolorSix(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

        }

        function UpdatecolorSeven(){


        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);

        }

///////////////////////////////////////////////////////////////////////////////////////////////

        // Activity select
        let btnbackground = ''
        let backgroundnumber = 1
        let totalpictures = 7
        let cc = 0

        function click_Background() {
            if(backgroundnumber>=totalpictures) {
            backgroundnumber=1;
                UpdateBackgroundOne();
                }
            else {
                backgroundnumber=backgroundnumber+1;
                if(backgroundnumber==2) {
                  UpdateBackgroundTwo();
                }
                if(backgroundnumber==3) {
                  UpdateBackgroundThree();
                }
               if(backgroundnumber==4) {
                  UpdateBackgroundFour();
                }
               if(backgroundnumber==5) {
                  UpdateBackgroundFive();
                }
               if(backgroundnumber==6) {
                  UpdateBackgroundSix();
                }
               if(backgroundnumber==7) {
                  UpdateBackgroundSeven();
                }
    

            }
          if(backgroundnumber==1) hmUI.showToast({text: 'Steps'});
          if(backgroundnumber==2) hmUI.showToast({text: 'Calorie'});
          if(backgroundnumber==3) hmUI.showToast({text: 'Distance'});
          if(backgroundnumber==4) hmUI.showToast({text: 'Heart Rate'});
          if(backgroundnumber==5) hmUI.showToast({text: 'SPO2'});
          if(backgroundnumber==6) hmUI.showToast({text: 'Pai'});
          if(backgroundnumber==7) hmUI.showToast({text: 'Battery'});
        }

//////////////////////////////////////////////////////////////////////////////////////////////////

        //steps
        function UpdateBackgroundOne(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        }

///////////////////////////////////////////////////////////////////////////////////////////////
        function UpdateBackgroundTwo(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////

        function UpdateBackgroundThree(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////
        function UpdateBackgroundFour(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////


        function UpdateBackgroundFive(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////

        function UpdateBackgroundSix(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////

        function UpdateBackgroundSeven(){


       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

        }

///////////////////////////////////////////////////////////////////////////////////////////////

        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ALL,
            });


/////// use for time color

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_01.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_2_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_02.png',
              show_level: hmUI.show_level.ALL,
            });
            normal_3_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_03.png',
              show_level: hmUI.show_level.ALL,
            });
            normal_4_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_04.png',
              show_level: hmUI.show_level.ALL,
            });
            normal_5_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_05.png',
              show_level: hmUI.show_level.ALL,
            });
            normal_6_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_06.png',
              show_level: hmUI.show_level.ALL,
            });
            normal_7_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 54,
              y: 104,
              src: 'color_time_07.png',
              show_level: hmUI.show_level.ALL,
            });

/////// use for time color end


            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 93,
              y: 98,
              font_array: ["Weather_Font_01.png","Weather_Font_02.png","Weather_Font_03.png","Weather_Font_04.png","Weather_Font_05.png","Weather_Font_06.png","Weather_Font_07.png","Weather_Font_08.png","Weather_Font_09.png","Weather_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_Symbo_01.png',
              unit_tc: 'Weather_Symbo_01.png',
              unit_en: 'Weather_Symbo_01.png',
              negative_image: 'Weather_Symbo_02.png',
              invalid_image: 'Weather_Symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 52,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 233,
              y: 403,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ALL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 176,
              y: 405,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 270,
              y: 325,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 325,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 62,
              y: 317,
              src: 'icon_pai.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 323,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 320,
              src: 'icon_O2.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 86,
              y: 320,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Bpm.png',
              unit_tc: 'Bpm.png',
              unit_en: 'Bpm.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 320,
              src: 'icon_Pulse.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 249,
              y: 320,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 325,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 292,
              y: 327,
              src: 'icon_Batt.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 48,
              y: 317,
              image_array: ["Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ALL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 325,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Act_font_KM.png',
              unit_tc: 'Act_font_KM.png',
              unit_en: 'Act_font_KM.png',
              imperial_unit_sc: 'Act_font_MI.png',
              imperial_unit_tc: 'Act_font_MI.png',
              imperial_unit_en: 'Act_font_MI.png',
              dot_image: 'Dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ALL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 328,
              src: 'icon_dis.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 121,
              y: 327,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ALL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 323,
              src: 'icon_cal.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 110,
              y: 325,
              font_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 298,
              y: 325,
              src: 'icon_step.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 178,
              day_startY: 66,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 252,
              y: 69,
              week_en: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_tc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              week_sc: ["WeekDay_01.png","WeekDay_02.png","WeekDay_03.png","WeekDay_04.png","WeekDay_05.png","WeekDay_06.png","WeekDay_07.png"],
              show_level: hmUI.show_level.ALL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 248,
              month_startY: 104,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 99,
              am_y: 152,
              am_sc_path: 'clock_AM.png',
              am_en_path: 'clock_AM.png',
              pm_x: 99,
              pm_y: 152,
              pm_sc_path: 'clock_PM.png',
              pm_en_path: 'clock_PM.png',
              show_level: hmUI.show_level.ALL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 54,
              hour_startY: 183,
              hour_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'Time_font_11.png',
              hour_unit_tc: 'Time_font_11.png',
              hour_unit_en: 'Time_font_11.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 177,
              minute_startY: 183,
              minute_array: ["Time_font_01.png","Time_font_02.png","Time_font_03.png","Time_font_04.png","Time_font_05.png","Time_font_06.png","Time_font_07.png","Time_font_08.png","Time_font_09.png","Time_font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ALL,
            });


///////////////////////////// analog seconds

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S1.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            });


            normal_2_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S2.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

            normal_3_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S3.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

            normal_4_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S4.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

            normal_5_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S5.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

            normal_6_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S6.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

            normal_7_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S7.png',
              second_centerX: 354,
              second_centerY: 226,
              second_posX: 5,
              second_posY: 55,
              show_level: hmUI.show_level.ALL,
            })

///////////////////////////// analog seconds end

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 312,
              y: 179,
              w: 87,
              h: 99,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ALL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 193,
              w: 45,
              h: 89,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ALL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 171,
              y: 399,
              w: 70,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ALL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 96,
              y: 44,
              w: 64,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 102,
              y: 98,
              w: 56,
              h: 45,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ALL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 163,
              y: 319,
              w: 112,
              h: 65,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ALL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 319,
              w: 109,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ALL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 319,
              w: 108,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ALL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 319,
              w: 108,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ALL,
            });

/////////////////Show element at the first time //////////

if (cc==0) {
  cc = 1

       normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_pai_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_battery_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
       normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);

       normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
       normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);

        normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
        normal_2_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);


        normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
        normal_2_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_3_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_4_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_5_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_6_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
        normal_7_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

 
}
//////////////////////////////////////////////////////////////////////////////////////////////////
 
           // Element on/off
            btnbackground = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 49,
              y: 325,
              text: '',
              w: 50,
              h: 50,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Background();
              },
              show_level: hmUI.show_level.ALL,
            });
            btnbackground.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

          // change color
            btncolorfont = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 186,
              y: 16,
              text: '',
              w: 100,
              h: 36,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_color();
              },
              show_level: hmUI.show_level.ALL,
            });
            btncolorfont.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
