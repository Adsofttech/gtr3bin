﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 396,
              src: '0118.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 396,
              src: '0120.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 211,
              y: 347,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 179,
              y: 341,
              src: '0123.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 258,
              y: 294,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0057.png',
              unit_tc: '0057.png',
              unit_en: '0057.png',
              dot_image: '0058.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 236,
              y: 285,
              src: '0122.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 98,
              y: 294,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 47,
              y: 289,
              src: '0121.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 241,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 43,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0059.png',
              unit_tc: '0059.png',
              unit_en: '0059.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 46,
              image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 100,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 263,
              y: 90,
              image_array: ["0111.png","0112.png","0113.png","0114.png","0115.png","0116.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 98,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0060.png',
              unit_tc: '0060.png',
              unit_en: '0060.png',
              negative_image: '0072.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 122,
              y: 91,
              image_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png","0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 191,
              month_sc_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_tc_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_en_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 79,
              day_startY: 146,
              day_sc_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_tc_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_en_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 397,
              am_y: 201,
              am_sc_path: '0138.png',
              am_en_path: '0138.png',
              pm_x: 397,
              pm_y: 201,
              pm_sc_path: '0139.png',
              pm_en_path: '0139.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 180,
              hour_startY: 162,
              hour_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 296,
              minute_startY: 161,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 164,
              src: '0021.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0022.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 102,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0000.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 262,
              y: 396,
              src: '0118.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 179,
              y: 396,
              src: '0120.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 69,
              y: 241,
              week_en: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_tc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              week_sc: ["0023.png","0024.png","0025.png","0026.png","0027.png","0028.png","0029.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 43,
              font_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0059.png',
              unit_tc: '0059.png',
              unit_en: '0059.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 168,
              y: 46,
              image_array: ["0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 33,
              month_startY: 191,
              month_sc_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_tc_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_en_array: ["0089.png","0090.png","0091.png","0092.png","0093.png","0094.png","0095.png","0096.png","0097.png","0098.png","0099.png","0100.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 79,
              day_startY: 146,
              day_sc_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_tc_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_en_array: ["0079.png","0080.png","0081.png","0082.png","0083.png","0084.png","0085.png","0086.png","0087.png","0088.png"],
              day_zero: 1,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 397,
              am_y: 201,
              am_sc_path: '0138.png',
              am_en_path: '0138.png',
              pm_x: 397,
              pm_y: 201,
              pm_sc_path: '0139.png',
              pm_en_path: '0139.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 181,
              hour_startY: 161,
              hour_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 296,
              minute_startY: 161,
              minute_array: ["0011.png","0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 276,
              y: 164,
              src: '0021.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 148,
              y: 364,
              w: 100,
              h: 100,
              src: '0030.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 59,
              w: 100,
              h: 100,
              src: '0030.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 245,
              y: 60,
              w: 100,
              h: 100,
              src: '0030.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 95,
              y: 257,
              w: 120,
              h: 100,
              src: '0030.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
