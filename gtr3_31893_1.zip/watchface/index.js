﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_linear_scale_pointer_img = ''
        let idle_battery_linear_scale_mirror = ''
        let idle_battery_linear_scale_pointer_img_mirror = ''
        let idle_analog_clock_time_pointer_second = ''
        let editGroup_1  = ''
        let editGroup_2  = ''
        let editGroup_3  = ''
        let editGroup_4  = ''
        let editableZone_5_battery_linear_scale = null;
        let editableZone_5_battery_linear_scale_pointer_img = ''
        let editableZone_5_battery_linear_scale_mirror = ''
        let editableZone_5_battery_linear_scale_pointer_img_mirror = ''
        let editGroup_5  = ''
        let mask = ''
        let fg_mask = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'tarcza.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 105,
              y: 110,
              src: 'zn_br_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 103,
              src: 'zn_AL.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 51,
              week_en: ["d_tyg_1.png","d_tyg_2.png","d_tyg_3.png","d_tyg_4.png","d_tyg_5.png","d_tyg_6.png","d_tyg_7.png"],
              week_tc: ["d_tyg_1.png","d_tyg_2.png","d_tyg_3.png","d_tyg_4.png","d_tyg_5.png","d_tyg_6.png","d_tyg_7.png"],
              week_sc: ["d_tyg_1.png","d_tyg_2.png","d_tyg_3.png","d_tyg_4.png","d_tyg_5.png","d_tyg_6.png","d_tyg_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 349,
              day_sc_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              day_tc_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              day_en_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 171,
              hour_startY: 285,
              hour_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_unit_sc: 'cyf_D_dwuk.png',
              hour_unit_tc: 'cyf_D_dwuk.png',
              hour_unit_en: 'cyf_D_dwuk.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 233,
              minute_startY: 285,
              minute_array: ["cyf_D_00.png","cyf_D_01.png","cyf_D_02.png","cyf_D_03.png","cyf_D_04.png","cyf_D_05.png","cyf_D_06.png","cyf_D_07.png","cyf_D_08.png","cyf_D_09.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'tarcza_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
              idle_battery_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            idle_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
            idle_battery_linear_scale_pointer_img_mirror = hmUI.createWidget(hmUI.widget.IMG);
            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 227,
              // start_y: 285,
              // color: 0xFF3E3EFF,
              // pointer: 'ik_aku.png',
              // lenght: 100,
              // line_width: 5,
              // vertical: False,
              // mirror: True,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'w_AOD_S.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 8,
              second_posY: 195,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            editGroup_1 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10021,
              x: 61,
              y: 167,
              w: 158,
              h: 59,
              select_image: 'ed_r_akt.png',
              un_select_image: 'ed_r_pas.png',
              default_type: hmUI.edit_type.BATTERY,
              optional_types: [
                { type: hmUI.edit_type.BATTERY, preview: 'ez(1)_BATTERY.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(1)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(1)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(1)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(1)_DISTANCE.png' },
                { type: 1300002, preview: 'ez(1)_FAT_BURNING.png', title_sc: 'X X X', title_tc: 'X X X', title_en: 'X X X' },
              ],
              count: 6,
              tips_BG: 'ed_wyb.png',
              tips_x: -1,
              tips_y: -45,
              tips_width: 131,
              tips_margin: 0,
            });

            const editType_1 = editGroup_1.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_1) {
              case hmUI.edit_type.BATTERY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 123,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'cyf_m_proc.png',
                  unit_tc: 'cyf_m_proc.png',
                  unit_en: 'cyf_m_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.BATTERY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 80,
                  y: 180,
                  src: 'ik_aku.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 120,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: true,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 74,
                  y: 175,
                  src: 'ik_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 128,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 75,
                  y: 178,
                  src: 'ik_kal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 121,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_zn_BPM.png',
                  unit_tc: 'cyf_zn_BPM.png',
                  unit_en: 'cyf_zn_BPM.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 73,
                  y: 183,
                  src: 'ik_puls.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 123,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'cyf_m_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 77,
                  y: 178,
                  src: 'ik_km.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 111,
              y: 181,
              src: 'ped1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_2 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10022,
              x: 235,
              y: 167,
              w: 158,
              h: 59,
              select_image: 'ed_r_akt.png',
              un_select_image: 'ed_r_pas.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(2)_WEATHER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(2)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(2)_UVI.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(2)_WIND.png' },
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(2)_ALTIMETER.png' },
                { type: 1300002, preview: 'ez(2)_FAT_BURNING.png', title_sc: 'X X X', title_tc: 'X X X', title_en: 'X X X' },
              ],
              count: 6,
              tips_BG: 'ed_wyb.png',
              tips_x: 56,
              tips_y: -45,
              tips_width: 131,
              tips_margin: 0,
            });

            const editType_2 = editGroup_2.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_2) {
              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 180,
              src: 'ped2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 267,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'cyf_m_stC.png',
                  unit_tc: 'cyf_m_stC.png',
                  unit_en: 'cyf_m_stC.png',
                  negative_image: 'cyf_m_minus.png',
                  invalid_image: 'zn_error.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 355,
              y: 180,
              src: 'ik_term.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 276,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'cyf_zn_UV.png',
                  unit_tc: 'cyf_zn_UV.png',
                  unit_en: 'cyf_zn_UV.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 175,
                  src: 'ik_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 272,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m_proc.png',
                  unit_tc: 'cyf_m_proc.png',
                  unit_en: 'cyf_m_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 177,
                  src: 'ik_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 272,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 174,
                  src: 'ik_cis.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 274,
                  y: 191,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_zn_wiatr.png',
                  unit_tc: 'cyf_zn_wiatr.png',
                  unit_en: 'cyf_zn_wiatr.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 183,
                  src: 'ik_wiatr.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_3 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10023,
              x: 61,
              y: 225,
              w: 158,
              h: 159,
              select_image: 'ed_r_akt.png',
              un_select_image: 'ed_r_pas.png',
              default_type: hmUI.edit_type.DISTANCE,
              optional_types: [
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(3)_DISTANCE.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(3)_STEP.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(3)_HEART.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(3)_CAL.png' },
                { type: 1300002, preview: 'ez(3)_FAT_BURNING.png', title_sc: 'X X X', title_tc: 'X X X', title_en: 'X X X' },
              ],
              count: 5,
              tips_BG: 'ed_wyb.png',
              tips_x: -1,
              tips_y: 57,
              tips_width: 131,
              tips_margin: 0,
            });

            const editType_3 = editGroup_3.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_3) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 121,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: true,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 73,
                  y: 243,
                  src: 'ik_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 128,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 73,
                  y: 243,
                  src: 'ik_kal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 121,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_zn_BPM.png',
                  unit_tc: 'cyf_zn_BPM.png',
                  unit_en: 'cyf_zn_BPM.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 73,
                  y: 249,
                  src: 'ik_puls.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 123,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'cyf_m_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 75,
                  y: 245,
                  src: 'ik_km.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 112,
              y: 229,
              src: 'ped3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            editGroup_4 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10024,
              x: 235,
              y: 225,
              w: 158,
              h: 159,
              select_image: 'ed_r_akt.png',
              un_select_image: 'ed_r_pas.png',
              default_type: hmUI.edit_type.ALTIMETER,
              optional_types: [
                { type: hmUI.edit_type.ALTIMETER, preview: 'ez(4)_ALTIMETER.png' },
                { type: hmUI.edit_type.HUMIDITY, preview: 'ez(4)_HUMIDITY.png' },
                { type: hmUI.edit_type.UVI, preview: 'ez(4)_UVI.png' },
                { type: hmUI.edit_type.WIND, preview: 'ez(4)_WIND.png' },
                { type: hmUI.edit_type.WEATHER, preview: 'ez(4)_WEATHER.png' },
                { type: hmUI.edit_type.STEP, preview: 'ez(4)_STEP.png' },
                { type: hmUI.edit_type.CAL, preview: 'ez(4)_CAL.png' },
                { type: hmUI.edit_type.HEART, preview: 'ez(4)_HEART.png' },
                { type: hmUI.edit_type.DISTANCE, preview: 'ez(4)_DISTANCE.png' },
                { type: 1300002, preview: 'ez(4)_FAT_BURNING.png', title_sc: 'X X X', title_tc: 'X X X', title_en: 'X X X' },
              ],
              count: 10,
              tips_BG: 'ed_wyb.png',
              tips_x: 56,
              tips_y: 57,
              tips_width: 131,
              tips_margin: 0,
            });

            const editType_4 = editGroup_4.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_4) {
              case hmUI.edit_type.STEP:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 268,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: true,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.STEP,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 355,
                  y: 245,
                  src: 'ik_krok.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.CAL:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.CAL,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 356,
                  y: 245,
                  src: 'ik_kal.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HEART:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 268,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_zn_BPM.png',
                  unit_tc: 'cyf_zn_BPM.png',
                  unit_en: 'cyf_zn_BPM.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HEART,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 356,
                  y: 251,
                  src: 'ik_puls.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.DISTANCE:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 270,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: -1,
                  dot_image: 'cyf_m_przec.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.DISTANCE,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 361,
                  y: 245,
                  src: 'ik_km.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 229,
              src: 'ped4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 270,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m_stC.png',
                  unit_tc: 'cyf_m_stC.png',
                  unit_en: 'cyf_m_stC.png',
                  negative_image: 'cyf_m_minus.png',
                  invalid_image: 'zn_error.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
              x: 358,
              y: 250,
              src: 'ik_term.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.UVI:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 275,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 1,
                  unit_sc: 'cyf_zn_UV.png',
                  unit_tc: 'cyf_zn_UV.png',
                  unit_en: 'cyf_zn_UV.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.UVI,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 356,
                  y: 247,
                  src: 'ik_UV.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.HUMIDITY:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 269,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_m_proc.png',
                  unit_tc: 'cyf_m_proc.png',
                  unit_en: 'cyf_m_proc.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.HUMIDITY,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 247,
                  src: 'ik_wilg.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.ALTIMETER:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 273,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.ALTIMETER,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 247,
                  src: 'ik_cis.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WIND:
                hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                  x: 271,
                  y: 240,
                  font_array: ["cyf_m_00.png","cyf_m_01.png","cyf_m_02.png","cyf_m_03.png","cyf_m_04.png","cyf_m_05.png","cyf_m_06.png","cyf_m_07.png","cyf_m_08.png","cyf_m_09.png"],
                  padding: false,
                  h_space: 0,
                  unit_sc: 'cyf_zn_wiatr.png',
                  unit_tc: 'cyf_zn_wiatr.png',
                  unit_en: 'cyf_zn_wiatr.png',
                  align_h: hmUI.align.CENTER_H,
                  type: hmUI.data_type.WIND,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });

                hmUI.createWidget(hmUI.widget.IMG, {
                  x: 354,
                  y: 247,
                  src: 'ik_wiatr.png',
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            
            editGroup_5 = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_GROUP, {
              edit_id: 10025,
              x: 150,
              y: 108,
              w: 158,
              h: 59,
              select_image: 'ed_r_akt.png',
              un_select_image: 'ed_r_pas.png',
              default_type: hmUI.edit_type.WEATHER,
              optional_types: [
                { type: hmUI.edit_type.WEATHER, preview: 'ez(5)_WEATHER.png' },
                { type: hmUI.edit_type.BATTERY, preview: 'ez(5)_BATTERY.png' },
                { type: 1300002, preview: 'ez(5)_FAT_BURNING.png', title_sc: 'X X X', title_tc: 'X X X', title_en: 'X X X' },
              ],
              count: 3,
              tips_BG: 'ed_wyb.png',
              tips_x: 11,
              tips_y: -45,
              tips_width: 131,
              tips_margin: 0,
            });

            const editType_5 = editGroup_5.getProperty(hmUI.prop.CURRENT_TYPE);

            switch (editType_5) {
              case hmUI.edit_type.BATTERY:
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  editableZone_5_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
                  editableZone_5_battery_linear_scale_mirror = hmUI.createWidget(hmUI.widget.FILL_RECT);
                };

                editableZone_5_battery_linear_scale_pointer_img = hmUI.createWidget(hmUI.widget.IMG);
                editableZone_5_battery_linear_scale_pointer_img_mirror = hmUI.createWidget(hmUI.widget.IMG);
                // editableZone_5_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
                  // start_x: 227,
                  // start_y: 149,
                  // color: 0xFF4D4DFF,
                  // pointer: 'ik_aku.png',
                  // lenght: 63,
                  // line_width: 8,
                  // vertical: False,
                  // mirror: True,
                  // inversion: False,
                  // type: hmUI.data_type.BATTERY,
                  // show_level: hmUI.show_level.ONLY_NORMAL,
                // });
                break;

              case 1300002:
                hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 130,
              src: 'zn_error.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;

              case hmUI.edit_type.WEATHER:
                hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                  x: 209,
                  y: 130,
                  image_array: ["pog_01.png","pog_02.png","pog_03.png","pog_04.png","pog_05.png","pog_06.png","pog_07.png","pog_08.png","pog_09.png","pog_10.png","pog_11.png","pog_12.png","pog_13.png","pog_14.png","pog_15.png","pog_16.png","pog_17.png","pog_18.png","pog_19.png","pog_20.png","pog_21.png","pog_22.png","pog_23.png","pog_24.png","pog_25.png","pog_26.png","pog_27.png","pog_28.png","pog_29.png"],
                  image_length: 29,
                  type: hmUI.data_type.WEATHER_CURRENT,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                break;
            }; // end switch

            mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'ed_bg_i.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            fg_mask = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_FG_MASK, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'ed_fg_i.png',
              show_level: hmUI.show_level.ONLY_EDIT,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wS.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 22,
                    posY: 113,
                    path: 'wH.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 13,
                    posY: 179,
                    path: 'wM.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 227,
                    centerY: 227,
                    posX: 9,
                    posY: 200,
                    path: 'wS2.png',
                  },
                  hour: {
                    centerX: 227,
                    centerY: 227,
                    posX: 22,
                    posY: 113,
                    path: 'wH2.png',
                  },
                  minute: {
                    centerX: 227,
                    centerY: 227,
                    posX: 13,
                    posY: 179,
                    path: 'wM2.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
              ],
              count: 2,
              default_id: 1,
              fg: 'Hf.png',
              tips_x: 159,
              tips_y: 338,
              tips_bg: 'ed_wyb.png',
            });
            const screenTypeForETP = hmSetting.getScreenType();
            const aodModel = screenTypeForETP == hmSetting.screen_type.AOD;
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, !aodModel);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 25,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 331,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 72,
              y: 64,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 283,
              y: 64,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 177,
              y: 31,
              w: 100,
              h: 100,
              src: 'zn_error.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 227;
                  let start_y_idle_battery = 285;
                  let lenght_ls_idle_battery = 100;
                  let line_width_ls_idle_battery = 5;
                  let color_ls_idle_battery = 0xFF3E3EFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery = 6;
                  let pointer_offset_y_ls_idle_battery = 11;
                  idle_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery + lenght_ls_idle_battery - pointer_offset_x_ls_idle_battery,
                    y: start_y_idle_battery_draw + line_width_ls_idle_battery / 2 - pointer_offset_y_ls_idle_battery,
                    src: 'ik_aku.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                  
                  // idle_battery_linear_scale_mirror
                  // initial parameters
                  let start_x_idle_battery_mirror = 227;
                  let start_y_idle_battery_mirror = 285;
                  let lenght_ls_idle_battery_mirror = -100;
                  let line_width_ls_idle_battery_mirror =5;
                  let color_ls_idle_battery_mirror = 0xFF3E3EFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw_mirror = start_x_idle_battery_mirror;
                  let start_y_idle_battery_draw_mirror = start_y_idle_battery_mirror;
                  lenght_ls_idle_battery_mirror = lenght_ls_idle_battery_mirror * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw_mirror = lenght_ls_idle_battery_mirror;
                  let line_width_ls_idle_battery_draw_mirror = line_width_ls_idle_battery_mirror;
                  if (lenght_ls_idle_battery_mirror < 0){
                    lenght_ls_idle_battery_draw_mirror = -lenght_ls_idle_battery_mirror;
                    start_x_idle_battery_draw_mirror = start_x_idle_battery - lenght_ls_idle_battery_draw_mirror;
                  };
                  
                  idle_battery_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw_mirror,
                    y: start_y_idle_battery_draw_mirror,
                    w: lenght_ls_idle_battery_draw_mirror,
                    h: line_width_ls_idle_battery_draw_mirror,
                    color: color_ls_idle_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_idle_battery_mirror = 6;
                  let pointer_offset_y_ls_idle_battery_mirror = 11;
                  idle_battery_linear_scale_pointer_img_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_mirror + lenght_ls_idle_battery_mirror - pointer_offset_x_ls_idle_battery_mirror,
                    y: start_y_idle_battery_draw_mirror + line_width_ls_idle_battery_mirror / 2 - pointer_offset_y_ls_idle_battery_mirror,
                    src: 'ik_aku.png',
                    show_level: hmUI.show_level.ONLY_AOD,
                  });
                };

                console.log('update editable linear_scale BATTERY');
                let progress_ls_editableZone_5_battery = progressBattery;

                if (editableZone_5_battery_linear_scale) {

                  // editableZone_5_battery_linear_scale
                  // initial parameters
                  let start_x_editableZone_5_battery = 227;
                  let start_y_editableZone_5_battery = 149;
                  let lenght_ls_editableZone_5_battery = 63;
                  let line_width_ls_editableZone_5_battery = 8;
                  let color_ls_editableZone_5_battery = 0xFF4D4DFF;
                  
                  // calculated parameters
                  let start_x_editableZone_5_battery_draw = start_x_editableZone_5_battery;
                  let start_y_editableZone_5_battery_draw = start_y_editableZone_5_battery;
                  lenght_ls_editableZone_5_battery = lenght_ls_editableZone_5_battery * progress_ls_editableZone_5_battery;
                  let lenght_ls_editableZone_5_battery_draw = lenght_ls_editableZone_5_battery;
                  let line_width_ls_editableZone_5_battery_draw = line_width_ls_editableZone_5_battery;
                  if (lenght_ls_editableZone_5_battery < 0){
                    lenght_ls_editableZone_5_battery_draw = -lenght_ls_editableZone_5_battery;
                    start_x_editableZone_5_battery_draw = start_x_editableZone_5_battery - lenght_ls_editableZone_5_battery_draw;
                  };
                  
                  editableZone_5_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_editableZone_5_battery_draw,
                    y: start_y_editableZone_5_battery_draw,
                    w: lenght_ls_editableZone_5_battery_draw,
                    h: line_width_ls_editableZone_5_battery_draw,
                    color: color_ls_editableZone_5_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_editableZone_5_battery = 6;
                  let pointer_offset_y_ls_editableZone_5_battery = 11;
                  editableZone_5_battery_linear_scale_pointer_img.setProperty(hmUI.prop.MORE, {
                    x: start_x_editableZone_5_battery + lenght_ls_editableZone_5_battery - pointer_offset_x_ls_editableZone_5_battery,
                    y: start_y_editableZone_5_battery_draw + line_width_ls_editableZone_5_battery / 2 - pointer_offset_y_ls_editableZone_5_battery,
                    src: 'ik_aku.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                  
                  // editableZone_5_battery_linear_scale_mirror
                  // initial parameters
                  let start_x_editableZone_5_battery_mirror = 227;
                  let start_y_editableZone_5_battery_mirror = 149;
                  let lenght_ls_editableZone_5_battery_mirror = -63;
                  let line_width_ls_editableZone_5_battery_mirror =8;
                  let color_ls_editableZone_5_battery_mirror = 0xFF4D4DFF;
                  
                  // calculated parameters
                  let start_x_editableZone_5_battery_draw_mirror = start_x_editableZone_5_battery_mirror;
                  let start_y_editableZone_5_battery_draw_mirror = start_y_editableZone_5_battery_mirror;
                  lenght_ls_editableZone_5_battery_mirror = lenght_ls_editableZone_5_battery_mirror * progress_ls_editableZone_5_battery;
                  let lenght_ls_editableZone_5_battery_draw_mirror = lenght_ls_editableZone_5_battery_mirror;
                  let line_width_ls_editableZone_5_battery_draw_mirror = line_width_ls_editableZone_5_battery_mirror;
                  if (lenght_ls_editableZone_5_battery_mirror < 0){
                    lenght_ls_editableZone_5_battery_draw_mirror = -lenght_ls_editableZone_5_battery_mirror;
                    start_x_editableZone_5_battery_draw_mirror = start_x_editableZone_5_battery - lenght_ls_editableZone_5_battery_draw_mirror;
                  };
                  
                  editableZone_5_battery_linear_scale_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_editableZone_5_battery_draw_mirror,
                    y: start_y_editableZone_5_battery_draw_mirror,
                    w: lenght_ls_editableZone_5_battery_draw_mirror,
                    h: line_width_ls_editableZone_5_battery_draw_mirror,
                    color: color_ls_editableZone_5_battery,
                  });
                  
                  // pointers parameters
                  let pointer_offset_x_ls_editableZone_5_battery_mirror = 6;
                  let pointer_offset_y_ls_editableZone_5_battery_mirror = 11;
                  editableZone_5_battery_linear_scale_pointer_img_mirror.setProperty(hmUI.prop.MORE, {
                    x: start_x_editableZone_5_battery_mirror + lenght_ls_editableZone_5_battery_mirror - pointer_offset_x_ls_editableZone_5_battery_mirror,
                    y: start_y_editableZone_5_battery_draw_mirror + line_width_ls_editableZone_5_battery_mirror / 2 - pointer_offset_y_ls_editableZone_5_battery_mirror,
                    src: 'ik_aku.png',
                    show_level: hmUI.show_level.ONLY_NORMAL,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
