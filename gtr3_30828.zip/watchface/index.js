﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["BAT_00.png","BAT_01.png","BAT_02.png","BAT_03.png","BAT_04.png","BAT_05.png","BAT_06.png","BAT_07.png","BAT_08.png","BAT_09.png","BAT_10.png","BAT_11.png","BAT_12.png","BAT_13.png","BAT_14.png","BAT_15.png","BAT_16.png","BAT_17.png","BAT_18.png","BAT_19.png"],
              image_length: 20,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 201,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 201,
              day_sc_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_tc_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_en_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_zero: 0,
              day_space: -24,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 231,
              font_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              padding: false,
              h_space: -24,
              unit_sc: 'STCC_DEG.png',
              unit_tc: 'STCC_DEG.png',
              unit_en: 'STCC_DEG.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["STEPS_01.png","STEPS_02.png","STEPS_03.png","STEPS_04.png","STEPS_05.png","STEPS_06.png","STEPS_07.png","STEPS_08.png","STEPS_09.png","STEPS_10.png","STEPS_11.png","STEPS_12.png","STEPS_13.png","STEPS_14.png","STEPS_15.png","STEPS_16.png","STEPS_17.png","STEPS_18.png","STEPS_19.png","STEPS_20.png","STEPS_21.png","STEPS_22.png","STEPS_23.png","STEPS_24.png","STEPS_25.png","STEPS_26.png","STEPS_27.png","STEPS_28.png","STEPS_29.png","STEPS_30.png","STEPS_31.png","STEPS_32.png"],
              image_length: 32,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","d7.png"],
              week_tc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","d7.png"],
              week_sc: ["D1.png","D2.png","D3.png","D4.png","D5.png","D6.png","d7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -42,
              hour_startY: 36,
              hour_array: ["STC_0.png","STC_1.png","STC_2.png","STC_3.png","STC_4.png","STC_5.png","STC_6.png","STC_7.png","STC_8.png","STC_9.png"],
              hour_zero: 1,
              hour_space: -370,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: -42,
              minute_startY: 192,
              minute_array: ["STC_0.png","STC_1.png","STC_2.png","STC_3.png","STC_4.png","STC_5.png","STC_6.png","STC_7.png","STC_8.png","STC_9.png"],
              minute_zero: 1,
              minute_space: -370,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 294,
              second_startY: 231,
              second_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              second_zero: 1,
              second_space: -23,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 201,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 148,
              day_startY: 201,
              day_sc_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_tc_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_en_array: ["STCC_0.png","STCC_1.png","STCC_2.png","STCC_3.png","STCC_4.png","STCC_5.png","STCC_6.png","STCC_7.png","STCC_8.png","STCC_9.png"],
              day_zero: 0,
              day_space: -24,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              week_tc: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              week_sc: ["DD1.png","DD2.png","DD3.png","DD4.png","DD5.png","DD6.png","DD7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -42,
              hour_startY: 36,
              hour_array: ["STC_0.png","STC_1.png","STC_2.png","STC_3.png","STC_4.png","STC_5.png","STC_6.png","STC_7.png","STC_8.png","STC_9.png"],
              hour_zero: 1,
              hour_space: -370,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: -42,
              minute_startY: 192,
              minute_array: ["STC_0.png","STC_1.png","STC_2.png","STC_3.png","STC_4.png","STC_5.png","STC_6.png","STC_7.png","STC_8.png","STC_9.png"],
              minute_zero: 1,
              minute_space: -370,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  