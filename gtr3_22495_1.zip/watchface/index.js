﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_year_separator_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_year_separator_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              second_cover_path: 'Seconds_Foreground.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 361,
              font_array: ["weather_number_001.png","weather_number_002.png","weather_number_003.png","weather_number_004.png","weather_number_005.png","weather_number_006.png","weather_number_007.png","weather_number_008.png","weather_number_009.png","weather_number_010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_number_041.png',
              unit_tc: 'weather_number_041.png',
              unit_en: 'weather_number_041.png',
              negative_image: 'weather_number_040.png',
              invalid_image: 'weather_number_040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 328,
              image_array: ["weather_number_011.png","weather_number_012.png","weather_number_013.png","weather_number_014.png","weather_number_015.png","weather_number_016.png","weather_number_017.png","weather_number_018.png","weather_number_019.png","weather_number_020.png","weather_number_021.png","weather_number_022.png","weather_number_023.png","weather_number_024.png","weather_number_025.png","weather_number_026.png","weather_number_027.png","weather_number_028.png","weather_number_029.png","weather_number_030.png","weather_number_031.png","weather_number_032.png","weather_number_033.png","weather_number_034.png","weather_number_035.png","weather_number_036.png","weather_number_037.png","weather_number_038.png","weather_number_039.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 188,
              center_y: 298,
              x: 11,
              y: 59,
              start_angle: 513,
              end_angle: 388,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 288,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 292,
              image_array: ["zone_01.png","zone_02.png","zone_03.png","zone_04.png","zone_05.png","zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 244,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Act_number_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 19,
              y: 242,
              src: 'Dis_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 194,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 190,
              src: 'Kcal_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 188,
              center_y: 154,
              x: 11,
              y: 59,
              start_angle: 541,
              end_angle: 359,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 144,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 88,
              image_array: ["moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 161,
              year_startY: 41,
              year_sc_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_tc_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_en_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 38,
              src: 'YEAR_ICON.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 11,
              month_sc_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_tc_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_en_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 85,
              y: 91,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 235,
              day_startY: 19,
              day_sc_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_tc_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_en_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 63,
              src: 'BluetoothOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 283,
              y: 331,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 424,
              font_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_number_11.png',
              unit_tc: 'Batt_number_11.png',
              unit_en: 'Batt_number_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 143,
              y: 395,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 394,
              am_y: 199,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 394,
              pm_y: 199,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 283,
              hour_startY: 142,
              hour_array: ["H_M_number_001.png","H_M_number_002.png","H_M_number_003.png","H_M_number_004.png","H_M_number_005.png","H_M_number_006.png","H_M_number_007.png","H_M_number_008.png","H_M_number_009.png","H_M_number_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 278,
              minute_startY: 237,
              minute_array: ["H_M_number_001.png","H_M_number_002.png","H_M_number_003.png","H_M_number_004.png","H_M_number_005.png","H_M_number_006.png","H_M_number_007.png","H_M_number_008.png","H_M_number_009.png","H_M_number_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 318,
              second_startY: 323,
              second_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 387,
              y: 73,
              w: 53,
              h: 80,
              src: 'A_CLICK.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 388,
              y: 301,
              w: 46,
              h: 69,
              src: 'A_CLICK.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 277,
              y: 324,
              w: 43,
              h: 35,
              src: 'A_CLICK.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 82,
              w: 46,
              h: 39,
              src: 'A_CLICK.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 352,
              w: 47,
              h: 35,
              src: 'A_CLICK.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 17,
              y: 204,
              w: 46,
              h: 48,
              src: 'A_CLICK.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 279,
              w: 49,
              h: 43,
              src: 'A_CLICK.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 16,
              y: 295,
              w: 60,
              h: 69,
              src: 'A_CLICK.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 11,
              y: 84,
              w: 54,
              h: 69,
              src: 'A_CLICK.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds_hand.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              second_cover_path: 'Seconds_Foreground.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 133,
              y: 361,
              font_array: ["weather_number_001.png","weather_number_002.png","weather_number_003.png","weather_number_004.png","weather_number_005.png","weather_number_006.png","weather_number_007.png","weather_number_008.png","weather_number_009.png","weather_number_010.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'weather_number_041.png',
              unit_tc: 'weather_number_041.png',
              unit_en: 'weather_number_041.png',
              negative_image: 'weather_number_040.png',
              invalid_image: 'weather_number_040.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 84,
              y: 328,
              image_array: ["weather_number_011.png","weather_number_012.png","weather_number_013.png","weather_number_014.png","weather_number_015.png","weather_number_016.png","weather_number_017.png","weather_number_018.png","weather_number_019.png","weather_number_020.png","weather_number_021.png","weather_number_022.png","weather_number_023.png","weather_number_024.png","weather_number_025.png","weather_number_026.png","weather_number_027.png","weather_number_028.png","weather_number_029.png","weather_number_030.png","weather_number_031.png","weather_number_032.png","weather_number_033.png","weather_number_034.png","weather_number_035.png","weather_number_036.png","weather_number_037.png","weather_number_038.png","weather_number_039.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 188,
              center_y: 298,
              x: 11,
              y: 59,
              start_angle: 513,
              end_angle: 388,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 106,
              y: 288,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 5,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 47,
              y: 292,
              image_array: ["zone_01.png","zone_02.png","zone_03.png","zone_04.png","zone_05.png","zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 244,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 3,
              dot_image: 'Act_number_011.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 19,
              y: 242,
              src: 'Dis_icon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 58,
              y: 194,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 21,
              y: 190,
              src: 'Kcal_icon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer.png',
              center_x: 188,
              center_y: 154,
              x: 11,
              y: 59,
              start_angle: 541,
              end_angle: 359,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 61,
              y: 144,
              font_array: ["Act_number_001.png","Act_number_002.png","Act_number_003.png","Act_number_004.png","Act_number_005.png","Act_number_006.png","Act_number_007.png","Act_number_008.png","Act_number_009.png","Act_number_010.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 88,
              image_array: ["moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png","moon_8.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 161,
              year_startY: 41,
              year_sc_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_tc_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_en_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              year_zero: 1,
              year_space: 3,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_year_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 137,
              y: 38,
              src: 'YEAR_ICON.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 162,
              month_startY: 11,
              month_sc_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_tc_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_en_array: ["month_001.png","month_002.png","month_003.png","month_004.png","month_005.png","month_006.png","month_007.png","month_008.png","month_009.png","month_010.png","month_011.png","month_012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 85,
              y: 91,
              week_en: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_tc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              week_sc: ["weekday_1.png","weekday_2.png","weekday_3.png","weekday_4.png","weekday_5.png","weekday_6.png","weekday_7.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 235,
              day_startY: 19,
              day_sc_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_tc_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_en_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 63,
              src: 'BluetoothOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 283,
              y: 331,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 424,
              font_array: ["Batt_number_001.png","Batt_number_002.png","Batt_number_003.png","Batt_number_004.png","Batt_number_005.png","Batt_number_006.png","Batt_number_007.png","Batt_number_008.png","Batt_number_009.png","Batt_number_010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Batt_number_11.png',
              unit_tc: 'Batt_number_11.png',
              unit_en: 'Batt_number_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 143,
              y: 395,
              image_array: ["Batt_01.png","Batt_02.png","Batt_03.png","Batt_04.png","Batt_05.png","Batt_06.png","Batt_07.png","batt_08.png","Batt_09.png","Batt_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 394,
              am_y: 199,
              am_sc_path: 'Time_AM.png',
              am_en_path: 'Time_AM.png',
              pm_x: 394,
              pm_y: 199,
              pm_sc_path: 'Time_PM.png',
              pm_en_path: 'Time_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 283,
              hour_startY: 142,
              hour_array: ["H_M_number_001.png","H_M_number_002.png","H_M_number_003.png","H_M_number_004.png","H_M_number_005.png","H_M_number_006.png","H_M_number_007.png","H_M_number_008.png","H_M_number_009.png","H_M_number_010.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 278,
              minute_startY: 237,
              minute_array: ["H_M_number_001.png","H_M_number_002.png","H_M_number_003.png","H_M_number_004.png","H_M_number_005.png","H_M_number_006.png","H_M_number_007.png","H_M_number_008.png","H_M_number_009.png","H_M_number_010.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 318,
              second_startY: 323,
              second_array: ["S_number_001.png","S_number_002.png","S_number_003.png","S_number_004.png","S_number_005.png","S_number_006.png","S_number_007.png","S_number_008.png","S_number_009.png","S_number_010.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  