﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_second_separator_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 135,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 316,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 314,
              src: '030.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 226,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 231,
              image_array: ["024.png","025.png","026.png","027.png","028.png","029.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 362,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 118,
              day_sc_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_tc_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_en_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 218,
              y: 84,
              week_en: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              week_tc: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              week_sc: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 293,
              hour_startY: 226,
              hour_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 338,
              minute_startY: 226,
              minute_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 383,
              second_startY: 226,
              second_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 216,
              src: '023.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 216,
              src: '022.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '001.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '002.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 22,
              hour_posY: 135,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '003.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 22,
              minute_posY: 213,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '004.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 28,
              second_posY: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 208,
              y: 316,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 258,
              y: 314,
              src: '030.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 226,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 69,
              y: 231,
              image_array: ["024.png","025.png","026.png","027.png","028.png","029.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 204,
              y: 362,
              font_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 228,
              day_startY: 118,
              day_sc_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_tc_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_en_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 218,
              y: 84,
              week_en: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              week_tc: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              week_sc: ["005.png","006.png","007.png","008.png","009.png","010.png","011.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 293,
              hour_startY: 226,
              hour_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 338,
              minute_startY: 226,
              minute_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 383,
              second_startY: 226,
              second_array: ["012.png","013.png","014.png","015.png","016.png","017.png","018.png","019.png","020.png","021.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 326,
              y: 216,
              src: '023.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 371,
              y: 216,
              src: '022.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  