try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        let normal$_$text_7dbabe2365b6478dbd19bc180d756256 = '';
        let dateFormat = '';
        let dateFormatMap = '';
        let batterySensor = '';
        let timeSensor = '';
        const logger = Logger.getLogger('watchface6');
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '2.png',
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                normal$_$text_7dbabe2365b6478dbd19bc180d756256 = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 120,
                    y: 394,
                    w: 100,
                    h: 40,
                    text: '[BATT_PER]% [WEEK_EN_S] [DAY_Z]/[MON_Z]/[YEAR]',
                    color: '0xFF070707',
                    text_size: 24,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.LEFT,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 30,
                    hour_posY: 172,
                    hour_path: '3.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 35,
                    minute_posY: 222,
                    minute_path: '4.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 23,
                    second_posY: 228,
                    second_path: '5.png',
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_NORMAL
                });
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: '6.png',
                    show_level: hmUI.show_level.ONLY_AOD
                });
                hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 30,
                    hour_posY: 172,
                    hour_path: '7.png',
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 35,
                    minute_posY: 222,
                    minute_path: '8.png',
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: false,
                    show_level: hmUI.show_level.ONLY_AOD
                });
                if (!batterySensor) {
                    batterySensor = hmSensor.createSensor(hmSensor.id.BATTERY);
                }
                if (!timeSensor) {
                    timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
                }
                batterySensor.addEventListener(hmSensor.event.CHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }% ${ String(timeSensor.month).padStart(2, '0') } ${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }% ${ String(timeSensor.month).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }% ${ String(timeSensor.day).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                }), timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function () {
                    dateFormat = hmSetting.getDateFormat();
                    dateFormatMap = [
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }% ${ String(timeSensor.month).padStart(2, '0') } ${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }% ${ String(timeSensor.month).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        },
                        () => {
                            normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }% ${ String(timeSensor.day).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                        }
                    ];
                    dateFormatMap[dateFormat]();
                });
                hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        dateFormat = hmSetting.getDateFormat();
                        dateFormatMap = [
                            () => {
                                normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ timeSensor.year }% ${ String(timeSensor.month).padStart(2, '0') } ${ String(timeSensor.day).padStart(2, '0') }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.day).padStart(2, '0') }% ${ String(timeSensor.month).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                            },
                            () => {
                                normal$_$text_7dbabe2365b6478dbd19bc180d756256.setProperty(hmUI.prop.MORE, { text: `${ String(timeSensor.month).padStart(2, '0') }% ${ String(timeSensor.day).padStart(2, '0') } ${ timeSensor.year }/${ String(timeSensor.month).padStart(2, '0') }/${ timeSensor.year }` });
                            }
                        ];
                        dateFormatMap[dateFormat]();
                    }
                });
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}