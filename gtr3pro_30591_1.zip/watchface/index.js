﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_battery_text_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'BAGRAUNDOK.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 96,
              week_en: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              week_tc: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              week_sc: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 214,
              day_startY: 136,
              day_sc_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_tc_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_en_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_zero: 1,
              day_space: -7,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 401,
              font_array: ["BAT001.png","BAT002.png","BAT003.png","BAT004.png","BAT005.png","BAT006.png","BAT007.png","BAT008.png","BAT009.png","BAT010.png"],
              padding: false,
              h_space: -10,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 205,
              am_y: 330,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 205,
              pm_y: 330,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 138,
              hour_startY: 355,
              hour_array: ["TIMEDEY001.png","TIMEDEY002.png","TIMEDEY003.png","TIMEDEY004.png","TIMEDEY005.png","TIMEDEY006.png","TIMEDEY007.png","TIMEDEY008.png","TIMEDEY009.png","TIMEDEY010.png"],
              hour_zero: 1,
              hour_space: -17,
              hour_align: hmUI.align.LEFT,

              minute_startX: 239,
              minute_startY: 355,
              minute_array: ["TIMEDEY001.png","TIMEDEY002.png","TIMEDEY003.png","TIMEDEY004.png","TIMEDEY005.png","TIMEDEY006.png","TIMEDEY007.png","TIMEDEY008.png","TIMEDEY009.png","TIMEDEY010.png"],
              minute_zero: 1,
              minute_space: -17,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HOURDEY.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 161,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MINITDEY.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_S.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 30,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'step1ok.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 211,
              day_startY: 136,
              day_sc_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_tc_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_en_array: ["D001.png","D002.png","D003.png","D004.png","D005.png","D006.png","D007.png","D008.png","D009.png","D010.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 155,
              y: 96,
              week_en: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              week_tc: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              week_sc: ["DEN001.png","DEN002.png","DEN003.png","DEN004.png","DEN005.png","DEN006.png","DEN007.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 400,
              font_array: ["BAT001.png","BAT002.png","BAT003.png","BAT004.png","BAT005.png","BAT006.png","BAT007.png","BAT008.png","BAT009.png","BAT010.png"],
              padding: false,
              h_space: -5,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'telia.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 364,
              font_array: ["S001.png","S002.png","S003.png","S004.png","S005.png","S006.png","S007.png","S008.png","S009.png","S010.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'HOURNITE.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 159,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'MINITNITE.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
