﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_altimeter_icon_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_altimeter_icon_img = ''
        let idle_altimeter_text_text_img = ''
        let idle_altimeter_text_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001_MOD.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 371,
              y: 133,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Degree_2.png',
              unit_tc: 'Degree_2.png',
              unit_en: 'Degree_2.png',
              negative_image: 'Minus.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 356,
              y: 79,
              image_array: ["Weather(29.5).png","Weather(30).png","Weather(31).png","Weather(32).png","Weather(33).png","Weather(34).png","Weather(35).png","Weather(36).png","Weather(37).png","Weather(38).png","Weather(39).png","Weather(40).png","Weather(41).png","Weather(42).png","Weather(43).png","Weather(44).png","Weather(45).png","Weather(46).png","Weather(47).png","Weather(48).png","Weather(49).png","Weather(50).png","Weather(51).png","Weather(52).png","Weather(53).png","Weather(54).png","Weather(55).png","Weather(56).png","Weather(57).png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 50,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              dot_image: 'POINT_2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 50,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              dot_image: 'POINT_2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 80,
              src: 'BM_(1).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 30,
              y: 194,
              src: 'AOD_Non_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 12,
              y: 248,
              src: 'BM_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 316,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 320,
              image_array: ["Battery_(1).png","Battery_(2).png","Battery_(3).png","Battery_(4).png","Battery_(5).png","Battery_(6).png","Battery_(7).png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 400,
              src: 'Barometer.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 404,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 410,
              src: 'Barometer_3_Cropped.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 63,
              y: 133,
              week_en: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_tc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_sc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 286,
              year_startY: 133,
              year_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 133,
              month_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 133,
              src: 'Minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 133,
              day_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 133,
              src: 'Minus.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 312,
              src: 'Heart_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 316,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 308,
              src: 'Steps_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 316,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 400,
              am_y: 195,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 400,
              pm_y: 195,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 183,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 0,
              hour_space: 6,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 250,
              minute_startY: 183,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 403,
              second_startY: 254,
              second_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001_MOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 371,
              y: 133,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'Degree_2.png',
              unit_tc: 'Degree_2.png',
              unit_en: 'Degree_2.png',
              negative_image: 'Minus.png',
              invalid_image: 'Err.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 356,
              y: 79,
              image_array: ["Weather(29.5).png","Weather(30).png","Weather(31).png","Weather(32).png","Weather(33).png","Weather(34).png","Weather(35).png","Weather(36).png","Weather(37).png","Weather(38).png","Weather(39).png","Weather(40).png","Weather(41).png","Weather(42).png","Weather(43).png","Weather(44).png","Weather(45).png","Weather(46).png","Weather(47).png","Weather(48).png","Weather(49).png","Weather(50).png","Weather(51).png","Weather(52).png","Weather(53).png","Weather(54).png","Weather(55).png","Weather(56).png","Weather(57).png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 157,
              y: 50,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              dot_image: 'POINT_2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 247,
              y: 50,
              font_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              padding: false,
              h_space: 1,
              dot_image: 'POINT_2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 80,
              y: 80,
              src: 'BM_(1).png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 30,
              y: 194,
              src: 'AOD_Non_BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 12,
              y: 248,
              src: 'BM_(2).png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 122,
              y: 316,
              font_array: ["Top_Mini001.png","Top_Mini002.png","Top_Mini003.png","Top_Mini004.png","Top_Mini005.png","Top_Mini006.png","Top_Mini007.png","Top_Mini008.png","Top_Mini009.png","Top_Mini010.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 80,
              y: 320,
              image_array: ["Battery_(1).png","Battery_(2).png","Battery_(3).png","Battery_(4).png","Battery_(5).png","Battery_(6).png","Battery_(7).png"],
              image_length: 7,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 155,
              y: 400,
              src: 'Barometer.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 250,
              y: 404,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 410,
              src: 'Barometer_3_Cropped.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 63,
              y: 133,
              week_en: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_tc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              week_sc: ["Day01.png","Day02.png","Day03.png","Day04.png","Day05.png","Day06.png","Day07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 286,
              year_startY: 133,
              year_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              year_zero: 1,
              year_space: 1,
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 228,
              month_startY: 133,
              month_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 133,
              src: 'Minus.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 160,
              day_startY: 133,
              day_sc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_tc_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_en_array: ["Botton_Mini001.png","Botton_Mini002.png","Botton_Mini003.png","Botton_Mini004.png","Botton_Mini005.png","Botton_Mini006.png","Botton_Mini007.png","Botton_Mini008.png","Botton_Mini009.png","Botton_Mini010.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 205,
              y: 133,
              src: 'Minus.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 331,
              y: 312,
              src: 'Heart_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 316,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 193,
              y: 308,
              src: 'Steps_3.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 316,
              font_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 400,
              am_y: 195,
              am_sc_path: 'AM.png',
              am_en_path: 'AM.png',
              pm_x: 400,
              pm_y: 195,
              pm_sc_path: 'PM.png',
              pm_en_path: 'PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 78,
              hour_startY: 183,
              hour_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              hour_zero: 0,
              hour_space: 6,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 250,
              minute_startY: 183,
              minute_array: ["Big001.png","Big002.png","Big003.png","Big004.png","Big005.png","Big006.png","Big007.png","Big008.png","Big009.png","Big010.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 403,
              second_startY: 254,
              second_array: ["Mini001.png","Mini002.png","Mini003.png","Mini004.png","Mini005.png","Mini006.png","Mini007.png","Mini008.png","Mini009.png","Mini010.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 244,
              y: 180,
              w: 150,
              h: 120,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 70,
              y: 180,
              w: 150,
              h: 120,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 48,
              w: 80,
              h: 70,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 20,
              y: 245,
              w: 40,
              h: 40,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 0,
              w: 200,
              h: 110,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 370,
              w: 200,
              h: 110,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 357,
              y: 70,
              w: 100,
              h: 100,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 310,
              w: 105,
              h: 50,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 310,
              w: 125,
              h: 50,
              src: 'Blank_Image_(0107).png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
