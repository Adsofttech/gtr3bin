﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_circle_scale = ''
        let normal_pai_weekly_text_img = ''
        let normal_heart_rate_circle_scale = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_calorie_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_pai_circle_scale = ''
        let idle_heart_rate_circle_scale = ''
        let idle_calorie_circle_scale = ''
        let idle_step_circle_scale = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 280,
              y: 60,
              image_array: ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 60,
              src: '10.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 60,
              src: '9.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 180,
              y: 60,
              src: '11.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 220,
              y: 60,
              week_en: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              week_tc: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              week_sc: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 90,
              // end_angle: 450,
              // radius: 218,
              // line_width: 20,
              // color: 0xFFA7109F,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const pai = hmSensor.createSensor(hmSensor.id.PAI);
            pai.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 370,
              y: 186,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 91,
              // line_width: 20,
              // color: 0xFFFF80C0,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const heart_rate = hmSensor.createSensor(hmSensor.id.HEART);
            heart_rate.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 190,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 540,
              // radius: 114,
              // line_width: 20,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 63,
              y: 268,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 240,
              // line_width: 20,
              // color: 0xFF049CEE,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 268,
              font_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 259,
              day_startY: 405,
              day_sc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_tc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_en_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 186,
              month_startY: 405,
              month_sc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              month_tc_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              month_en_array: ["57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '95.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 12,
              hour_posY: 232,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '96.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 10,
              minute_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '97.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
              second_posY: 231,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            // idle_pai_weekly_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 90,
              // end_angle: 450,
              // radius: 197,
              // line_width: 40,
              // color: 0xFF5D5D5D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.PAI_WEEKLY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_pai_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            // idle_heart_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 113,
              // line_width: 40,
              // color: 0xFF5D5D5D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.HEART,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_heart_rate_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 180,
              // end_angle: 540,
              // radius: 155,
              // line_width: 40,
              // color: 0xFF5D5D5D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 240,
              // center_y: 240,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 239,
              // line_width: 40,
              // color: 0xFF5D5D5D,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 164,
              hour_startY: 110,
              hour_array: ["67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png","75.png","76.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 164,
              minute_startY: 250,
              minute_array: ["77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              minute_zero: 1,
              minute_space: 8,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '44.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 12,
              hour_posY: 232,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '45.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 10,
              minute_posY: 231,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '46.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 10,
              second_posY: 231,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales PAI');
                
                let valuePAI = pai.totalpai;
                let targetPAI = 100;
                let progressPAI = valuePAI/targetPAI;
                if (progressPAI > 1) progressPAI = 1;
                let progress_cs_normal_pai = progressPAI;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_pai_circle_scale
                  // initial parameters
                  let start_angle_normal_pai = 0;
                  let end_angle_normal_pai = 360;
                  let center_x_normal_pai = 240;
                  let center_y_normal_pai = 240;
                  let radius_normal_pai = 218;
                  let line_width_cs_normal_pai = 20;
                  let color_cs_normal_pai = 0xFFA7109F;
                  
                  // calculated parameters
                  let arcX_normal_pai = center_x_normal_pai - radius_normal_pai;
                  let arcY_normal_pai = center_y_normal_pai - radius_normal_pai;
                  let CircleWidth_normal_pai = 2 * radius_normal_pai;
                  let angle_offset_normal_pai = end_angle_normal_pai - start_angle_normal_pai;
                  angle_offset_normal_pai = angle_offset_normal_pai * progress_cs_normal_pai;
                  let end_angle_normal_pai_draw = start_angle_normal_pai + angle_offset_normal_pai;
                  
                  normal_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_pai,
                    y: arcY_normal_pai,
                    w: CircleWidth_normal_pai,
                    h: CircleWidth_normal_pai,
                    start_angle: start_angle_normal_pai,
                    end_angle: end_angle_normal_pai_draw,
                    color: color_cs_normal_pai,
                    line_width: line_width_cs_normal_pai,
                  });
                };

                console.log('update scales HEART');
                
                let valueHeartRate = heart_rate.last;
                let targetHeartRate = 179;
                let progressHeartRate = (valueHeartRate - 71)/(targetHeartRate - 71);
                if (progressHeartRate < 0) progressHeartRate = 0;
                if (progressHeartRate > 1) progressHeartRate = 1;
                let progress_cs_normal_heart_rate = progressHeartRate;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_normal_heart_rate = -90;
                  let end_angle_normal_heart_rate = 270;
                  let center_x_normal_heart_rate = 240;
                  let center_y_normal_heart_rate = 240;
                  let radius_normal_heart_rate = 91;
                  let line_width_cs_normal_heart_rate = 20;
                  let color_cs_normal_heart_rate = 0xFFFF80C0;
                  
                  // calculated parameters
                  let arcX_normal_heart_rate = center_x_normal_heart_rate - radius_normal_heart_rate;
                  let arcY_normal_heart_rate = center_y_normal_heart_rate - radius_normal_heart_rate;
                  let CircleWidth_normal_heart_rate = 2 * radius_normal_heart_rate;
                  let angle_offset_normal_heart_rate = end_angle_normal_heart_rate - start_angle_normal_heart_rate;
                  angle_offset_normal_heart_rate = angle_offset_normal_heart_rate * progress_cs_normal_heart_rate;
                  let end_angle_normal_heart_rate_draw = start_angle_normal_heart_rate + angle_offset_normal_heart_rate;
                  
                  normal_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_heart_rate,
                    y: arcY_normal_heart_rate,
                    w: CircleWidth_normal_heart_rate,
                    h: CircleWidth_normal_heart_rate,
                    start_angle: start_angle_normal_heart_rate,
                    end_angle: end_angle_normal_heart_rate_draw,
                    color: color_cs_normal_heart_rate,
                    line_width: line_width_cs_normal_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = 90;
                  let end_angle_normal_calorie = 450;
                  let center_x_normal_calorie = 240;
                  let center_y_normal_calorie = 240;
                  let radius_normal_calorie = 114;
                  let line_width_cs_normal_calorie = 20;
                  let color_cs_normal_calorie = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 270;
                  let center_x_normal_step = 240;
                  let center_y_normal_step = 240;
                  let radius_normal_step = 240;
                  let line_width_cs_normal_step = 20;
                  let color_cs_normal_step = 0xFF049CEE;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales PAI');
                let progress_cs_idle_pai = progressPAI;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_pai_circle_scale
                  // initial parameters
                  let start_angle_idle_pai = 0;
                  let end_angle_idle_pai = 360;
                  let center_x_idle_pai = 240;
                  let center_y_idle_pai = 240;
                  let radius_idle_pai = 197;
                  let line_width_cs_idle_pai = 40;
                  let color_cs_idle_pai = 0xFF5D5D5D;
                  
                  // calculated parameters
                  let arcX_idle_pai = center_x_idle_pai - radius_idle_pai;
                  let arcY_idle_pai = center_y_idle_pai - radius_idle_pai;
                  let CircleWidth_idle_pai = 2 * radius_idle_pai;
                  let angle_offset_idle_pai = end_angle_idle_pai - start_angle_idle_pai;
                  angle_offset_idle_pai = angle_offset_idle_pai * progress_cs_idle_pai;
                  let end_angle_idle_pai_draw = start_angle_idle_pai + angle_offset_idle_pai;
                  
                  idle_pai_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_pai,
                    y: arcY_idle_pai,
                    w: CircleWidth_idle_pai,
                    h: CircleWidth_idle_pai,
                    start_angle: start_angle_idle_pai,
                    end_angle: end_angle_idle_pai_draw,
                    color: color_cs_idle_pai,
                    line_width: line_width_cs_idle_pai,
                  });
                };

                console.log('update scales HEART');
                let progress_cs_idle_heart_rate = progressHeartRate;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_heart_rate_circle_scale
                  // initial parameters
                  let start_angle_idle_heart_rate = -90;
                  let end_angle_idle_heart_rate = 270;
                  let center_x_idle_heart_rate = 240;
                  let center_y_idle_heart_rate = 240;
                  let radius_idle_heart_rate = 113;
                  let line_width_cs_idle_heart_rate = 40;
                  let color_cs_idle_heart_rate = 0xFF5D5D5D;
                  
                  // calculated parameters
                  let arcX_idle_heart_rate = center_x_idle_heart_rate - radius_idle_heart_rate;
                  let arcY_idle_heart_rate = center_y_idle_heart_rate - radius_idle_heart_rate;
                  let CircleWidth_idle_heart_rate = 2 * radius_idle_heart_rate;
                  let angle_offset_idle_heart_rate = end_angle_idle_heart_rate - start_angle_idle_heart_rate;
                  angle_offset_idle_heart_rate = angle_offset_idle_heart_rate * progress_cs_idle_heart_rate;
                  let end_angle_idle_heart_rate_draw = start_angle_idle_heart_rate + angle_offset_idle_heart_rate;
                  
                  idle_heart_rate_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_heart_rate,
                    y: arcY_idle_heart_rate,
                    w: CircleWidth_idle_heart_rate,
                    h: CircleWidth_idle_heart_rate,
                    start_angle: start_angle_idle_heart_rate,
                    end_angle: end_angle_idle_heart_rate_draw,
                    color: color_cs_idle_heart_rate,
                    line_width: line_width_cs_idle_heart_rate,
                  });
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale
                  // initial parameters
                  let start_angle_idle_calorie = 90;
                  let end_angle_idle_calorie = 450;
                  let center_x_idle_calorie = 240;
                  let center_y_idle_calorie = 240;
                  let radius_idle_calorie = 155;
                  let line_width_cs_idle_calorie = 40;
                  let color_cs_idle_calorie = 0xFF5D5D5D;
                  
                  // calculated parameters
                  let arcX_idle_calorie = center_x_idle_calorie - radius_idle_calorie;
                  let arcY_idle_calorie = center_y_idle_calorie - radius_idle_calorie;
                  let CircleWidth_idle_calorie = 2 * radius_idle_calorie;
                  let angle_offset_idle_calorie = end_angle_idle_calorie - start_angle_idle_calorie;
                  angle_offset_idle_calorie = angle_offset_idle_calorie * progress_cs_idle_calorie;
                  let end_angle_idle_calorie_draw = start_angle_idle_calorie + angle_offset_idle_calorie;
                  
                  idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_calorie,
                    y: arcY_idle_calorie,
                    w: CircleWidth_idle_calorie,
                    h: CircleWidth_idle_calorie,
                    start_angle: start_angle_idle_calorie,
                    end_angle: end_angle_idle_calorie_draw,
                    color: color_cs_idle_calorie,
                    line_width: line_width_cs_idle_calorie,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 270;
                  let center_x_idle_step = 240;
                  let center_y_idle_step = 240;
                  let radius_idle_step = 239;
                  let line_width_cs_idle_step = 40;
                  let color_cs_idle_step = 0xFF5D5D5D;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            heart_rate.removeEventListener(heart.event.CURRENT, hrCurrListener);
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  