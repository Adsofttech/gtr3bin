﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_date_img_date_month_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_date_img_date_month_img = ''
        let idle_spo2_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'maind.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 278,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 278,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 311,
              month_startY: 132,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 126,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 80,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 302,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 126,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'ACT_01 (1).png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 80,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 184,
              day_sc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_tc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_en_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 172,
              font_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 170,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 61,
              y: 338,
              src: 'SYSTEM_BT_DISCONNECT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 104,
              y: 314,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 231,
              week_en: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              week_tc: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              week_sc: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 359,
              am_y: 351,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 359,
              pm_y: 351,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 123,
              hour_startY: 310,
              hour_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 310,
              minute_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 360,
              second_startY: 312,
              second_array: ["te01.png","te02.png","te03.png","te04.png","te05.png","te06.png","te07.png","te08.png","te09.png","te10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 304,
              src: 'Digital-shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds_hand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 245,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 419,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 416,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'maincc.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 188,
              y: 269,
              w: 100,
              h: 35,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 26,
              font_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'tem12.png',
              unit_tc: 'tem12.png',
              unit_en: 'tem12.png',
              negative_image: 'tem11.png',
              invalid_image: 'tem11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 10,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 352,
              y: 307,
              w: 53,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 225,
              y: 327,
              w: 32,
              h: 57,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 126,
              y: 310,
              w: 44,
              h: 84,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 93,
              y: 268,
              w: 300,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 194,
              y: 20,
              w: 87,
              h: 31,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 222,
              y: 118,
              w: 91,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 75,
              y: 167,
              w: 152,
              h: 35,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 121,
              y: 74,
              w: 116,
              h: 40,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 52,
              y: 300,
              w: 55,
              h: 55,
              src: 'A-empty.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'maind.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 94,
              y: 278,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 326,
              y: 278,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 2,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 311,
              month_startY: 132,
              month_sc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_tc_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_en_array: ["Month_icons_01.png","Month_icons_02.png","Month_icons_03.png","Month_icons_04.png","Month_icons_05.png","Month_icons_06.png","Month_icons_07.png","Month_icons_08.png","Month_icons_09.png","Month_icons_10.png","Month_icons_11.png","Month_icons_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 265,
              y: 126,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 274,
              y: 80,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 302,
              image_array: ["moon_1.png","moon_2.png","moon_3.png","moon_4.png","moon_5.png","moon_6.png","moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 126,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'ACT_01 (1).png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 143,
              y: 80,
              font_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 352,
              day_startY: 184,
              day_sc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_tc_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_en_array: ["DAY__01.png","DAY__02.png","DAY__03.png","DAY__04.png","DAY__05.png","DAY__06.png","DAY__07.png","DAY__08.png","DAY__09.png","DAY__10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 114,
              y: 172,
              font_array: ["t01.png","t02.png","t03.png","t04.png","t05.png","t06.png","t07.png","t08.png","t09.png","t10.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 197,
              y: 170,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 61,
              y: 338,
              src: 'SYSTEM_BT_DISCONNECT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 104,
              y: 314,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 61,
              y: 231,
              week_en: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              week_tc: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              week_sc: ["DayWeek_icon_07.png","DayWeek_icons_01.png","DayWeek_icons_02.png","DayWeek_icons_03.png","DayWeek_icons_04.png","DayWeek_icons_05.png","DayWeek_icons_06.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 359,
              am_y: 351,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 359,
              pm_y: 351,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 123,
              hour_startY: 310,
              hour_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 246,
              minute_startY: 310,
              minute_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 360,
              second_startY: 312,
              second_array: ["te01.png","te02.png","te03.png","te04.png","te05.png","te06.png","te07.png","te08.png","te09.png","te10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 304,
              src: 'Digital-shadow.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'seconds_hand.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 240,
              second_posY: 245,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 419,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 254,
              y: 416,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'maincc.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 188,
              y: 269,
              w: 100,
              h: 35,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 243,
              y: 26,
              font_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'tem12.png',
              unit_tc: 'tem12.png',
              unit_en: 'tem12.png',
              negative_image: 'tem11.png',
              invalid_image: 'tem11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 185,
              y: 10,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  