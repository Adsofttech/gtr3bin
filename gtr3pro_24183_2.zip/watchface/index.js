    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;

        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

		let normal$_$background$_$bg = ''
		let normal$_$date$_$img_date = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_image_progress_img_level = ''
		let	normal_calorie_image_progress_img_level = ''		

		let normal$_$weather$_$image_progress$_$img_level = ''
		let normal$_$temperature$_$current$_$text_img = ''
		let normal$_$humidity$_$text$_$text_img = ''

		let normal_humidity_image_progress_img_level = ''

		let normal_heart_rate_text_text_img = ''
		let normal_heart_rate_image_progress_img_level = ''

        let normal$_$system$_$disconnect$_$img = ''
        let normal$_$system$_$lock$_$img = ''
        let normal$_$system$_$clock$_$img = ''		
		let normal$_$system$_$dnd$_$img = ''
		
        let normal$_$analog_clock$_$time_pointer = ''

    let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 5000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    } 		
		const stepsArrayImg = new Array(5);
		const calorieArrayImg = new Array(3);

		
		let debugText = null;
        const ASCIIARRAY = ["12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png"];

		
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {
			 
			 
            normal$_$background$_$bg = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			  normal$_$date$_$img_date = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 280,
              year_startY: 90,
              year_sc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","20.png","21.png","22.png","23.png"],
              year_tc_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","20.png","21.png","22.png","23.png"],
              year_en_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","20.png","21.png","22.png","23.png"],
              year_align: hmUI.align.LEFT,
              year_zero: 1,
              year_space: 0,
              year_is_character: false,
              month_startX: 135,
              month_startY: 87,
              month_sc_array: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              month_tc_array: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              month_en_array: ["42.png","43.png","44.png","45.png","46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png"],
              month_align: hmUI.align.LEFT,
              month_zero: 0,
              month_follow: 0,
              month_space: 0,
              month_is_character: true,
              day_startX: 210,
              day_startY: 80,
              day_sc_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              day_tc_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              day_en_array: ["02.png","03.png","04.png","05.png","06.png","07.png","08.png","09.png","10.png","11.png"],
              day_align: hmUI.align.LEFT,
              day_zero: 1,
              day_follow: 0,
              day_space: 0,
              day_is_character: false,
			  
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 85,
              y: 20,
              week_en: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_tc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              week_sc: ["w1.png","w2.png","w3.png","w4.png","w5.png","w6.png","w7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 180,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              padding: false,
              h_space: 1,
              unit_sc: '68.png',
              unit_tc: '68.png',
              unit_en: '68.png',
 
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

 			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 140,
			  y: 180,
			  w: 480,
              h: 480,
			  src: '88.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 150,
              image_array: ["73.png","74.png","75.png","76.png","77.png","78.png","79.png","81.png","82.png","83.png","84.png","85.png","86.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			


            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 290,
              y: 275,
			  type: hmUI.data_type.HEART,
              font_array: ["32.png","33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 4,
              show_level: hmUI.show_level.ONLY_NORMAL,
              invalid_image: '54.png',
              padding: false,
              isCharacter: false
            });
			
           normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 142,
              y: 295,
              image_array: ["55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png"],
              image_length: 13,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });				

			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 140,
			  y: 275,
			  w: 480,
              h: 480,
			  src: '89.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 			
			
/*---------STEPS--------------*/			
			
            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 395,
              y: 120,
              image_array: ["r1.png","r2.png","r3.png","r4.png","r5.png","r6.png","r7.png","r8.png"],
              image_length: 8,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });			

			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 410,
			  y: 180,
			  w: 480,
              h: 480,
			  src: '91.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 

/*---------CALORIE--------------*/
						
            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 123,
              image_array: ["l1.png","l2.png","l3.png","l4.png","l5.png","l6.png","l7.png","l8.png"],
              image_length: 8,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });						
 
 			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 40,
			  y: 180,
			  w: 480,
              h: 480,
			  src: '92.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 
			

			normal$_$temperature$_$current$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 340,
              type: hmUI.data_type.WEATHER_CURRENT,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '69.png',
              unit_tc: '69.png',
              unit_en: '69.png',
              negative_image: '70.png',
              invalid_image: '90.png',
              padding: false,
              isCharacter: false
            });

            normal$_$humidity$_$text$_$text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 305,
              y: 340,
              type: hmUI.data_type.HUMIDITY,
              font_array: ["22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png"],
              align_h: hmUI.align.CENTER_H,
              h_space: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
              unit_sc: '98.png',
              unit_tc: '98.png',
              unit_en: '98.png',
              invalid_image: '70.png',
              padding: false,
              isCharacter: false
            });

            normal_humidity_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 107,
              y: 405,
              image_array: ["d0.png","d1.png","d2.png","d3.png"],
              image_length: 4,
              type: hmUI.data_type.HUMIDITY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

			normal$_$Text$_$text$_$text_img = hmUI.createWidget(hmUI.widget.IMG, {
			  x: 170,
			  y: 422,
			  w: 480,
              h: 480,
			  src: '97.png',			
			show_level: hmUI.show_level.ONLY_NORMAL,			
			}); 	
 
			normal$_$weather$_$image_progress$_$img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 195,
              y: 345,
              image_array: ["100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });	

	
              normal$_$system$_$disconnect$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 134,
              y: 385,
              src: 'btz.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal$_$system$_$clock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 90,
              y: 367,
              src: 'clock.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
            normal$_$system$_$lock$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 317,
              y: 383,
              src: 'lock.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal$_$system$_$dnd$_$img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 351,
              y: 367,
              src: 'dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
						

			stepsArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: -70,
				src: '12.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: -80,
				src: '13.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: -90,
				src: '14.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[3] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: -100,
				src: '15.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			stepsArrayImg[4] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: -110,
				src: '16.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 0,
				w: 100,
				h: 24,
				text_size: 24,
				char_space: 0,
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});


			var step = hmSensor.createSensor(hmSensor.id.STEP);
			let stepCurrent = step.current;
			let stepString = String(step.current);
			
			index = 0;
          for (var i = 0; i < 5; i++) {
						stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
						
						}
			if (stepCurrent < 10) {
				index = 1;
			}
				for (let char of stepString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 5) {
					break;
				}
				stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}	


			calorieArrayImg[0] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: 105,
				src: '12.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			calorieArrayImg[1] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: 95,
				src: '13.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			calorieArrayImg[2] = hmUI.createWidget(hmUI.widget.IMG, {
				x: 0,
				y: 0,
				w: 480,
				h: 480,
				pos_x: 240,
				pos_y: 370,
				center_x: 240,
				center_y: 240,
				angle: 85,
				src: '14.png',
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			debugText = hmUI.createWidget(hmUI.widget.TEXT, {
				x: 0,
				y: 0,
				w: 100,
				h: 24,
				text_size: 24,
				char_space: 0,
				color: 0xffffff,
				align_h: hmUI.align.LEFT,
				align_v: hmUI.align.CENTER_V,
			});


			var calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
			let calorieCurrent = calorie.current;
			let calorieString = String(calorie.current);
			
			index = 0;
          for (var i = 0; i < 3; i++) {
						calorieArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');
						
						}
			if (calorieCurrent < 10) {
				index = 1;
			}
				for (let char of calorieString) {
				const charCode = char.charCodeAt()-48;
				if (charCode < 0) {
					continue;
				}
				if (index >= 3) {
					break;
				}
				calorieArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
			}	

 



					const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
					resume_call: (function () {
						console.log('ui resume');					
						console.log('ui resume');
					stepCurrent = step.current;
					stepString = String(step.current);
					debugText.setProperty(hmUI.prop.TEXT, String(stepString));
					index = 0;
					for (var i = 0; i < 5; i++) {
						stepsArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');

						}
          
					if (stepCurrent < 10) {
						index = 1;
					}						
					for (let char of stepString) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 5) {
							break;
						}						
						debugText.setProperty(hmUI.prop.TEXT, String(index));
						stepsArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}
				
					
					calorieCurrent = calorie.current;
					calorieString = String(calorie.current);
					debugText.setProperty(hmUI.prop.TEXT, String(calorieString));
					index = 0;
					for (i = 0; i < 3; i++) {
						calorieArrayImg[i].setProperty(hmUI.prop.SRC, 'transparent.png');

											}
					if (calorieCurrent < 10) {
						index = 1;
					}						
					for (let char of calorieString) {
						const charCode = char.charCodeAt()-48;
						if (charCode < 0) {
							continue;
						}
						if (index >= 5) {
							break;
						}						
						debugText.setProperty(hmUI.prop.TEXT, String(index));
						calorieArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode]);
					}					
							}),
						});

    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
      }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          pos_x: 480 / 2 - 40,
          pos_y: 480 / 2 - 240,
          center_x: 240,
          center_y: 240,
          src: 'sec.png',
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
      }
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
          } else {
            duration = 0;
          }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
          stopSecAnim();
        }),
      });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }
	
			  normal$_$analog_clock$_$time_pointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 40,
              hour_posY: 240,
              hour_path: 'hour.png',
              hour_cover_path: '',
              hour_cover_x: 0,
              hour_cover_y: 0,
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 40,
              minute_posY: 240,
              minute_path: 'min.png',
              minute_cover_path: '',
              minute_cover_x: 0,
              minute_cover_y: 0,			  
             /*
			  second_centerX: 240,
              second_centerY: 240,
              second_posX: 40,
              second_posY: 240,
              second_path: 'sec.png',
              second_cover_path: '',
              second_cover_x: 0,
              second_cover_y: 0,
			  
              show_level: hmUI.show_level.ONLY_NORMAL,
*/
            });
 setSec();




  },
          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  