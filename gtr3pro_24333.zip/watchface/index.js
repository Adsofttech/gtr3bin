﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 160,
              src: 'system_bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 162,
              src: 'system_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 261,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Cal_dis_font_14.png',
              unit_tc: 'Cal_dis_font_14.png',
              unit_en: 'Cal_dis_font_14.png',
              negative_image: 'Cal_dis_font_13.png',
              invalid_image: 'Cal_dis_font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 243,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 215,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Cal_dis_font_12.png',
              unit_tc: 'Cal_dis_font_12.png',
              unit_en: 'Cal_dis_font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 15,
              y: 14,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 332,
              font_array: ["Heart_Step_font_01.png","Heart_Step_font_02.png","Heart_Step_font_03.png","Heart_Step_font_04.png","Heart_Step_font_05.png","Heart_Step_font_06.png","Heart_Step_font_07.png","Heart_Step_font_08.png","Heart_Step_font_09.png","Heart_Step_font_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Heart_Step_font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 256,
              y: 337,
              image_array: ["zone01.png","zone02.png","zone03.png","zone04.png","zone05.png","zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 118,
              font_array: ["Heart_Step_font_01.png","Heart_Step_font_02.png","Heart_Step_font_03.png","Heart_Step_font_04.png","Heart_Step_font_05.png","Heart_Step_font_06.png","Heart_Step_font_07.png","Heart_Step_font_08.png","Heart_Step_font_09.png","Heart_Step_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 15,
              image_array: ["step_icon_01.png","step_icon_02.png","step_icon_03.png","step_icon_04.png","step_icon_05.png","step_icon_06.png","step_icon_07.png","step_icon_08.png","step_icon_09.png","step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 260,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Cal_dis_font_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 215,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 313,
              image_array: ["cal_icons_01.png","cal_icons_02.png","cal_icons_03.png","cal_icons_04.png","cal_icons_05.png","cal_icons_06.png","cal_icons_07.png","cal_icons_08.png","cal_icons_09.png","cal_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 416,
              week_en: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              week_tc: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              week_sc: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -404,
              day_startY: 356,
              day_sc_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_tc_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_en_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_zero: 1,
              day_space: -19,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 58,
              am_y: 293,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 58,
              pm_y: 293,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 54,
              hour_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 54,
              minute_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 54,
              src: 'Cal_dis_font_15.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Clock_03.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 130,
              hour_posY: 302,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Clock_02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 130,
              minute_posY: 302,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Clock_01.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 130,
              second_posY: 302,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 205,
              w: 71,
              h: 71,
              src: '0_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 217,
              y: 41,
              w: 42,
              h: 43,
              src: '0_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 385,
              y: 147,
              w: 43,
              h: 44,
              src: '0_empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 243,
              w: 48,
              h: 40,
              src: '0_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 254,
              w: 66,
              h: 31,
              src: '0_empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 259,
              y: 331,
              w: 101,
              h: 32,
              src: '0_empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 135,
              y: 328,
              w: 111,
              h: 38,
              src: '0_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 168,
              y: 95,
              w: 151,
              h: 56,
              src: '0_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'main.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 66,
              y: 160,
              src: 'system_bluetooth_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 162,
              src: 'system_alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 261,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Cal_dis_font_14.png',
              unit_tc: 'Cal_dis_font_14.png',
              unit_en: 'Cal_dis_font_14.png',
              negative_image: 'Cal_dis_font_13.png',
              invalid_image: 'Cal_dis_font_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 90,
              y: 243,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 90,
              y: 215,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Cal_dis_font_12.png',
              unit_tc: 'Cal_dis_font_12.png',
              unit_en: 'Cal_dis_font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 15,
              y: 14,
              image_array: ["Battery_icons_01.png","Battery_icons_02.png","Battery_icons_03.png","Battery_icons_04.png","Battery_icons_05.png","Battery_icons_06.png","Battery_icons_07.png","Battery_icons_08.png","Battery_icons_09.png","Battery_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 134,
              y: 332,
              font_array: ["Heart_Step_font_01.png","Heart_Step_font_02.png","Heart_Step_font_03.png","Heart_Step_font_04.png","Heart_Step_font_05.png","Heart_Step_font_06.png","Heart_Step_font_07.png","Heart_Step_font_08.png","Heart_Step_font_09.png","Heart_Step_font_10.png"],
              padding: false,
              h_space: 3,
              invalid_image: 'Heart_Step_font_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 256,
              y: 337,
              image_array: ["zone01.png","zone02.png","zone03.png","zone04.png","zone05.png","zone06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 150,
              y: 118,
              font_array: ["Heart_Step_font_01.png","Heart_Step_font_02.png","Heart_Step_font_03.png","Heart_Step_font_04.png","Heart_Step_font_05.png","Heart_Step_font_06.png","Heart_Step_font_07.png","Heart_Step_font_08.png","Heart_Step_font_09.png","Heart_Step_font_10.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 313,
              y: 15,
              image_array: ["step_icon_01.png","step_icon_02.png","step_icon_03.png","step_icon_04.png","step_icon_05.png","step_icon_06.png","step_icon_07.png","step_icon_08.png","step_icon_09.png","step_icon_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 260,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'Cal_dis_font_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 315,
              y: 215,
              font_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 312,
              y: 313,
              image_array: ["cal_icons_01.png","cal_icons_02.png","cal_icons_03.png","cal_icons_04.png","cal_icons_05.png","cal_icons_06.png","cal_icons_07.png","cal_icons_08.png","cal_icons_09.png","cal_icons_10.png"],
              image_length: 10,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 104,
              y: 416,
              week_en: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              week_tc: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              week_sc: ["day_week_01.png","day_week_02.png","day_week_03.png","day_week_04.png","day_week_05.png","day_week_06.png","day_week_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: -404,
              day_startY: 356,
              day_sc_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_tc_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_en_array: ["d01.png","d02.png","d03.png","d04.png","d05.png","d06.png","d07.png","d08.png","d09.png","d10.png"],
              day_zero: 1,
              day_space: -19,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 58,
              am_y: 293,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 58,
              pm_y: 293,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 184,
              hour_startY: 54,
              hour_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.LEFT,

              minute_startX: 244,
              minute_startY: 54,
              minute_array: ["Cal_dis_font_01.png","Cal_dis_font_02.png","Cal_dis_font_03.png","Cal_dis_font_04.png","Cal_dis_font_05.png","Cal_dis_font_06.png","Cal_dis_font_07.png","Cal_dis_font_08.png","Cal_dis_font_09.png","Cal_dis_font_10.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 233,
              y: 54,
              src: 'Cal_dis_font_15.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'Hand_Clock_03.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 130,
              hour_posY: 302,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'Hand_Clock_02.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 130,
              minute_posY: 302,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_Clock_01.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 130,
              second_posY: 302,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  