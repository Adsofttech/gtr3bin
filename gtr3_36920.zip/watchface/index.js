﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_altimeter_text_text_img = ''
        let normal_altimeter_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_month = ''
        let normal_date_month_separator_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let normal_countdown_jumpable_img_click = ''
        let timeSensor = ''

        let element_index = 1;  // Selected element index
        let element_count = 5;  // Number of elements

        let delay_Timer = null;
        let clicks = 0;
        let clicksDelay = 400;       // задержка между кликами в мс 


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 277,
              minute_startY: 237,
              minute_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 313,
              y: 238,
              src: 'Sep.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            // normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 318,
              second_startY: 237,
              second_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              second_zero: 1,
              second_space: 3,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 288,
              y: 198,
              src: 'time.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            //normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 237,
              font_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 198,
              src: 'batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_altimeter_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 237,
              font_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_altimeter_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 198,
              src: 'baro.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 298,
              y: 237,
              font_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 317,
              y: 198,
              src: 'hr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 276,
              day_startY: 237,
              day_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 312,
              y: 237,
              src: 'Dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 317,
              month_startY: 237,
              month_sc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_tc_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_en_array: ["000.png","001.png","002.png","003.png","004.png","005.png","006.png","007.png","008.png","009.png"],
              month_zero: 1,
              month_space: 3,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 280,
              y: 198,
              src: 'date.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, false);  // Disable element display

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'Arrow2.png',
              center_x: 227,
              center_y: 227,
              posX: 24,
              posY: 224,
              start_angle: -180,
              end_angle: -74,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Arrow.png',
              // center_x: 227,
              // center_y: 227,
              // x: 24,
              // y: 227,
              // start_angle: -180,
              // end_angle: 180,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
              // format24h: true,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 24,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'Arrow.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Arrow.png',
              // center_x: 227,
              // center_y: 227,
              // x: 24,
              // y: 227,
              // start_angle: -180,
              // end_angle: 180,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
              // format24h: true,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 24,
              pos_y: 227 - 227,
              center_x: 227,
              center_y: 227,
              src: 'Arrow.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 87,
              y: 178,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                let normal_angle_hour = -180 + normal_fullAngle_hour*normal_hour/24 + (normal_fullAngle_hour/24)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                let idle_angle_hour = -180 + idle_fullAngle_hour*idle_hour/24 + (idle_fullAngle_hour/24)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
              }),
            });

              function click_btn() {  // Function to enable and disable the visibility of elements
              element_index++;
              if(element_index > element_count) element_index = 1;
              
              normal_digital_clock_img_time_minute.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);

              normal_digital_clock_img_time_second.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              normal_digital_clock_second_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 1);
              
              normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);
              normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 3);

              normal_altimeter_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
              normal_altimeter_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 4);
              
              normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_date_day_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, element_index == 2);
              normal_date_month_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 2);

              normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);
              normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, element_index == 5);


              // if (element_index == 1) {
              //   hmUI.showToast({text: 'Altimeter'});
              // };
              // if (element_index == 2) {
              //   hmUI.showToast({text: 'Battery'});
              // };
              // if (element_index == 3) {
              //   hmUI.showToast({text: 'Steps'});
              // };
            };


            // Button to switch elements. This block should be after all blocks with display elements.
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 277,  // x coordinate of the button
              y: 190,  // y coordinate of the button
              text: '',
              w: 90,  // button width
              h: 90,  // button height
              normal_src: '',  
              press_src: '',  
              show_level: hmUI.show_level.ONLY_NORMAL,
              click_func: () => {
                click_btn();
              }
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}