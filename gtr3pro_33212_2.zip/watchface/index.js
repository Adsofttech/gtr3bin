﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 222,
              day_startY: 375,
              day_sc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_tc_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_en_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              day_zero: 0,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 420,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 188,
              y: 73,
              week_en: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_tc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              week_sc: ["day_1.png","day_2.png","day_3.png","day_4.png","day_5.png","day_6.png","day_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 25,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'pointer_6.png',
              unit_tc: 'pointer_6.png',
              unit_en: 'pointer_6.png',
              negative_image: 'pointer_5.png',
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 191,
              y: 18,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 86,
              center_y: 86,
              x: 5,
              y: 90,
              start_angle: 226,
              end_angle: 43,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 190,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 392,
              center_y: 86,
              x: 5,
              y: 90,
              start_angle: 134,
              end_angle: 315,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 358,
              y: 190,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 86,
              center_y: 392,
              x: 5,
              y: 90,
              start_angle: -48,
              end_angle: 137,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 46,
              y: 265,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_4.png',
              center_x: 392,
              center_y: 392,
              x: 5,
              y: 90,
              start_angle: -137,
              end_angle: 48,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 265,
              font_array: ["act_0.png","act_1.png","act_2.png","act_3.png","act_4.png","act_5.png","act_6.png","act_7.png","act_8.png","act_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 302,
              am_y: 226,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 302,
              pm_y: 226,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 185,
              hour_startY: 153,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 185,
              minute_startY: 245,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });




                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
