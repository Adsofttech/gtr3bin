try {
    (() => {
        const e = __$$hmAppManager$$__.currentApp;
		//-----01此处添加下列代码 代码块 开始位置 ------

let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 5000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 100,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 480,/*屏幕宽度  3p 480*/
          h: 480,/*屏幕宽度  3p 480*/
          pos_x: 480 / 2 - 15,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 480 / 2 - 240,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 240, /*表盘旋转中心 3p 240*/
          center_y: 240,/*表盘旋转中心 3p 240*/
          src: '23.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘
          easeInAnim();
          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------
		
		
        const n = e.current,
            {
                px: _
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.__globals__),
            g = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "3.png",
                    center_x: 240,
                    center_y: 323,
                    x: 10,
                    y: 52,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 0,
                    end_angle: 359,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 186,
                    y: 124,
                    week_en: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png"],
                    week_tc: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png"],
                    week_sc: ["4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 259,
                    day_startY: 126,
                    day_sc_array: ["11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png"],
                    day_tc_array: ["11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png"],
                    day_en_array: ["11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png"],
                    day_align: hmUI.align.CENTER_H,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 15,
                    hour_posY: 218,
                    hour_path: "21.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 15,
                    minute_posY: 218,
                    minute_path: "22.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 240,
                    second_centerY: 240,
                    second_posX: 1001,
                    second_posY: 1001,
                    second_path: "23.png",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }),
					/*03此处添加  setSec()*/
					setSec()
					
					hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 480,
                    h: 480,
                    src: "24.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 240,
                    hour_centerY: 240,
                    hour_posX: 15,
                    hour_posY: 218,
                    hour_path: "25.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 240,
                    minute_centerY: 240,
                    minute_posX: 15,
                    minute_posY: 218,
                    minute_path: "26.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            }, onInit() {
                g.log("index page.js on init invoke")
            }, build() {
                this.init_view(), g.log("index page.js on ready invoke")
            }, onDestroy() {
                g.log("index page.js on destroy invoke")
					/*04此处添加 stopSecAnim() */
				stopSecAnim()
            }
        })
    })()
} catch (e) {
    console.log("Mini Program Error", e), e && e.stack && e.stack.split(/\n/).forEach((e => console.log("error stack", e)))
}