﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_date_img_date_month_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_moon_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_day = ''
        let idle_moon_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_current_separator_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_distance_text_separator_img = ''
        let idle_step_icon_img = ''
        let idle_step_current_text_img = ''
        let idle_pai_icon_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        // смена маски
        //let bot_circle_btn = ''
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 7
            
       function click_mask() {
         if(mask_num>=mask_all) {mask_num=1;}
          else { mask_num=mask_num+1;}
           hmUI.showToast({text: "<Фон> " + parseInt(mask_num) });
           normal_background_bg_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(mask_num) + ".png");
       }

       //смена окантовки
        let btn_bezel
        let okan_num = 1
        let okan_all = 7
            
       function click_okan() {
         if(okan_num>=okan_all) {okan_num=1;}
          else { okan_num=okan_num+1;}
           hmUI.showToast({text: "<Окантовка> " + parseInt(okan_num) });
           normal_image_img.setProperty(hmUI.prop.SRC, "okan_" + parseInt(okan_num) + ".png");
       }

       let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
       
       let switch_checkBT;
       let switch_hourlyVibro;
       
       const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider1_on.png' : 'slider1_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   
   //--------------------- вибрация каждый час  ---------------------
       function setEveryHourVibro() {
         curTime.addEventListener(curTime.event.MINUTEEND, function () {
             if (everyHourVibro && !(curTime.minute % 60)) {
               vibro(27);
               hmUI.showToast({text: "Новый час!!!"});
             }
         });
           }
   
   //----------------- вибрация каждый час: включение/отключение  ------------------
       function toggleEveryHourVibro() {
         everyHourVibro = !everyHourVibro;
         vibro();
         hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 
         hmUI.showToast({text: "Ежечасная вибрация " + (everyHourVibro ? "включена" : "отключена")});
           }
   
   
   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
         if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
           everyHourVibro = false;
           hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         } else {
           everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
         }
     
       }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'okan_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 316,
              month_startY: 242,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 342,
              center_y: 227,
              posX: 86,
              posY: 86,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 361,
              day_sc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_tc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_en_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 262,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 316,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 349,
              src: 'cal_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 349,
              src: 'pulse_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 316,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 108,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'wnum_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 87,
              src: 'dist_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 87,
              src: 'stepicon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 108,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 100,
              y: 176,
              src: 'bton.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 176,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 174,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 243,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 110,
              center_y: 227,
              x: 86,
              y: 86,
              start_angle: -150,
              end_angle: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 26,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 26,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 26,
              second_posY: 227,
              second_cover_path: 'center_p.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 57,
              y: 53,
              text: '',
              w: 66,
              h: 66,
              normal_src: '',
              press_src: '',
              click_func: () => {
                click_okan();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
      
            btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 331,
              y: 53,
              text: '',
              w: 66,
              h: 66,
              normal_src: '',
              press_src: '',
              click_func: () => {
                  click_mask();
                  vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);

      // кнопка включения/отключения ежечасного сигнала
      switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
        x: 328,
        y: 326,
        w: 66,
        h: 66,
        src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
          switch_hourlyVibro.addEventListener(hmUI.event.CLICK_UP, function () {
          toggleEveryHourVibro();
       });


      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 57,
        y: 326,
        w: 66,
        h: 66,
        src: checkBT ? 'slider1_on.png' : 'slider1_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });

                // низкий заряд
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 61,
                  y: 180,
                  w: 95,
                  h: 95,
                  text: '',
                  normal_src: '',
                  press_src: '',
                  click_func: () => {
                  hmApp.startApp({ url: 'LowBatteryScreen', native: true });
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });				
       
              // календарь
              hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 295,
                y: 180,
                w: 95,
                h: 95,
                text: '',
                normal_src: '',
                press_src: '',
                click_func: () => {
                hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
               });	


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 316,
              month_startY: 242,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 342,
              center_y: 227,
              posX: 86,
              posY: 86,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 361,
              day_sc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_tc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_en_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 208,
              y: 262,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 257,
              y: 316,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 267,
              y: 349,
              src: 'cal_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 152,
              y: 349,
              src: 'pulse_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 316,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 252,
              y: 108,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'wnum_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 255,
              y: 87,
              src: 'dist_icon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 87,
              src: 'stepicon.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 108,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 100,
              y: 176,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 320,
              y: 174,
              src: 'al.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 85,
              y: 243,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 110,
              center_y: 227,
              x: 86,
              y: 86,
              start_angle: -150,
              end_angle: 150,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 26,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 26,
              minute_posY: 227,
              minute_cover_path: 'center_p.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 193,
              y: 248,
              w: 66,
              h: 66,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 260,
              y: 308,
              w: 66,
              h: 66,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 125,
              y: 307,
              w: 66,
              h: 66,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 131,
              y: 74,
              w: 95,
              h: 95,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                //scale_call();
                stopVibro();
                checkConnection(checkBT);
                //autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),

            });
            setEveryHourVibro();


                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}