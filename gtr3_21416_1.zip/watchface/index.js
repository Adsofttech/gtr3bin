﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_step_current_text_img = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_background_bg = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 323,
              font_array: ["76.png","77.png","78.png","79.png","80.png","81.png","82.png","83.png","84.png","85.png"],
              padding: false,
              h_space: -4,
              unit_sc: '75.png',
              unit_tc: '75.png',
              unit_en: '75.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -56,
              y: 170,
              src: '45.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 65,
              y: 170,
              image_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png","56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png","66.png","67.png","68.png","69.png","70.png","71.png","72.png","73.png","74.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 305,
              month_startY: 122,
              month_sc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_tc_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_en_array: ["21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png","30.png","31.png","32.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 122,
              day_sc_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              day_tc_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              day_en_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: '44.png',
              day_unit_tc: '44.png',
              day_unit_en: '44.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -63,
              y: 122,
              src: '43.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 29,
              week_en: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png"],
              week_tc: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png"],
              week_sc: ["01.png","02.png","03.png","04.png","05.png","06.png","07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 245,
              hour_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: '09.png',
              hour_unit_tc: '09.png',
              hour_unit_en: '09.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_unit_en: '20.png',
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -88,
              y: 245,
              src: '08.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 305,
              month_startY: 122,
              month_sc_array: ["AOD_21.png","AOD_22.png","AOD_23.png","AOD_24.png","AOD_25.png","AOD_26.png","AOD_27.png","AOD_28.png","AOD_29.png","AOD_30.png","AOD_31.png","AOD_32.png"],
              month_tc_array: ["AOD_21.png","AOD_22.png","AOD_23.png","AOD_24.png","AOD_25.png","AOD_26.png","AOD_27.png","AOD_28.png","AOD_29.png","AOD_30.png","AOD_31.png","AOD_32.png"],
              month_en_array: ["AOD_21.png","AOD_22.png","AOD_23.png","AOD_24.png","AOD_25.png","AOD_26.png","AOD_27.png","AOD_28.png","AOD_29.png","AOD_30.png","AOD_31.png","AOD_32.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 60,
              day_startY: 122,
              day_sc_array: ["AOD_33.png","AOD_34.png","AOD_35.png","AOD_36.png","AOD_37.png","AOD_38.png","AOD_39.png","AOD_40.png","AOD_41.png","AOD_42.png"],
              day_tc_array: ["AOD_33.png","AOD_34.png","AOD_35.png","AOD_36.png","AOD_37.png","AOD_38.png","AOD_39.png","AOD_40.png","AOD_41.png","AOD_42.png"],
              day_en_array: ["AOD_33.png","AOD_34.png","AOD_35.png","AOD_36.png","AOD_37.png","AOD_38.png","AOD_39.png","AOD_40.png","AOD_41.png","AOD_42.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'AOD_44.png',
              day_unit_tc: 'AOD_44.png',
              day_unit_en: 'AOD_44.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -63,
              y: 122,
              src: 'AOD_43.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 60,
              y: 29,
              week_en: ["AOD_01.png","AOD_02.png","AOD_03.png","AOD_04.png","AOD_05.png","AOD_06.png","AOD_07.png"],
              week_tc: ["AOD_01.png","AOD_02.png","AOD_03.png","AOD_04.png","AOD_05.png","AOD_06.png","AOD_07.png"],
              week_sc: ["AOD_01.png","AOD_02.png","AOD_03.png","AOD_04.png","AOD_05.png","AOD_06.png","AOD_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 245,
              hour_array: ["AOD_10.png","AOD_11.png","AOD_12.png","AOD_13.png","AOD_14.png","AOD_15.png","AOD_16.png","AOD_17.png","AOD_18.png","AOD_19.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_unit_sc: 'AOD_09.png',
              hour_unit_tc: 'AOD_09.png',
              hour_unit_en: 'AOD_09.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["AOD_10.png","AOD_11.png","AOD_12.png","AOD_13.png","AOD_14.png","AOD_15.png","AOD_16.png","AOD_17.png","AOD_18.png","AOD_19.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  