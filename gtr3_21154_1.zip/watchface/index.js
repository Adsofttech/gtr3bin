﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_month = ''
        let normal_step_icon_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Casio_1500_C.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 147,
              y: 340,
              src: '0266.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 302,
              y: 344,
              src: '0255.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 93,
              month_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              month_zero: 0,
              month_space: 0,
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 352,
              y: 105,
              src: 'Pro0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 105,
              image_array: ["Pro0001.png","Pro0002.png","Pro0003.png","Pro0004.png","Pro0005.png","Pro0006.png","Pro0007.png","Pro0008.png","Pro0009.png","Pro0010.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 56,
              hour_startY: 166,
              hour_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              hour_zero: 0,
              hour_space: -1,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 218,
              minute_startY: 166,
              minute_array: ["Dig0010.png","Dig0011.png","Dig0012.png","Dig0013.png","Dig0014.png","Dig0015.png","Dig0016.png","Dig0017.png","Dig0018.png","Dig0019.png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 198,
              second_startY: 319,
              second_array: ["Dig0020.png","Dig0021.png","Dig0022.png","Dig0023.png","Dig0024.png","Dig0025.png","Dig0026.png","Dig0027.png","Dig0028.png","Dig0029.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 300,
              am_sc_path: 'PM0000.png',
              am_en_path: 'PM0000.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'PM0000.png',
              pm_en_path: 'PM0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 273,
              day_startY: 93,
              day_sc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_tc_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_en_array: ["Dig0030.png","Dig0031.png","Dig0032.png","Dig0033.png","Dig0034.png","Dig0035.png","Dig0036.png","Dig0037.png","Dig0038.png","Dig0039.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 105,
              y: 93,
              week_en: ["Dig0001.png","Dig0002.png","Dig0003.png","Dig0004.png","Dig0005.png","Dig0006.png","Dig0007.png"],
              week_tc: ["Dig0001.png","Dig0002.png","Dig0003.png","Dig0004.png","Dig0005.png","Dig0006.png","Dig0007.png"],
              week_sc: ["Dig0001.png","Dig0002.png","Dig0003.png","Dig0004.png","Dig0005.png","Dig0006.png","Dig0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 55,
              hour_startY: 167,
              hour_array: ["DigA000.png","DigA001.png","DigA002.png","DigA003.png","DigA004.png","DigA005.png","DigA006.png","DigA007.png","DigA008.png","DigA009.png"],
              hour_zero: 0,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 223,
              minute_startY: 167,
              minute_array: ["DigA000.png","DigA001.png","DigA002.png","DigA003.png","DigA004.png","DigA005.png","DigA006.png","DigA007.png","DigA008.png","DigA009.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 167,
              src: 'DigW990.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 300,
              am_y: 300,
              am_sc_path: 'PMw000.png',
              am_en_path: 'PMw000.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: 'PMw000.png',
              pm_en_path: 'PMw000.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  