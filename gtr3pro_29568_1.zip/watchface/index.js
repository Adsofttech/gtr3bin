﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 206,
              y: 307,
              src: '0046.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 257,
              y: 307,
              src: '0048.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 97,
              y: 306,
              src: '0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 152,
              y: 306,
              src: '0044.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 5,
              y: 185,
              image_array: ["0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 80,
              y: 187,
              font_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Perc.png',
              unit_tc: 'Perc.png',
              unit_en: 'Perc.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 272,
              y: 376,
              font_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              padding: false,
              h_space: 2,
              invalid_image: '0031.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 125,
              y: 376,
              font_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 104,
              font_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 76,
              y: 41,
              image_array: ["0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 260,
              y: 50,
              week_en: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              week_tc: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              week_sc: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 269,
              month_startY: 105,
              month_sc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_tc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_en_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 355,
              day_startY: 105,
              day_sc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_tc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_en_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 310,
              am_y: 306,
              am_sc_path: '0050.png',
              am_en_path: '0050.png',
              pm_x: 310,
              pm_y: 306,
              pm_sc_path: '0051.png',
              pm_en_path: '0051.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 190,
              hour_array: ["B_(1).png","B_(2).png","B_(3).png","B_(4).png","B_(5).png","B_(6).png","B_(7).png","B_(8).png","B_(9).png","B_(A).png"],
              hour_zero: 0,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 332,
              minute_startY: 190,
              minute_array: ["B_(1).png","B_(2).png","B_(3).png","B_(4).png","B_(5).png","B_(6).png","B_(7).png","B_(8).png","B_(9).png","B_(A).png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 100,
              second_startY: 237,
              second_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 290,
              y: 180,
              src: '0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 256,
              y: 337,
              src: '0046.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 307,
              y: 337,
              src: '0048.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 147,
              y: 336,
              src: '0043.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 202,
              y: 336,
              src: '0044.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 385,
              font_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Perc.png',
              unit_tc: 'Perc.png',
              unit_en: 'Perc.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 312,
              y: 125,
              week_en: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              week_tc: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              week_sc: ["Day_(1).png","Day_(2).png","Day_(3).png","Day_(4).png","Day_(5).png","Day_(6).png","Day_(7).png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 149,
              month_startY: 125,
              month_sc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_tc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_en_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              month_zero: 1,
              month_space: 1,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 225,
              day_startY: 125,
              day_sc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_tc_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_en_array: ["S_(1).png","S_(2).png","S_(3).png","S_(4).png","S_(5).png","S_(6).png","S_(7).png","S_(8).png","S_(9).png","S_(A).png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 175,
              am_y: 291,
              am_sc_path: '0050.png',
              am_en_path: '0050.png',
              pm_x: 185,
              pm_y: 291,
              pm_sc_path: '0051.png',
              pm_en_path: '0051.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 190,
              hour_array: ["B_(1).png","B_(2).png","B_(3).png","B_(4).png","B_(5).png","B_(6).png","B_(7).png","B_(8).png","B_(9).png","B_(A).png"],
              hour_zero: 0,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 262,
              minute_startY: 190,
              minute_array: ["B_(1).png","B_(2).png","B_(3).png","B_(4).png","B_(5).png","B_(6).png","B_(7).png","B_(8).png","B_(9).png","B_(A).png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 180,
              src: '0012.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  