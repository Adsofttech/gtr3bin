﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js

//////////////////////////////////////////////////////////////////////////////////////////////////

        let nDisplayNumber = 1
        let nMaxDisplays = 5
        let cc = 0

function click_ChangeMode() {
    nDisplayNumber=nDisplayNumber+1;
	if (nDisplayNumber>nMaxDisplays){
	  nDisplayNumber=1;
    }
    if(nDisplayNumber==1) {
      ShowDisplay_Steps();
	  hmUI.showToast({text: 'Steps'});
    }
    if(nDisplayNumber==2) {
      ShowDisplay_Distance();
	  hmUI.showToast({text: 'Distance'});
    }
    if(nDisplayNumber==3) {
      ShowDisplay_Pulse();
	  hmUI.showToast({text: 'Pulse'});
    }
    if(nDisplayNumber==4) {
      ShowDisplay_Battery();
	  hmUI.showToast({text: 'Battery'});
    }
    if(nDisplayNumber==5) {
      ShowDisplay_Date();
	  hmUI.showToast({text: 'Date'});
    }
}

// - - - - - - - - 
let nAnimNumber = 1
let total_anim = 2

function click_Anim() {
  nAnimNumber=nAnimNumber+1;
  if(nAnimNumber>total_anim) {nAnimNumber=1;}
  if(nAnimNumber==1) {UpdateAnimOn(); hmUI.showToast({text: 'Animation ON'});}
  if(nAnimNumber==2) {UpdateAnimOff(); hmUI.showToast({text: 'Animation OFF'});}
}

// Animation ON
function UpdateAnimOn(){
	normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_rotate_animation_img_2.setProperty(hmUI.prop.VISIBLE, true);
	normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_rotate_animation_img_3.setProperty(hmUI.prop.VISIBLE, true);
	normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_rotate_animation_img_4.setProperty(hmUI.prop.VISIBLE, true);
	normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
	normal_rotate_animation_img_5.setProperty(hmUI.prop.VISIBLE, true);
}

//Animation OFF
function UpdateAnimOff(){
	normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_rotate_animation_img_2.setProperty(hmUI.prop.VISIBLE, false);
	normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_rotate_animation_img_3.setProperty(hmUI.prop.VISIBLE, false);
	normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_rotate_animation_img_4.setProperty(hmUI.prop.VISIBLE, false);
	normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
	normal_rotate_animation_img_5.setProperty(hmUI.prop.VISIBLE, false);
}

//////////////////////////////////////////////////////////////////////////////////////////////////
function Show_Reset(){    
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
}
//////////////////////////////////////////////////////////////////////////////////////////////////
function ShowDisplay_Steps(){
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
}
//////////////////////////////////////////////////////////////////////////////////////////////////
function ShowDisplay_Distance(){
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
}
//////////////////////////////////////////////////////////////////////////////////////////////////
function ShowDisplay_Pulse(){
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);

    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
}
//////////////////////////////////////////////////////////////////////////////////////////////////
function ShowDisplay_Battery(){
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, false);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
}
//////////////////////////////////////////////////////////////////////////////////////////////////
function ShowDisplay_Date(){
	normal_year_icon_img.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_year.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_month.setProperty(hmUI.prop.VISIBLE, true);
    normal_date_img_date_day.setProperty(hmUI.prop.VISIBLE, true);
    
	normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_battery_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    
	normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_spo2_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
 
    normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
   
	normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
    normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
}

        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_year_icon_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_spo2_text_text_img = ''
        let normal_spo2_text_separator_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_rotate_animation_img_2 = '';
        let normal_rotate_animation_param_2 = null;
        let normal_rotate_animation_lastTime_2 = 0;
        let timer_anim_rotate_2;
        let timer_anim_rotate_2_mirror = false;
        let normal_rotate_animation_param_2_mirror = null;
        let normal_rotate_animation_count_2 = 0;
        let normal_rotate_animation_img_3 = '';
        let normal_rotate_animation_param_3 = null;
        let normal_rotate_animation_lastTime_3 = 0;
        let timer_anim_rotate_3;
        let timer_anim_rotate_3_mirror = false;
        let normal_rotate_animation_param_3_mirror = null;
        let normal_rotate_animation_count_3 = 0;
        let normal_rotate_animation_img_4 = '';
        let normal_rotate_animation_param_4 = null;
        let normal_rotate_animation_lastTime_4 = 0;
        let timer_anim_rotate_4;
        let timer_anim_rotate_4_mirror = false;
        let normal_rotate_animation_param_4_mirror = null;
        let normal_rotate_animation_count_4 = 0;
        let normal_rotate_animation_img_5 = '';
        let normal_rotate_animation_param_5 = null;
        let normal_rotate_animation_lastTime_5 = 0;
        let timer_anim_rotate_5;
        let timer_anim_rotate_5_mirror = false;
        let normal_rotate_animation_param_5_mirror = null;
        let normal_rotate_animation_count_5 = 0;
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_pai_icon_img = ''
        let idle_digital_clock_img_time = ''
        let image_top_img = ''
        let Button_1 = ''
        let Button_2 = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg01.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_year_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 97,
              src: 'bg03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 140,
              year_startY: 115,
              year_sc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              year_tc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              year_en_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              year_zero: 1,
              year_space: 0,
              year_unit_sc: 'font1_d.png',
              year_unit_tc: 'font1_d.png',
              year_unit_en: 'font1_d.png',
              year_align: hmUI.align.RIGHT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 240,
              month_startY: 115,
              month_sc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              month_tc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              month_en_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'font1_d.png',
              month_unit_tc: 'font1_d.png',
              month_unit_en: 'font1_d.png',
              month_align: hmUI.align.RIGHT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 300,
              day_startY: 115,
              day_sc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              day_tc_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              day_en_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 97,
              src: 'bg03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 249,
              y: 115,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'font2_f.png',
              unit_tc: 'font2_f.png',
              unit_en: 'font2_f.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 117,
              src: 'icon_batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 97,
              src: 'bg03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 178,
              y: 115,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: 0,
              invalid_image: 'font1_e.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 119,
              src: 'icon_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 97,
              src: 'bg03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 174,
              y: 115,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'font2_i.png',
              unit_tc: 'font2_i.png',
              unit_en: 'font2_i.png',
              imperial_unit_sc: 'font2_j.png',
              imperial_unit_tc: 'font2_j.png',
              imperial_unit_en: 'font2_j.png',
              dot_image: 'font1_b.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 115,
              src: 'icon_dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 115,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 245,
              y: 116,
              src: 'icon_spo2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 125,
              y: 97,
              src: 'bg03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 115,
              font_array: ["font1_0.png","font1_1.png","font1_2.png","font1_3.png","font1_4.png","font1_5.png","font1_6.png","font1_7.png","font1_8.png","font1_9.png"],
              padding: true,
              h_space: 0,
              unit_sc: 'font2_g.png',
              unit_tc: 'font2_g.png',
              unit_en: 'font2_g.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 119,
              src: 'icon_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_img_2 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: -287,
              pos_y: 123,
              center_x: -34,
              center_y: 550,
              angle: 56,
              src: 'animation/anim_blade1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_2 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 56,
              anim_to: 30,
              anim_fps: 15,
              anim_key: "angle",
            };

            let now = hmSensor.createSensor(hmSensor.id.TIME);

            normal_rotate_animation_param_2_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 30,
              anim_to: 56,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_2_mirror() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2_mirror);
              normal_rotate_animation_lastTime_2 = now.utc;
              normal_rotate_animation_count_2 = normal_rotate_animation_count_2 - 1;
              if(normal_rotate_animation_count_2 < -1) normal_rotate_animation_count_2 = - 1;
              if(normal_rotate_animation_count_2 == 0) stop_anim_rotate_2();

            }; // end animation_mirror callback function

            function anim_rotate_2_complete_call() {
              normal_rotate_animation_img_2.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_2);
              normal_rotate_animation_lastTime_2 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_2() {
              if (timer_anim_rotate_2) {
                timer.stopTimer(timer_anim_rotate_2);
                timer_anim_rotate_2 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_2 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 56,
              // end_angle: 30,
              // pos_x: 253,
              // pos_y: 427,
              // center_x: -34,
              // center_y: 550,
              // src: 'anim_blade1.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_3 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: -432,
              pos_y: -296,
              center_x: -179,
              center_y: 131,
              angle: 120,
              src: 'animation/anim_blade1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_3 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 120,
              anim_to: 94,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_3_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 94,
              anim_to: 120,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_3_mirror() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3_mirror);
              normal_rotate_animation_lastTime_3 = now.utc;
              normal_rotate_animation_count_3 = normal_rotate_animation_count_3 - 1;
              if(normal_rotate_animation_count_3 < -1) normal_rotate_animation_count_3 = - 1;
              if(normal_rotate_animation_count_3 == 0) stop_anim_rotate_3();

            }; // end animation_mirror callback function

            function anim_rotate_3_complete_call() {
              normal_rotate_animation_img_3.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_3);
              normal_rotate_animation_lastTime_3 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_3() {
              if (timer_anim_rotate_3) {
                timer.stopTimer(timer_anim_rotate_3);
                timer_anim_rotate_3 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_3 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 120,
              // end_angle: 94,
              // pos_x: 253,
              // pos_y: 427,
              // center_x: -179,
              // center_y: 131,
              // src: 'anim_blade1.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_4 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: -149,
              pos_y: -611,
              center_x: 104,
              center_y: -184,
              angle: 180,
              src: 'animation/anim_blade1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_4 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 180,
              anim_to: 152,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_4_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 152,
              anim_to: 180,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_4_mirror() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4_mirror);
              normal_rotate_animation_lastTime_4 = now.utc;
              normal_rotate_animation_count_4 = normal_rotate_animation_count_4 - 1;
              if(normal_rotate_animation_count_4 < -1) normal_rotate_animation_count_4 = - 1;
              if(normal_rotate_animation_count_4 == 0) stop_anim_rotate_4();

            }; // end animation_mirror callback function

            function anim_rotate_4_complete_call() {
              normal_rotate_animation_img_4.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_4);
              normal_rotate_animation_lastTime_4 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_4() {
              if (timer_anim_rotate_4) {
                timer.stopTimer(timer_anim_rotate_4);
                timer_anim_rotate_4 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_4 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 180,
              // end_angle: 152,
              // pos_x: 253,
              // pos_y: 427,
              // center_x: 104,
              // center_y: -184,
              // src: 'anim_blade1.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_rotate_animation_img_5 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 481,
              h: 481,
              pos_x: 267,
              pos_y: -527,
              center_x: 520,
              center_y: -100,
              angle: 240,
              src: 'animation/anim_blade1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_rotate_animation_param_5 = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 240,
              anim_to: 210,
              anim_fps: 15,
              anim_key: "angle",
            };

            normal_rotate_animation_param_5_mirror = {
              anim_rate: 'linear',
              anim_duration: 1000,
              anim_from: 210,
              anim_to: 240,
              anim_fps: 15,
              anim_key: "angle",
            };

            function anim_rotate_5_mirror() {
              normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5_mirror);
              normal_rotate_animation_lastTime_5 = now.utc;
              normal_rotate_animation_count_5 = normal_rotate_animation_count_5 - 1;
              if(normal_rotate_animation_count_5 < -1) normal_rotate_animation_count_5 = - 1;
              if(normal_rotate_animation_count_5 == 0) stop_anim_rotate_5();

            }; // end animation_mirror callback function

            function anim_rotate_5_complete_call() {
              normal_rotate_animation_img_5.setProperty(hmUI.prop.ANIM, normal_rotate_animation_param_5);
              normal_rotate_animation_lastTime_5 = now.utc;
            }; // end animation callback function
            
            function stop_anim_rotate_5() {
              if (timer_anim_rotate_5) {
                timer.stopTimer(timer_anim_rotate_5);
                timer_anim_rotate_5 = undefined;
              };
            }; // end stop_anim_rotate function

            // normal_rotate_anime_5 = hmUI.createWidget(hmUI.widget.Rotate_Animation, {
              // start_angle: 240,
              // end_angle: 210,
              // pos_x: 253,
              // pos_y: 427,
              // center_x: 520,
              // center_y: -100,
              // src: 'anim_blade1.png',
              // anim_fps: 15,
              // anim_duration: 1000,
              // repeat_count: 0,
              // anim_two_sides: True,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 191,
              src: 'bg02.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'crown1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pointer0_3.png',
              // center_x: 240,
              // center_y: 240,
              // x: 0,
              // y: 247,
              // start_angle: 310,
              // end_angle: 357,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 0,
              pos_y: 240 - 247,
              center_x: 240,
              center_y: 240,
              src: 'pointer0_3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pointer0_3.png',
              // center_x: 240,
              // center_y: 240,
              // x: 0,
              // y: 247,
              // start_angle: 41,
              // end_angle: 87,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 0,
              pos_y: 240 - 247,
              center_x: 240,
              center_y: 240,
              src: 'pointer0_3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'pointer0_3.png',
              // center_x: 240,
              // center_y: 240,
              // x: 0,
              // y: 247,
              // start_angle: -185,
              // end_angle: -229,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 0,
              pos_y: 240 - 247,
              center_x: 240,
              center_y: 240,
              src: 'pointer0_3.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 50,
              am_y: 90,
              am_sc_path: 'font2_k.png',
              am_en_path: 'font2_k.png',
              pm_x: 50,
              pm_y: 90,
              pm_sc_path: 'font2_l.png',
              pm_en_path: 'font2_l.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 108,
              hour_startY: 210,
              hour_array: ["font0_0.png","font0_1.png","font0_2.png","font0_3.png","font0_4.png","font0_5.png","font0_6.png","font0_7.png","font0_8.png","font0_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_unit_sc: 'font0_a.png',
              hour_unit_tc: 'font0_a.png',
              hour_unit_en: 'font0_a.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 210,
              minute_array: ["font0_0.png","font0_1.png","font0_2.png","font0_3.png","font0_4.png","font0_5.png","font0_6.png","font0_7.png","font0_8.png","font0_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 175,
              second_startY: 304,
              second_array: ["font0_0.png","font0_1.png","font0_2.png","font0_3.png","font0_4.png","font0_5.png","font0_6.png","font0_7.png","font0_8.png","font0_9.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg01.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'crown0.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 108,
              hour_startY: 210,
              hour_array: ["font0_0.png","font0_1.png","font0_2.png","font0_3.png","font0_4.png","font0_5.png","font0_6.png","font0_7.png","font0_8.png","font0_9.png"],
              hour_zero: 1,
              hour_space: -10,
              hour_angle: 0,
              hour_unit_sc: 'font0_a.png',
              hour_unit_tc: 'font0_a.png',
              hour_unit_en: 'font0_a.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 246,
              minute_startY: 210,
              minute_array: ["font0_0.png","font0_1.png","font0_2.png","font0_3.png","font0_4.png","font0_5.png","font0_6.png","font0_7.png","font0_8.png","font0_9.png"],
              minute_zero: 1,
              minute_space: -10,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'crown2.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 310,
              y: 20,
              w: 90,
              h: 70,
              text: '',
              color: 0xFF800000,
              text_size: 25,
              press_src: 'dots_nered1.png',
              normal_src: 'dots_nered0.png',
              click_func: (button_widget) => {
                click_Anim();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: -5,
              y: 140,
              w: 70,
              h: 90,
              text: '',
              color: 0xFF800000,
              text_size: 25,
              press_src: 'dots_nwred1.png',
              normal_src: 'dots_nwred0.png',
              click_func: (button_widget) => {
                click_ChangeMode();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            console.log('user_script_end.js');
            // start user_script_end.js

if (cc==0 ){
Show_Reset();
hmUI.showToast({text: 'Init'});
cc =1
}
            // end user_script_end.js

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 47;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 310 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 46;
                let normal_angle_minute = 41 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = -44;
              let normal_angle_second = -185 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);

                let nawAnimationTime = now.utc;;
                
                let delay_anim_rotate_2 = 0;
                let repeat_anim_rotate_2 = 1000;
                delay_anim_rotate_2 = repeat_anim_rotate_2 - (nawAnimationTime - normal_rotate_animation_lastTime_2);
                if(delay_anim_rotate_2 < 0) delay_anim_rotate_2 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_2) > repeat_anim_rotate_2*2) {
                  normal_rotate_animation_count_2 = 0;
                  timer_anim_rotate_2_mirror = false;
                };

                if (!timer_anim_rotate_2) {
                  timer_anim_rotate_2 = timer.createTimer(delay_anim_rotate_2, repeat_anim_rotate_2, (function (option) {
                    if(timer_anim_rotate_2_mirror) {
                      anim_rotate_2_mirror()
                    } else {
                      anim_rotate_2_complete_call()
                    };
                    timer_anim_rotate_2_mirror = !timer_anim_rotate_2_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_3 = 0;
                let repeat_anim_rotate_3 = 1000;
                delay_anim_rotate_3 = repeat_anim_rotate_3 - (nawAnimationTime - normal_rotate_animation_lastTime_3);
                if(delay_anim_rotate_3 < 0) delay_anim_rotate_3 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_3) > repeat_anim_rotate_3*2) {
                  normal_rotate_animation_count_3 = 0;
                  timer_anim_rotate_3_mirror = false;
                };

                if (!timer_anim_rotate_3) {
                  timer_anim_rotate_3 = timer.createTimer(delay_anim_rotate_3, repeat_anim_rotate_3, (function (option) {
                    if(timer_anim_rotate_3_mirror) {
                      anim_rotate_3_mirror()
                    } else {
                      anim_rotate_3_complete_call()
                    };
                    timer_anim_rotate_3_mirror = !timer_anim_rotate_3_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_4 = 0;
                let repeat_anim_rotate_4 = 1000;
                delay_anim_rotate_4 = repeat_anim_rotate_4 - (nawAnimationTime - normal_rotate_animation_lastTime_4);
                if(delay_anim_rotate_4 < 0) delay_anim_rotate_4 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_4) > repeat_anim_rotate_4*2) {
                  normal_rotate_animation_count_4 = 0;
                  timer_anim_rotate_4_mirror = false;
                };

                if (!timer_anim_rotate_4) {
                  timer_anim_rotate_4 = timer.createTimer(delay_anim_rotate_4, repeat_anim_rotate_4, (function (option) {
                    if(timer_anim_rotate_4_mirror) {
                      anim_rotate_4_mirror()
                    } else {
                      anim_rotate_4_complete_call()
                    };
                    timer_anim_rotate_4_mirror = !timer_anim_rotate_4_mirror;
                  })); // end timer create
                };
                
                let delay_anim_rotate_5 = 0;
                let repeat_anim_rotate_5 = 1000;
                delay_anim_rotate_5 = repeat_anim_rotate_5 - (nawAnimationTime - normal_rotate_animation_lastTime_5);
                if(delay_anim_rotate_5 < 0) delay_anim_rotate_5 = 0; 
                if((nawAnimationTime - normal_rotate_animation_lastTime_5) > repeat_anim_rotate_5*2) {
                  normal_rotate_animation_count_5 = 0;
                  timer_anim_rotate_5_mirror = false;
                };

                if (!timer_anim_rotate_5) {
                  timer_anim_rotate_5 = timer.createTimer(delay_anim_rotate_5, repeat_anim_rotate_5, (function (option) {
                    if(timer_anim_rotate_5_mirror) {
                      anim_rotate_5_mirror()
                    } else {
                      anim_rotate_5_complete_call()
                    };
                    timer_anim_rotate_5_mirror = !timer_anim_rotate_5_mirror;
                  })); // end timer create
                };
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                stop_anim_rotate_2();
                stop_anim_rotate_3();
                stop_anim_rotate_4();
                stop_anim_rotate_5();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}