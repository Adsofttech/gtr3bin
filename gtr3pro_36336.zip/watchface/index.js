﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_image_img = ''
        let normal_pai_icon_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_day = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
 
       // смена безеля
       //let bezel_img = ''
       let btn_bezel = ''
       let bezel_num = 1
       let bezel_all = 10
    
       function click_Bezel() {
           if(bezel_num>=bezel_all) {bezel_num=1;}
           else { bezel_num=bezel_num+1;}
           hmUI.showToast({text: "<Безель> " + parseInt(bezel_num) });
           normal_background_bg_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(bezel_num) + ".png");
       } 
       
       let btn_fonm = ''
       let fonm_num = 1
       let fonm_all = 5
    
       function click_fonm() {
           if(fonm_num>=fonm_all) {fonm_num=1;}
           else { fonm_num=fonm_num+1;}
           hmUI.showToast({text: "<Фон> " + parseInt(fonm_num) });
           normal_image_img.setProperty(hmUI.prop.SRC, "fonm_" + parseInt(fonm_num) + ".png");
       } 

       let longPress_Timer = null;
       let longPressDelay = 850;
       //let btn_cal = ''
       
       function showAppScreen1(){
        //vibro();
        hmApp.startApp({ url: 'LowBatteryScreen', native: true });
       }

       function showAppScreen2(){
        //vibro();
        hmApp.startApp({ url: "CountdownAppScreen", native: true });
       }

       let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
       
       let switch_checkBT;
       let switch_hourlyVibro;
       
       //const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider1_on.png' : 'slider1_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   
   //--------------------- вибрация каждый час  ---------------------
       function setEveryHourVibro() {
         curTime.addEventListener(curTime.event.MINUTEEND, function () {
             if (everyHourVibro && !(curTime.minute % 60)) {
               vibro(27);
               hmUI.showToast({text: "Новый час!!!"});
             }
         });
           }
   
   //----------------- вибрация каждый час: включение/отключение  ------------------
       function toggleEveryHourVibro() {
         everyHourVibro = !everyHourVibro;
         vibro();
         hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 
         hmUI.showToast({text: "Ежечасная вибрация " + (everyHourVibro ? "включена" : "отключена")});
           }
   
   
   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
         if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
           everyHourVibro = false;
           hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         } else {
           everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
         }
     
       }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'fonm_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'system_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 348,
              y: 226,
              src: 'sysalarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 76,
              // start_y: 170,
              // color: 0xFF000000,
              // lenght: 35,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 186,
              font_array: ["batf_1.png","batf_2.png","batf_3.png","batf_4.png","batf_5.png","batf_6.png","batf_7.png","batf_8.png","batf_9.png","batf_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'batf_11.png',
              unit_tc: 'batf_11.png',
              unit_en: 'batf_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 349,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dicon_1.png',
              unit_tc: 'dicon_1.png',
              unit_en: 'dicon_1.png',
              dot_image: 'wnum_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 349,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 97,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zona1.png","zona2.png","zona3.png","zona4.png","zona5.png","zona6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 155,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 354,
              month_startY: 165,
              month_sc_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              month_tc_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              month_en_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 287,
              day_startY: 165,
              day_sc_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              day_tc_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              day_en_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'smnum_11.png',
              day_unit_tc: 'smnum_11.png',
              day_unit_en: 'smnum_11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 235,
              hour_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'num_11.png',
              hour_unit_tc: 'num_11.png',
              hour_unit_en: 'num_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 208,
              minute_startY: 236,
              minute_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 343,
              second_startY: 263,
              second_array: ["snum_1.png","snum_2.png","snum_3.png","snum_4.png","snum_5.png","snum_6.png","snum_7.png","snum_8.png","snum_9.png","snum_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            btn_bezel.addEventListener(hmUI.event.CLICK_DOWN, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              longPress_Timer = timer.createTimer(longPressDelay, 0, showAppScreen1, {});
      
            });
            btn_bezel.addEventListener(hmUI.event.CLICK_UP, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              click_Bezel();
            });

            btn_fonm = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 278,
              y: 35,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_fonm.setProperty(hmUI.prop.VISIBLE, true);

            btn_fonm.addEventListener(hmUI.event.CLICK_DOWN, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              longPress_Timer = timer.createTimer(longPressDelay, 0, showAppScreen2, {});
      
            });
            btn_fonm.addEventListener(hmUI.event.CLICK_UP, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              click_fonm();
            });

      // кнопка включения/отключения ежечасного сигнала
      switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
        x: 204,
        y: 78,
        w: 70,
        h: 70,
        src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
          switch_hourlyVibro.addEventListener(hmUI.event.CLICK_UP, function () {
          toggleEveryHourVibro();
       });


      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 204,
        y: 330,
        w: 70,
        h: 70,
        src: checkBT ? 'slider1_on.png' : 'slider1_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });

            // календарь
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 294,
              y: 140,
              w: 100,
              h: 80,
              text: '',
              normal_src: '',
              press_src: '',
              click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
             });	

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bezel_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 0,
              y: 0,
              src: 'system_disconnect.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 76,
              // start_y: 170,
              // color: 0xFFFFFFFF,
              // lenght: 35,
              // line_width: 12,
              // line_cap: Flat,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 69,
              y: 186,
              font_array: ["aod_batf_1.png","aod_batf_2.png","aod_batf_3.png","aod_batf_4.png","aod_batf_5.png","aod_batf_6.png","aod_batf_7.png","aod_batf_8.png","aod_batf_9.png","aod_batf_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aod_batf_11.png',
              unit_tc: 'aod_batf_11.png',
              unit_en: 'aod_batf_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 296,
              y: 349,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'dicon_1.png',
              unit_tc: 'dicon_1.png',
              unit_en: 'dicon_1.png',
              dot_image: 'wnum_11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 149,
              y: 349,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 153,
              y: 97,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zona1.png","zona2.png","zona3.png","zona4.png","zona5.png","zona6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 133,
              y: 155,
              week_en: ["aod_dn_1.png","aod_dn_2.png","aod_dn_3.png","aod_dn_4.png","aod_dn_5.png","aod_dn_6.png","aod_dn_7.png"],
              week_tc: ["aod_dn_1.png","aod_dn_2.png","aod_dn_3.png","aod_dn_4.png","aod_dn_5.png","aod_dn_6.png","aod_dn_7.png"],
              week_sc: ["aod_dn_1.png","aod_dn_2.png","aod_dn_3.png","aod_dn_4.png","aod_dn_5.png","aod_dn_6.png","aod_dn_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 354,
              month_startY: 165,
              month_sc_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              month_tc_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              month_en_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 287,
              day_startY: 165,
              day_sc_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              day_tc_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              day_en_array: ["aod_smnum_1.png","aod_smnum_2.png","aod_smnum_3.png","aod_smnum_4.png","aod_smnum_5.png","aod_smnum_6.png","aod_smnum_7.png","aod_smnum_8.png","aod_smnum_9.png","aod_smnum_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'aod_smnum_11.png',
              day_unit_tc: 'aod_smnum_11.png',
              day_unit_en: 'aod_smnum_11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 235,
              hour_array: ["aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png","aod_num_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'aod_num_11.png',
              hour_unit_tc: 'aod_num_11.png',
              hour_unit_en: 'aod_num_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 208,
              minute_startY: 236,
              minute_array: ["aod_num_1.png","aod_num_2.png","aod_num_3.png","aod_num_4.png","aod_num_5.png","aod_num_6.png","aod_num_7.png","aod_num_8.png","aod_num_9.png","aod_num_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 343,
              second_startY: 263,
              second_array: ["aod_snum_1.png","aod_snum_2.png","aod_snum_3.png","aod_snum_4.png","aod_snum_5.png","aod_snum_6.png","aod_snum_7.png","aod_snum_8.png","aod_snum_9.png","aod_snum_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 400,
              y: 190,
              w: 80,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 190,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 99,
              y: 36,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 337,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 76;
                  let start_y_normal_battery = 170;
                  let lenght_ls_normal_battery = 35;
                  let line_width_ls_normal_battery = 12;
                  let color_ls_normal_battery = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 76;
                  let start_y_idle_battery = 170;
                  let lenght_ls_idle_battery = 35;
                  let line_width_ls_idle_battery = 12;
                  let color_ls_idle_battery = 0xFFFFFFFF;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                stopVibro();
                checkConnection(checkBT);
                //autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),

            });
            setEveryHourVibro();

                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}