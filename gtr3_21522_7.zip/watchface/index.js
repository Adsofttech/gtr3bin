﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'Background_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 390,
              month_startY: 209,
              month_sc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_tc_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_en_array: ["97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 358,
              day_startY: 212,
              day_sc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_tc_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_en_array: ["10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Seconds_dot.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 0,
              second_posY: 220,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 95,
              hour_startY: 160,
              hour_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 225,
              minute_startY: 160,
              minute_array: ["33.png","34.png","35.png","36.png","37.png","38.png","39.png","40.png","41.png","42.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 90,
              y: 175,
              w: 250,
              h: 100,
              src: '01.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 345,
              y: 175,
              w: 100,
              h: 100,
              src: '01.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });




            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  