﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_sun_current_text_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_pai_pointer_progress_img_pointer = ''
        let normal_pai_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_pointer_progress_img_pointer = ''
        let normal_calorie_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

// Start Change content
        let btnchangecontent = ''
        let contentnumber = 0
        let totalcontent = 5

        function click_Changecontent() {
          contentnumber=contentnumber+1;
          switch (contentnumber) {
            case 1:
              Changecontent(1); break;
            case 2:
              Changecontent(2); break;
            case 3:
              Changecontent(3); break;
			case 4:
              Changecontent(4); break;
			case 5:
              Changecontent(5); break;
            default:
              Changecontent(0); contentnumber=0;
          }
          if(contentnumber==1) hmUI.showToast({text: 'STEPS'});
          if(contentnumber==2) hmUI.showToast({text: 'HEARTRATE'});
          if(contentnumber==3) hmUI.showToast({text: 'CALORIE'});
		  if(contentnumber==4) hmUI.showToast({text: 'P A I'});
		  if(contentnumber==5) hmUI.showToast({text: 'SUN and MOON'});
		  if(contentnumber==0) hmUI.showToast({text: 'WEATHER'});
        }

// Give contentnumber
        function Changecontent(number) {
           if(number==1) {
                  UpdatecontentSteps();
             } else if(number==2) {
                  UpdatecontentPulse();
             } else if(number==3) {
                  UpdatecontentCal();
			 } else if(number==4) {
                  UpdatecontentPai();
			 } else if(number==5) {
                  UpdatecontentSun();
             } else {
                  UpdatecontentWeather();
             }
        }

        function UpdatecontentSteps(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
        }

        function UpdatecontentPulse(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }

        function UpdatecontentCal(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }

		function UpdatecontentPai(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, true);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		function UpdatecontentSun(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }
		
		function UpdatecontentWeather(){
                normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
                normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
                normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
                normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
				normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
        }
// END Change content
		
// Start color change
        let btncolor = ''
        let colornumber = 0
        let totalcolors = 7

        function click_Color() {
            if(colornumber==totalcolors) {
            colornumber=0;
                }
            else {
                colornumber=colornumber+1;
            }
		  if(colornumber==1) hmUI.showToast({text: 'Dark'});
          if(colornumber==2) hmUI.showToast({text: 'Red'});
          if(colornumber==3) hmUI.showToast({text: 'Black'});
		  if(colornumber==4) hmUI.showToast({text: 'Blue'});
		  if(colornumber==5) hmUI.showToast({text: 'Yellow'});
          if(colornumber==6) hmUI.showToast({text: 'Orange'});
          if(colornumber==7) hmUI.showToast({text: 'Green'});
		  if(colornumber==0) hmUI.showToast({text: 'Light'});
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bg" + parseInt(colornumber) + ".png");
            call_change_Hands();
        }

	// Change hands called by backgroundcolor (default color with background)
        function call_change_Hands() {
              if(colornumber==1) {
                ChangeHands(1);
              } else if(colornumber==2) {
                ChangeHands(1);
              } else if(colornumber==3) {
                ChangeHands(1);
			  } else if(colornumber==4) {
                ChangeHands(1);
              } else if(colornumber==5) {
                ChangeHands(0);
			  } else if(colornumber==6) {
                ChangeHands(0);
              } else if(colornumber==7) {
                ChangeHands(1);
              } else if(colornumber==0) {
                ChangeHands(0);
              }
        }
		
		function ChangeHands(number) {
           if(number==1) {
                  hourstring='hour3.png';
                  minutestring='min3.png';
				  secondstring='sec3.png';
				  pointerstring='pointer3.png';
				  fontstring=["lightnum_00.png","lightnum_01.png","lightnum_02.png","lightnum_03.png","lightnum_04.png","lightnum_05.png","lightnum_06.png","lightnum_07.png","lightnum_08.png","lightnum_09.png"];
				  weather_imagestring=["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"];
				  negative_imagestring='lightnum_11.png';
				  unit_weatherstring='lightnum_14.png';
				  dot_imagestring='lightnum_12.png';
				  separatorstring='lightnum_15.png';
				  unknownstring='lightnum_10.png';
				  sym_stepsstring='syml_steps.png';
				  sym_pulsesstring='syml_pulse.png';
				  sym_paisstring='syml_pai.png';
				  sym_calsstring='syml_cal.png';
            } else {
                  hourstring='hour0.png';
                  minutestring='min0.png';
				  secondstring='sec0.png';
				  pointerstring='pointer0.png';
				  fontstring=["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"];
				  weather_imagestring=["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"];
				  negative_imagestring='darknum_11.png';
				  unit_weatherstring='darknum_14.png';
				  dot_imagestring='darknum_12.png';
				  separatorstring='darknum_15.png';
				  unknownstring='darknum_10.png';
				  sym_stepsstring='symd_steps.png';
				  sym_pulsesstring='symd_pulse.png';
				  sym_paisstring='symd_pai.png';
				  sym_calsstring='symd_cal.png';
             }
			 
			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
			  hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minutestring,
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: secondstring,
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_sun_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 203,
              y: 317,
              font_array: fontstring,
              padding: false,
              h_space: 0,
              invalid_image: unknownstring,
              dot_image: dot_imagestring,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_pai_weekly_text_img.setProperty(hmUI.prop.MORE, {
              x: 217,
              y: 318,
              font_array: fontstring,
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_pai_icon_img.setProperty(hmUI.prop.MORE, {
              x: 209,
              y: 401,
              src: sym_paisstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.MORE, {
              x: 217,
              y: 317,
              font_array: fontstring,
              padding: true,
              h_space: 2,
              invalid_image: unknownstring,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img.setProperty(hmUI.prop.MORE, {
              x: 209,
              y: 401,
              src: sym_pulsesstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 210,
              y: 317,
              font_array: fontstring,
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img.setProperty(hmUI.prop.MORE, {
              x: 209,
              y: 401,
              src: sym_calsstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 207,
              y: 317,
              font_array: fontstring,
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img.setProperty(hmUI.prop.MORE, {
              x: 209,
              y: 401,
              src: sym_stepsstring,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_temperature_current_text_img.setProperty(hmUI.prop.MORE, {
              x: 214,
              y: 317,
              font_array: fontstring,
              padding: false,
              h_space: 1,
              unit_sc: unit_weatherstring,
              unit_tc: unit_weatherstring,
              unit_en: unit_weatherstring,
              negative_image: negative_imagestring,
              invalid_image: unknownstring,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level.setProperty(hmUI.prop.MORE, {
              x: 202,
              y: 344,
              image_array: weather_imagestring,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: pointerstring,
              center_x: 239,
              center_y: 100,
              x: 119,
              y: 119,
              start_angle: 28,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
		}

//dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
//dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 215,
              y: 357,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_moon_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 203,
              y: 317,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'darknum_10.png',
              dot_image: 'darknum_15.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 318,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: true,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_weekly_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer0.png',
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 401,
              src: 'symd_pai.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 217,
              y: 317,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: true,
              h_space: 2,
              invalid_image: 'darknum_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer0.png',
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 401,
              src: 'symd_pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 317,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer0.png',
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 401,
              src: 'symd_cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 207,
              y: 317,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer0.png',
              center_x: 239,
              center_y: 380,
              x: 119,
              y: 119,
              start_angle: -48,
              end_angle: -312,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 209,
              y: 401,
              src: 'symd_steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 317,
              font_array: ["darknum_00.png","darknum_01.png","darknum_02.png","darknum_03.png","darknum_04.png","darknum_05.png","darknum_06.png","darknum_07.png","darknum_08.png","darknum_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'darknum_14.png',
              unit_tc: 'darknum_14.png',
              unit_en: 'darknum_14.png',
              negative_image: 'darknum_11.png',
              invalid_image: 'darknum_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 344,
              image_array: ["weatherd_00.png","weatherd_01.png","weatherd_02.png","weatherd_03.png","weatherd_04.png","weatherd_05.png","weatherd_06.png","weatherd_07.png","weatherd_08.png","weatherd_09.png","weatherd_10.png","weatherd_11.png","weatherd_12.png","weatherd_13.png","weatherd_14.png","weatherd_15.png","weatherd_16.png","weatherd_17.png","weatherd_18.png","weatherd_19.png","weatherd_20.png","weatherd_21.png","weatherd_22.png","weatherd_23.png","weatherd_24.png","weatherd_25.png","weatherd_26.png","weatherd_27.png","weatherd_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer0.png',
              center_x: 239,
              center_y: 100,
              x: 119,
              y: 119,
              start_angle: 28,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 229,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 406,
              day_startY: 229,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min0.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec0.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 239,
              second_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
//Set Weather first
//			UpdatecontentWeather();

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 317,
              font_array: ["lightnum_00.png","lightnum_01.png","lightnum_02.png","lightnum_03.png","lightnum_04.png","lightnum_05.png","lightnum_06.png","lightnum_07.png","lightnum_08.png","lightnum_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'lightnum_14.png',
              unit_tc: 'lightnum_14.png',
              unit_en: 'lightnum_14.png',
              negative_image: 'lightnum_11.png',
              invalid_image: 'lightnum_10.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 202,
              y: 344,
              image_array: ["weatherl_00.png","weatherl_01.png","weatherl_02.png","weatherl_03.png","weatherl_04.png","weatherl_05.png","weatherl_06.png","weatherl_07.png","weatherl_08.png","weatherl_09.png","weatherl_10.png","weatherl_11.png","weatherl_12.png","weatherl_13.png","weatherl_14.png","weatherl_15.png","weatherl_16.png","weatherl_17.png","weatherl_18.png","weatherl_19.png","weatherl_20.png","weatherl_21.png","weatherl_22.png","weatherl_23.png","weatherl_24.png","weatherl_25.png","weatherl_26.png","weatherl_27.png","weatherl_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer3.png',
              center_x: 239,
              center_y: 100,
              x: 119,
              y: 119,
              start_angle: 28,
              end_angle: 330,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 310,
              month_startY: 229,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 406,
              day_startY: 229,
              day_sc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_tc_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_en_array: ["day_00.png","day_01.png","day_02.png","day_03.png","day_04.png","day_05.png","day_06.png","day_07.png","day_08.png","day_09.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aod_hour.png',
              hour_centerX: 239,
              hour_centerY: 240,
              hour_posX: 239,
              hour_posY: 239,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aod_min.png',
              minute_centerX: 239,
              minute_centerY: 240,
              minute_posX: 239,
              minute_posY: 239,
              minute_cover_path: 'aod_overlay.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 330,
              y: 90,
              w: 100,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 90,
              w: 100,
              h: 100,
              src: 'blank.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.STRESS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_stress_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 170,
              y: 310,
              w: 140,
              h: 140,
              src: 'blank.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

// START Battery Shortcut            
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 170,
              y: 30,
              w: 140,
              h: 140,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true })
            });
// END Battery Shortcut
// START Calendar Shortcut
			normal_img_click_1 = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 205,
              w: 165,
              h: 75,
              src: 'blank.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_img_click_1.addEventListener(hmUI.event.CLICK_DOWN, function (info) {
			hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true })
            });
// END Calendar Shortcut					
// Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: 'blank.png',
              press_src: 'blank.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
// Change color background shortcut end	
// Change content shortcut start
            btnchangecontent = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 205,
              text: '',
              w: 165,
              h: 75,
              normal_src: 'blank.png',
			  press_src: 'blank.png',
              click_func: () => {
               click_Changecontent();
              },
			show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btnchangecontent.setProperty(hmUI.prop.VISIBLE, true);
// Change content shortcut end

			
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 0,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 25,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(0);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(25);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                checkConnection();

              }),
              pause_call: (function () {
                stopVibro();
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
