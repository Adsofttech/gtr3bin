﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

       // start user_functions.js

        // Change Arry Data
          
        let btn_element_4= ''
        let elementnumber_4= 1
        let total_elemente4 = 5
        let array_step = ["Act_1_0.png","Act_1_1.png","Act_1_2.png","Act_1_3.png","Act_1_4.png","Act_1_5.png","Act_1_6.png","Act_1_7.png","Act_1_8.png","Act_1_9.png"];   
        let array_day = ["Day_1_0.png","Day_1_1.png","Day_1_2.png","Day_1_3.png","Day_1_4.png","Day_1_5.png","Day_1_6.png","Day_1_7.png","Day_1_8.png","Day_1_9.png"];
        let array_batt = ["Batt_1_0.png","Batt_1_1.png","Batt_1_2.png","Batt_1_3.png","Batt_1_4.png","Batt_1_5.png","Batt_1_6.png","Batt_1_7.png","Batt_1_8.png","Batt_1_9.png"];
        function click_elemente4() {
            if(elementnumber_4==total_elemente4) {
            elementnumber_4=1;

                UpdateElemente4One();
                }
            else {
                elementnumber_4=elementnumber_4+1;
                if(elementnumber_4==2) {

                  UpdateElemente4Two();
                }
                if(elementnumber_4==3) {

                  UpdateElemente4Three();
                }
                if(elementnumber_4==4) {

                  UpdateElemente4Four();
                }
                if(elementnumber_4==5) {

                  UpdateElemente4Five();
                }
       

            }
            if(elementnumber_4==1) hmUI.showToast({text: 'Orange'});
            if(elementnumber_4==2) hmUI.showToast({text: 'Blue'});
            if(elementnumber_4==3) hmUI.showToast({text: 'Green'});
            if(elementnumber_4==4) hmUI.showToast({text: 'Red'});
            if(elementnumber_4==5) hmUI.showToast({text: 'Lemon'});

           normal_battery_icon_img.setProperty(hmUI.prop.SRC, "batt_symbo" + parseInt(elementnumber_4) + ".png");
           normal_image_img.setProperty(hmUI.prop.SRC, "DotT" + parseInt(elementnumber_4) + ".png");
           normal_heart_rate_icon_img.setProperty(hmUI.prop.SRC, "icon_pulse" + parseInt(elementnumber_4) + ".png");


            normal_digital_clock_img_time_AmPm.setProperty(hmUI.prop.MORE, {
              am_x: 322,
              am_y: 90,
              am_sc_path: "Clock_AM" + parseInt(elementnumber_4) + ".png",
              am_en_path: "Clock_AM" + parseInt(elementnumber_4) + ".png",
              pm_x: 322,
              pm_y: 90,
              pm_sc_path: "Clock_PM" + parseInt(elementnumber_4) + ".png",
              pm_en_path: "Clock_PM" + parseInt(elementnumber_4) + ".png",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


        }

        //orange
        function UpdateElemente4One(){
array_step.splice(0, 1, "Act_1_0.png");
array_step.splice(1, 1, "Act_1_1.png");
array_step.splice(2, 1, "Act_1_2.png");
array_step.splice(3, 1, "Act_1_3.png");
array_step.splice(4, 1, "Act_1_4.png");
array_step.splice(5, 1, "Act_1_5.png");
array_step.splice(6, 1, "Act_1_6.png");
array_step.splice(7, 1, "Act_1_7.png");
array_step.splice(8, 1, "Act_1_8.png");
array_step.splice(9, 1, "Act_1_9.png");

array_day.splice(0, 1, "Day_1_0.png");
array_day.splice(1, 1, "Day_1_1.png");
array_day.splice(2, 1, "Day_1_2.png");
array_day.splice(3, 1, "Day_1_3.png");
array_day.splice(4, 1, "Day_1_4.png");
array_day.splice(5, 1, "Day_1_5.png");
array_day.splice(6, 1, "Day_1_6.png");
array_day.splice(7, 1, "Day_1_7.png");
array_day.splice(8, 1, "Day_1_8.png");
array_day.splice(9, 1, "Day_1_9.png");


array_batt.splice(0, 1, "Batt_1_0.png");
array_batt.splice(1, 1, "Batt_1_1.png");
array_batt.splice(2, 1, "Batt_1_2.png");
array_batt.splice(3, 1, "Batt_1_3.png");
array_batt.splice(4, 1, "Batt_1_4.png");
array_batt.splice(5, 1, "Batt_1_5.png");
array_batt.splice(6, 1, "Batt_1_6.png");
array_batt.splice(7, 1, "Batt_1_7.png");
array_batt.splice(8, 1, "Batt_1_8.png");
array_batt.splice(9, 1, "Batt_1_9.png");
const result = hmSetting.setScreenOff()

        }

        //blue
        function UpdateElemente4Two(){
array_step.splice(0, 1, "Act_2_0.png");
array_step.splice(1, 1, "Act_2_1.png");
array_step.splice(2, 1, "Act_2_2.png");
array_step.splice(3, 1, "Act_2_3.png");
array_step.splice(4, 1, "Act_2_4.png");
array_step.splice(5, 1, "Act_2_5.png");
array_step.splice(6, 1, "Act_2_6.png");
array_step.splice(7, 1, "Act_2_7.png");
array_step.splice(8, 1, "Act_2_8.png");
array_step.splice(9, 1, "Act_2_9.png");

array_day.splice(0, 1, "Day_2_0.png");
array_day.splice(1, 1, "Day_2_1.png");
array_day.splice(2, 1, "Day_2_2.png");
array_day.splice(3, 1, "Day_2_3.png");
array_day.splice(4, 1, "Day_2_4.png");
array_day.splice(5, 1, "Day_2_5.png");
array_day.splice(6, 1, "Day_2_6.png");
array_day.splice(7, 1, "Day_2_7.png");
array_day.splice(8, 1, "Day_2_8.png");
array_day.splice(9, 1, "Day_2_9.png");


array_batt.splice(0, 1, "Batt_2_0.png");
array_batt.splice(1, 1, "Batt_2_1.png");
array_batt.splice(2, 1, "Batt_2_2.png");
array_batt.splice(3, 1, "Batt_2_3.png");
array_batt.splice(4, 1, "Batt_2_4.png");
array_batt.splice(5, 1, "Batt_2_5.png");
array_batt.splice(6, 1, "Batt_2_6.png");
array_batt.splice(7, 1, "Batt_2_7.png");
array_batt.splice(8, 1, "Batt_2_8.png");
array_batt.splice(9, 1, "Batt_2_9.png");

const result = hmSetting.setScreenOff()
        }

/// Green
        function UpdateElemente4Three(){
array_step.splice(0, 1, "Act_3_0.png");
array_step.splice(1, 1, "Act_3_1.png");
array_step.splice(2, 1, "Act_3_2.png");
array_step.splice(3, 1, "Act_3_3.png");
array_step.splice(4, 1, "Act_3_4.png");
array_step.splice(5, 1, "Act_3_5.png");
array_step.splice(6, 1, "Act_3_6.png");
array_step.splice(7, 1, "Act_3_7.png");
array_step.splice(8, 1, "Act_3_8.png");
array_step.splice(9, 1, "Act_3_9.png");

array_day.splice(0, 1, "Day_3_0.png");
array_day.splice(1, 1, "Day_3_1.png");
array_day.splice(2, 1, "Day_3_2.png");
array_day.splice(3, 1, "Day_3_3.png");
array_day.splice(4, 1, "Day_3_4.png");
array_day.splice(5, 1, "Day_3_5.png");
array_day.splice(6, 1, "Day_3_6.png");
array_day.splice(7, 1, "Day_3_7.png");
array_day.splice(8, 1, "Day_3_8.png");
array_day.splice(9, 1, "Day_3_9.png");


array_batt.splice(0, 1, "Batt_3_0.png");
array_batt.splice(1, 1, "Batt_3_1.png");
array_batt.splice(2, 1, "Batt_3_2.png");
array_batt.splice(3, 1, "Batt_3_3.png");
array_batt.splice(4, 1, "Batt_3_4.png");
array_batt.splice(5, 1, "Batt_3_5.png");
array_batt.splice(6, 1, "Batt_3_6.png");
array_batt.splice(7, 1, "Batt_3_7.png");
array_batt.splice(8, 1, "Batt_3_8.png");
array_batt.splice(9, 1, "Batt_3_9.png");
const result = hmSetting.setScreenOff()
        }

/// Red
        function UpdateElemente4Four(){
array_step.splice(0, 1, "Act_4_0.png");
array_step.splice(1, 1, "Act_4_1.png");
array_step.splice(2, 1, "Act_4_2.png");
array_step.splice(3, 1, "Act_4_3.png");
array_step.splice(4, 1, "Act_4_4.png");
array_step.splice(5, 1, "Act_4_5.png");
array_step.splice(6, 1, "Act_4_6.png");
array_step.splice(7, 1, "Act_4_7.png");
array_step.splice(8, 1, "Act_4_8.png");
array_step.splice(9, 1, "Act_4_9.png");

array_day.splice(0, 1, "Day_4_0.png");
array_day.splice(1, 1, "Day_4_1.png");
array_day.splice(2, 1, "Day_4_2.png");
array_day.splice(3, 1, "Day_4_3.png");
array_day.splice(4, 1, "Day_4_4.png");
array_day.splice(5, 1, "Day_4_5.png");
array_day.splice(6, 1, "Day_4_6.png");
array_day.splice(7, 1, "Day_4_7.png");
array_day.splice(8, 1, "Day_4_8.png");
array_day.splice(9, 1, "Day_4_9.png");


array_batt.splice(0, 1, "Batt_4_0.png");
array_batt.splice(1, 1, "Batt_4_1.png");
array_batt.splice(2, 1, "Batt_4_2.png");
array_batt.splice(3, 1, "Batt_4_3.png");
array_batt.splice(4, 1, "Batt_4_4.png");
array_batt.splice(5, 1, "Batt_4_5.png");
array_batt.splice(6, 1, "Batt_4_6.png");
array_batt.splice(7, 1, "Batt_4_7.png");
array_batt.splice(8, 1, "Batt_4_8.png");
array_batt.splice(9, 1, "Batt_4_9.png");
const result = hmSetting.setScreenOff()

        }

/// lemon
        function UpdateElemente4Five(){
array_step.splice(0, 1, "Act_5_0.png");
array_step.splice(1, 1, "Act_5_1.png");
array_step.splice(2, 1, "Act_5_2.png");
array_step.splice(3, 1, "Act_5_3.png");
array_step.splice(4, 1, "Act_5_4.png");
array_step.splice(5, 1, "Act_5_5.png");
array_step.splice(6, 1, "Act_5_6.png");
array_step.splice(7, 1, "Act_5_7.png");
array_step.splice(8, 1, "Act_5_8.png");
array_step.splice(9, 1, "Act_5_9.png");

array_day.splice(0, 1, "Day_5_0.png");
array_day.splice(1, 1, "Day_5_1.png");
array_day.splice(2, 1, "Day_5_2.png");
array_day.splice(3, 1, "Day_5_3.png");
array_day.splice(4, 1, "Day_5_4.png");
array_day.splice(5, 1, "Day_5_5.png");
array_day.splice(6, 1, "Day_5_6.png");
array_day.splice(7, 1, "Day_5_7.png");
array_day.splice(8, 1, "Day_5_8.png");
array_day.splice(9, 1, "Day_5_9.png");


array_batt.splice(0, 1, "Batt_5_0.png");
array_batt.splice(1, 1, "Batt_5_1.png");
array_batt.splice(2, 1, "Batt_5_2.png");
array_batt.splice(3, 1, "Batt_5_3.png");
array_batt.splice(4, 1, "Batt_5_4.png");
array_batt.splice(5, 1, "Batt_5_5.png");
array_batt.splice(6, 1, "Batt_5_6.png");
array_batt.splice(7, 1, "Batt_5_7.png");
array_batt.splice(8, 1, "Batt_5_8.png");
array_batt.splice(9, 1, "Batt_5_9.png");

const result = hmSetting.setScreenOff()
        }

        // end user_functions.js



        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_image_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_second = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_battery_icon_img = ''
        let idle_battery_text_text_img = ''
        let idle_heart_rate_icon_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_day = ''
        let idle_image_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_second = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''



        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 407,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 402,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 27,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 324,
              y: 396,
              src: 'batt_symbo1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 396,
              font_array: array_batt,
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 363,
              src: 'icon_pulse1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 355,
              font_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 255,
              y: 174,
              w: 176,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 132,
              font_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 131,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 310,
              font_array: array_step,
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 352,
              year_startY: 209,
              year_sc_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_tc_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_en_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 353,
              month_startY: 238,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 263,
              y: 274,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 213,
              day_sc_array: array_day,
              day_tc_array: array_day,
              day_en_array: array_day,
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 212,
              src: 'DotT1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 322,
              am_y: 90,
              am_sc_path: 'Clock_AM1.png',
              am_en_path: 'Clock_AM1.png',
              pm_x: 322,
              pm_y: 90,
              pm_sc_path: 'Clock_PM1.png',
              pm_en_path: 'Clock_PM1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 264,
              second_startY: 82,
              second_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 46,
              minute_startY: 227,
              minute_array: ["Time_H2_0.png","Time_H2_1.png","Time_H2_2.png","Time_H2_3.png","Time_H2_4.png","Time_H2_5.png","Time_H2_6.png","Time_H2_7.png","Time_H2_8.png","Time_H2_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 99,
              hour_array: ["Time_H1_0.png","Time_H1_1.png","Time_H1_2.png","Time_H1_3.png","Time_H1_4.png","Time_H1_5.png","Time_H1_6.png","Time_H1_7.png","Time_H1_8.png","Time_H1_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 214,
              y: 407,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 178,
              y: 402,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 160,
              y: 27,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 324,
              y: 396,
              src: 'batt_symbo1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 396,
              font_array: ["Batt_1_0.png","Batt_1_1.png","Batt_1_2.png","Batt_1_3.png","Batt_1_4.png","Batt_1_5.png","Batt_1_6.png","Batt_1_7.png","Batt_1_8.png","Batt_1_9.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 268,
              y: 363,
              src: 'icon_pulse1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 299,
              y: 355,
              font_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 255,
              y: 174,
              w: 176,
              h: 30,
              text_size: 23,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 132,
              font_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'weather_symbo1.png',
              unit_tc: 'weather_symbo1.png',
              unit_en: 'weather_symbo1.png',
              negative_image: 'weather_symbo2.png',
              invalid_image: 'weather_symbo2.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 274,
              y: 131,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 310,
              font_array: ["Act_1_0.png","Act_1_1.png","Act_1_2.png","Act_1_3.png","Act_1_4.png","Act_1_5.png","Act_1_6.png","Act_1_7.png","Act_1_8.png","Act_1_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 352,
              year_startY: 209,
              year_sc_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_tc_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_en_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 353,
              month_startY: 238,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 263,
              y: 274,
              week_en: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_tc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              week_sc: ["Week_icon_01.png","Week_icon_02.png","Week_icon_03.png","Week_icon_04.png","Week_icon_05.png","Week_icon_06.png","Week_icon_07.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 271,
              day_startY: 213,
              day_sc_array: ["Day_1_0.png","Day_1_1.png","Day_1_2.png","Day_1_3.png","Day_1_4.png","Day_1_5.png","Day_1_6.png","Day_1_7.png","Day_1_8.png","Day_1_9.png"],
              day_tc_array: ["Day_1_0.png","Day_1_1.png","Day_1_2.png","Day_1_3.png","Day_1_4.png","Day_1_5.png","Day_1_6.png","Day_1_7.png","Day_1_8.png","Day_1_9.png"],
              day_en_array: ["Day_1_0.png","Day_1_1.png","Day_1_2.png","Day_1_3.png","Day_1_4.png","Day_1_5.png","Day_1_6.png","Day_1_7.png","Day_1_8.png","Day_1_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 25,
              y: 212,
              src: 'DotT1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 322,
              am_y: 90,
              am_sc_path: 'Clock_AM1.png',
              am_en_path: 'Clock_AM1.png',
              pm_x: 322,
              pm_y: 90,
              pm_sc_path: 'Clock_PM1.png',
              pm_en_path: 'Clock_PM1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_second = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              second_startX: 264,
              second_startY: 82,
              second_array: ["act_gray0.png","act_gray1.png","act_gray2.png","act_gray3.png","act_gray4.png","act_gray5.png","act_gray6.png","act_gray7.png","act_gray8.png","act_gray9.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 46,
              minute_startY: 227,
              minute_array: ["Time_H2_0.png","Time_H2_1.png","Time_H2_2.png","Time_H2_3.png","Time_H2_4.png","Time_H2_5.png","Time_H2_6.png","Time_H2_7.png","Time_H2_8.png","Time_H2_9.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 46,
              hour_startY: 99,
              hour_array: ["Time_H1_0.png","Time_H1_1.png","Time_H1_2.png","Time_H1_3.png","Time_H1_4.png","Time_H1_5.png","Time_H1_6.png","Time_H1_7.png","Time_H1_8.png","Time_H1_9.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'img_top.png',
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 107,
              y: 254,
              w: 100,
              h: 100,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 101,
              y: 121,
              w: 100,
              h: 100,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 165,
              y: 393,
              w: 51,
              h: 39,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 25,
              w: 72,
              h: 61,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 129,
              w: 123,
              h: 33,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 262,
              y: 354,
              w: 32,
              h: 31,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 302,
              y: 352,
              w: 71,
              h: 33,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 305,
              w: 144,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 256,
              y: 35,
              w: 70,
              h: 48,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'SportListScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 279,
              y: 203,
              w: 141,
              h: 57,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '0_Empty.png',
              normal_src: '0_Empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            function scale_call() {

              console.log('Weather city name');
              let weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Weather city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

       // Change background shortcut start
            btn_element_4= hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 15,
              y: 203,
              text: '',
              w: 54,
              h: 54,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_elemente4();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_element_4.setProperty(hmUI.prop.VISIBLE, true);
            // Change background shortcut end

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}