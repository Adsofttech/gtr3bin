﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_frame_animation_1 = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_image_img = ''
        let normal_hour_TextRotate = new Array(2);
        let normal_hour_TextRotate_ASCIIARRAY = new Array(10);
        let normal_hour_TextRotate_img_width = 93;
        let normal_timerTextUpdate = undefined;
        let normal_second_TextRotate = new Array(2);
        let normal_second_TextRotate_ASCIIARRAY = new Array(10);
        let normal_second_TextRotate_img_width = 93;
        let normal_minute_TextRotate = new Array(2);
        let normal_minute_TextRotate_ASCIIARRAY = new Array(10);
        let normal_minute_TextRotate_img_width = 93;
        let idle_background_bg = ''
        let idle_hour_TextRotate = new Array(2);
        let idle_hour_TextRotate_ASCIIARRAY = new Array(10);
        let idle_hour_TextRotate_img_width = 93;
        let idle_timerTextUpdate = undefined;
        let idle_second_TextRotate = new Array(2);
        let idle_second_TextRotate_ASCIIARRAY = new Array(10);
        let idle_second_TextRotate_img_width = 93;
        let idle_minute_TextRotate = new Array(2);
        let idle_minute_TextRotate_ASCIIARRAY = new Array(10);
        let idle_minute_TextRotate_img_width = 93;
        let idle_image_img = ''
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "anim",
              anim_fps: 15,
              anim_size: 128,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: '006.png',
              // center_x: 240,
              // center_y: 240,
              // x: 1,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 1,
              pos_y: 240 - 238,
              center_x: 240,
              center_y: 240,
              src: '006.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -20,
              y: 97,
              src: '004.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 0,
              // y: 135,
              // font_array: ["th00.png","th01.png","th02.png","th03.png","th04.png","th05.png","th06.png","th07.png","th08.png","th09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -30,
              // angle: -15,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_hour_TextRotate_ASCIIARRAY[0] = 'th00.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[1] = 'th01.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[2] = 'th02.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[3] = 'th03.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[4] = 'th04.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[5] = 'th05.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[6] = 'th06.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[7] = 'th07.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[8] = 'th08.png';  // set of images with numbers
            normal_hour_TextRotate_ASCIIARRAY[9] = 'th09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 0,
                center_y: 135,
                pos_x: 0,
                pos_y: 135,
                angle: -15,
                src: 'th00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);

            // normal_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 470,
              // y: 135,
              // font_array: ["ts00.png","ts01.png","ts02.png","ts03.png","ts04.png","ts05.png","ts06.png","ts07.png","ts08.png","ts09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 15,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_second_TextRotate_ASCIIARRAY[0] = 'ts00.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[1] = 'ts01.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[2] = 'ts02.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[3] = 'ts03.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[4] = 'ts04.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[5] = 'ts05.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[6] = 'ts06.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[7] = 'ts07.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[8] = 'ts08.png';  // set of images with numbers
            normal_second_TextRotate_ASCIIARRAY[9] = 'ts09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 470,
                center_y: 135,
                pos_x: 470,
                pos_y: 135,
                angle: 15,
                src: 'ts00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // normal_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 226,
              // y: 98,
              // font_array: ["tm00.png","tm01.png","tm02.png","tm03.png","tm04.png","tm05.png","tm06.png","tm07.png","tm08.png","tm09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_minute_TextRotate_ASCIIARRAY[0] = 'tm00.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[1] = 'tm01.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[2] = 'tm02.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[3] = 'tm03.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[4] = 'tm04.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[5] = 'tm05.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[6] = 'tm06.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[7] = 'tm07.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[8] = 'tm08.png';  // set of images with numbers
            normal_minute_TextRotate_ASCIIARRAY[9] = 'tm09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              normal_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 226,
                center_y: 98,
                pos_x: 226,
                pos_y: 98,
                angle: 0,
                src: 'tm00.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_hour_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 0,
              // y: 135,
              // font_array: ["th00.png","th01.png","th02.png","th03.png","th04.png","th05.png","th06.png","th07.png","th08.png","th09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -30,
              // angle: -15,
              // align_h: hmUI.align.LEFT,
              // type: hmUI.data_type.HOUR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_hour_TextRotate_ASCIIARRAY[0] = 'th00.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[1] = 'th01.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[2] = 'th02.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[3] = 'th03.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[4] = 'th04.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[5] = 'th05.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[6] = 'th06.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[7] = 'th07.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[8] = 'th08.png';  // set of images with numbers
            idle_hour_TextRotate_ASCIIARRAY[9] = 'th09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_hour_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 0,
                center_y: 135,
                pos_x: 0,
                pos_y: 135,
                angle: -15,
                src: 'th00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_second_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 470,
              // y: 135,
              // font_array: ["ts00.png","ts01.png","ts02.png","ts03.png","ts04.png","ts05.png","ts06.png","ts07.png","ts08.png","ts09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 15,
              // align_h: hmUI.align.RIGHT,
              // type: hmUI.data_type.SECOND,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_second_TextRotate_ASCIIARRAY[0] = 'ts00.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[1] = 'ts01.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[2] = 'ts02.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[3] = 'ts03.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[4] = 'ts04.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[5] = 'ts05.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[6] = 'ts06.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[7] = 'ts07.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[8] = 'ts08.png';  // set of images with numbers
            idle_second_TextRotate_ASCIIARRAY[9] = 'ts09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_second_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 470,
                center_y: 135,
                pos_x: 470,
                pos_y: 135,
                angle: 15,
                src: 'ts00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_minute_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 226,
              // y: 98,
              // font_array: ["tm00.png","tm01.png","tm02.png","tm03.png","tm04.png","tm05.png","tm06.png","tm07.png","tm08.png","tm09.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: -20,
              // angle: 0,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.MINUTE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_minute_TextRotate_ASCIIARRAY[0] = 'tm00.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[1] = 'tm01.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[2] = 'tm02.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[3] = 'tm03.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[4] = 'tm04.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[5] = 'tm05.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[6] = 'tm06.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[7] = 'tm07.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[8] = 'tm08.png';  // set of images with numbers
            idle_minute_TextRotate_ASCIIARRAY[9] = 'tm09.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 2; i++) {
              idle_minute_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 480,
                h: 480,
                center_x: 226,
                center_y: 98,
                pos_x: 226,
                pos_y: 98,
                angle: 0,
                src: 'tm00.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: '003.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            function text_update() {

              console.log('update text rotate hour_TIME');
              let valueHour = timeNaw.hour;
              if (!timeNaw.is24Hour) {
                valueHour -= 12;
                if (valueHour < 1) valueHour += 12;
              };
              let normal_hour_rotate_string = parseInt(valueHour).toString();
              normal_hour_rotate_string = normal_hour_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && normal_hour_rotate_string.length > 0 && normal_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of normal_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 0 + img_offset);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.SRC, normal_hour_TextRotate_ASCIIARRAY[charCode]);
                      normal_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_hour_TextRotate_img_width + -30;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let valueSecond = timeNaw.second;
              let normal_second_rotate_string = parseInt(valueSecond).toString();
              normal_second_rotate_string = normal_second_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && normal_second_rotate_string.length > 0 && normal_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let normal_second_TextRotate_posOffset = normal_second_TextRotate_img_width * normal_second_rotate_string.length;
                  normal_second_TextRotate_posOffset = normal_second_TextRotate_posOffset + -20 * (normal_second_rotate_string.length - 1);
                  img_offset -= normal_second_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 470 + img_offset);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.SRC, normal_second_TextRotate_ASCIIARRAY[charCode]);
                      normal_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_second_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let valueMinute = timeNaw.minute;
              let normal_minute_rotate_string = parseInt(valueMinute).toString();
              normal_minute_rotate_string = normal_minute_rotate_string.padStart(2, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  normal_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && normal_minute_rotate_string.length > 0 && normal_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_minute_TextRotate_posOffset = normal_minute_TextRotate_img_width * normal_minute_rotate_string.length;
                  normal_minute_TextRotate_posOffset = normal_minute_TextRotate_posOffset + -20 * (normal_minute_rotate_string.length - 1);
                  img_offset -= normal_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 226 + img_offset);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.SRC, normal_minute_TextRotate_ASCIIARRAY[charCode]);
                      normal_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_minute_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate hour_TIME');
              let idle_hour_rotate_string = parseInt(valueHour).toString();
              idle_hour_rotate_string = idle_hour_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_hour_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueHour != null && valueHour != undefined && isFinite(valueHour) && idle_hour_rotate_string.length > 0 && idle_hour_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  
                  let index = 0;
                  for (let char of idle_hour_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.POS_X, 0 + img_offset);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.SRC, idle_hour_TextRotate_ASCIIARRAY[charCode]);
                      idle_hour_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_hour_TextRotate_img_width + -30;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate second_TIME');
              let idle_second_rotate_string = parseInt(valueSecond).toString();
              idle_second_rotate_string = idle_second_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_second_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueSecond != null && valueSecond != undefined && isFinite(valueSecond) && idle_second_rotate_string.length > 0 && idle_second_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = RIGHT
                  let idle_second_TextRotate_posOffset = idle_second_TextRotate_img_width * idle_second_rotate_string.length;
                  idle_second_TextRotate_posOffset = idle_second_TextRotate_posOffset + -20 * (idle_second_rotate_string.length - 1);
                  img_offset -= idle_second_TextRotate_posOffset;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_second_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_second_TextRotate[index].setProperty(hmUI.prop.POS_X, 470 + img_offset);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.SRC, idle_second_TextRotate_ASCIIARRAY[charCode]);
                      idle_second_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_second_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate minute_TIME');
              let idle_minute_rotate_string = parseInt(valueMinute).toString();
              idle_minute_rotate_string = idle_minute_rotate_string.padStart(2, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 2; i++) {  // hide all symbols
                  idle_minute_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueMinute != null && valueMinute != undefined && isFinite(valueMinute) && idle_minute_rotate_string.length > 0 && idle_minute_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_minute_TextRotate_posOffset = idle_minute_TextRotate_img_width * idle_minute_rotate_string.length;
                  idle_minute_TextRotate_posOffset = idle_minute_TextRotate_posOffset + -20 * (idle_minute_rotate_string.length - 1);
                  img_offset -= idle_minute_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_minute_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 2) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.POS_X, 226 + img_offset);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.SRC, idle_minute_TextRotate_ASCIIARRAY[charCode]);
                      idle_minute_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_minute_TextRotate_img_width + -20;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                text_update();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}