﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        console.log('user_functions.js');
        // start user_functions.js
        let bg_list = [
            'bg_0.png',
            'bg_1.png',
            'bg_2.png',
            'bg_3.png',
            'bg_4.png',
            'bg_5.png',
        ];
        let bg_index = 0;

        function bg_switching() {
            bg_index++;
            if (bg_index >= bg_list.length) bg_index = 0;
            normal_background_bg_img.setProperty(hmUI.prop.SRC, bg_list[bg_index]);
        }
        // end user_functions.js

        let normal_background_bg_img = ''
        let normal_wind_direction_image_progress_img_level = ''
        let normal_wind_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let Button_1 = ''
        let Button_2 = ''
        let Button_3 = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg_0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_direction_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 348,
              y: 301,
              image_array: ["wind_00.png","wind_01.png","wind_02.png","wind_03.png","wind_04.png","wind_05.png","wind_06.png","wind_07.png"],
              image_length: 8,
              type: hmUI.data_type.WIND_DIRECTION,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_wind_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 314,
              y: 330,
              image_array: ["digits-meduim_00.png","digits-meduim_01.png","digits-meduim_02.png","digits-meduim_03.png","digits-meduim_04.png","digits-meduim_05.png","digits-meduim_06.png","digits-meduim_07.png","digits-meduim_08.png","digits-meduim_09.png"],
              image_length: 10,
              type: hmUI.data_type.WIND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 352,
              y: 85,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png","moon_11.png","moon_12.png","moon_13.png","moon_14.png","moon_15.png","moon_16.png","moon_17.png","moon_18.png","moon_19.png","moon_20.png","moon_21.png","moon_22.png","moon_23.png","moon_24.png","moon_25.png","moon_26.png","moon_27.png","moon_28.png","moon_29.png","moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 330,
              font_array: ["digits-meduim_00.png","digits-meduim_01.png","digits-meduim_02.png","digits-meduim_03.png","digits-meduim_04.png","digits-meduim_05.png","digits-meduim_06.png","digits-meduim_07.png","digits-meduim_08.png","digits-meduim_09.png"],
              padding: false,
              h_space: 6,
              negative_image: 'minus.png',
              invalid_image: 'no-data.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 187,
              y: 319,
              image_array: ["weather_00.png","weather_01.png","weather_02.png","weather_03.png","weather_04.png","weather_05.png","weather_06.png","weather_07.png","weather_08.png","weather_09.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 238,
              y: 93,
              font_array: ["digits-smallest_00.png","digits-smallest_01.png","digits-smallest_02.png","digits-smallest_03.png","digits-smallest_04.png","digits-smallest_05.png","digits-smallest_06.png","digits-smallest_07.png","digits-smallest_08.png","digits-smallest_09.png"],
              padding: false,
              h_space: 3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 205,
              y: 48,
              image_array: ["battery_00.png","battery_01.png","battery_02.png","battery_03.png","battery_04.png","battery_05.png","battery_06.png","battery_07.png","battery_08.png","battery_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 355,
              month_startY: 219,
              month_sc_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_tc_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_en_array: ["month_00.png","month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 333,
              y: 172,
              week_en: ["days_00.png","days_01.png","days_02.png","days_03.png","days_04.png","days_05.png","days_06.png"],
              week_tc: ["days_00.png","days_01.png","days_02.png","days_03.png","days_04.png","days_05.png","days_06.png"],
              week_sc: ["days_00.png","days_01.png","days_02.png","days_03.png","days_04.png","days_05.png","days_06.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 359,
              day_startY: 190,
              day_sc_array: ["digits-smallest_00.png","digits-smallest_01.png","digits-smallest_02.png","digits-smallest_03.png","digits-smallest_04.png","digits-smallest_05.png","digits-smallest_06.png","digits-smallest_07.png","digits-smallest_08.png","digits-smallest_09.png"],
              day_tc_array: ["digits-smallest_00.png","digits-smallest_01.png","digits-smallest_02.png","digits-smallest_03.png","digits-smallest_04.png","digits-smallest_05.png","digits-smallest_06.png","digits-smallest_07.png","digits-smallest_08.png","digits-smallest_09.png"],
              day_en_array: ["digits-smallest_00.png","digits-smallest_01.png","digits-smallest_02.png","digits-smallest_03.png","digits-smallest_04.png","digits-smallest_05.png","digits-smallest_06.png","digits-smallest_07.png","digits-smallest_08.png","digits-smallest_09.png"],
              day_zero: 0,
              day_space: 4,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 92,
              y: 92,
              font_array: ["digits-small_00.png","digits-small_01.png","digits-small_02.png","digits-small_03.png","digits-small_04.png","digits-small_05.png","digits-small_06.png","digits-small_07.png","digits-small_08.png","digits-small_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 78,
              y: 165,
              font_array: ["digits-small_00.png","digits-small_01.png","digits-small_02.png","digits-small_03.png","digits-small_04.png","digits-small_05.png","digits-small_06.png","digits-small_07.png","digits-small_08.png","digits-small_09.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 30,
              y: 197,
              image_array: ["steps_00.png","steps_01.png","steps_02.png","steps_03.png","steps_04.png","steps_05.png","steps_06.png","steps_07.png","steps_08.png","steps_09.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 206,
              am_y: 212,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 206,
              pm_y: 212,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 57,
              hour_startY: 237,
              hour_array: ["digits-big_00.png","digits-big_01.png","digits-big_02.png","digits-big_03.png","digits-big_04.png","digits-big_05.png","digits-big_06.png","digits-big_07.png","digits-big_08.png","digits-big_09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 186,
              minute_startY: 237,
              minute_array: ["digits-big_00.png","digits-big_01.png","digits-big_02.png","digits-big_03.png","digits-big_04.png","digits-big_05.png","digits-big_06.png","digits-big_07.png","digits-big_08.png","digits-big_09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 291,
              second_startY: 283,
              second_array: ["digits-small_00.png","digits-small_01.png","digits-small_02.png","digits-small_03.png","digits-small_04.png","digits-small_05.png","digits-small_06.png","digits-small_07.png","digits-small_08.png","digits-small_09.png"],
              second_zero: 1,
              second_space: 4,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 261,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 164,
              y: 261,
              src: 'bt-off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 287,
              y: 259,
              src: 'alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 311,
              am_y: 168,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 311,
              pm_y: 168,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 107,
              hour_startY: 191,
              hour_array: ["digits-big_00.png","digits-big_01.png","digits-big_02.png","digits-big_03.png","digits-big_04.png","digits-big_05.png","digits-big_06.png","digits-big_07.png","digits-big_08.png","digits-big_09.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 250,
              minute_startY: 191,
              minute_array: ["digits-big_00.png","digits-big_01.png","digits-big_02.png","digits-big_03.png","digits-big_04.png","digits-big_05.png","digits-big_06.png","digits-big_07.png","digits-big_08.png","digits-big_09.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 220,
              y: 215,
              src: 'dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 287,
              y: 271,
              w: 49,
              h: 51,
              src: '_empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 55,
              y: 233,
              w: 229,
              h: 76,
              src: '_empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 352,
              y: 84,
              w: 60,
              h: 64,
              src: '_empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 325,
              w: 286,
              h: 68,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 85,
              y: 65,
              w: 74,
              h: 58,
              src: '_empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 38,
              y: 160,
              w: 161,
              h: 58,
              src: '_empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.Buttons');
            Button_1 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 187,
              y: 401,
              w: 75,
              h: 53,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_empty.png',
              normal_src: '_empty.png',
              click_func: (button_widget) => {
                bg_switching();
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_2 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 318,
              y: 150,
              w: 115,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_empty.png',
              normal_src: '_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'ScheduleCalScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button

            Button_3 = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 208,
              y: 46,
              w: 109,
              h: 120,
              text: '',
              color: 0xFFFF8C00,
              text_size: 25,
              press_src: '_empty.png',
              normal_src: '_empty.png',
              click_func: (button_widget) => {
                hmApp.startApp({url: 'PowerSaveHintScreen', native: true });
              }, // end func
              show_level: hmUI.show_level.ONLY_NORMAL,
            }); // end button


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}