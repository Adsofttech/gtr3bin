﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_day = ''
        let normal_sun_current_text_img = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_system_disconnect_img = ''
        let idle_analog_clock_time_pointer_second = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Main1_ver2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 119,
              font_array: ["S_numbs_steps_00.png","S_numbs_steps_01.png","S_numbs_steps_02.png","S_numbs_steps_03.png","S_numbs_steps_04.png","S_numbs_steps_05.png","S_numbs_steps_06.png","S_numbs_steps_07.png","S_numbs_steps_08.png","S_numbs_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 304,
              y: 90,
              src: '0091.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 278,
              y: 194,
              week_en: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_tc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              week_sc: ["0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 363,
              year_startY: 236,
              year_sc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              year_tc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              year_en_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 322,
              month_startY: 236,
              month_sc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              month_tc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              month_en_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              month_zero: 1,
              month_space: 0,
              month_unit_sc: 'dot.png',
              month_unit_tc: 'dot.png',
              month_unit_en: 'dot.png',
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 282,
              day_startY: 236,
              day_sc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              day_tc_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              day_en_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'dot.png',
              day_unit_tc: 'dot.png',
              day_unit_en: 'dot.png',
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 146,
              y: 237,
              font_array: ["S_numbers_00.png","S_numbers_01.png","S_numbers_02.png","S_numbers_03.png","S_numbers_04.png","S_numbers_05.png","S_numbers_06.png","S_numbers_07.png","S_numbers_08.png","S_numbers_09.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dot_2.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 50,
              y: 190,
              w: 190,
              h: 30,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              color: 0xFFC0C0C0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 120,
              y: 154,
              font_array: ["weather_numbers_00.png","weather_numbers_01.png","weather_numbers_02.png","weather_numbers_03.png","weather_numbers_04.png","weather_numbers_05.png","weather_numbers_06.png","weather_numbers_07.png","weather_numbers_08.png","weather_numbers_09.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'weather_numbers_celcius.png',
              unit_tc: 'weather_numbers_celcius.png',
              unit_en: 'weather_numbers_celcius.png',
              negative_image: 'weather_numbers_minus.png',
              invalid_image: 'weather_numbers_minus.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 50,
              y: 144,
              image_array: ["1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png","12.png","13.png","14.png","15.png","16.png","17.png","18.png","19.png","20.png","21.png","22.png","23.png","24.png","25.png","26.png","27.png","28.png","29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 151,
              font_array: ["S_numbs_steps_00.png","S_numbs_steps_01.png","S_numbs_steps_02.png","S_numbs_steps_03.png","S_numbs_steps_04.png","S_numbs_steps_05.png","S_numbs_steps_06.png","S_numbs_steps_07.png","S_numbs_steps_08.png","S_numbs_steps_09.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'icon_KM.png',
              unit_tc: 'icon_KM.png',
              unit_en: 'icon_KM.png',
              dot_image: 'icon_dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 350,
              y: 119,
              font_array: ["S_numbs_steps_00.png","S_numbs_steps_01.png","S_numbs_steps_02.png","S_numbs_steps_03.png","S_numbs_steps_04.png","S_numbs_steps_05.png","S_numbs_steps_06.png","S_numbs_steps_07.png","S_numbs_steps_08.png","S_numbs_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 405,
              y: 125,
              src: 'battery_percent.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 378,
              y: 89,
              image_array: ["battery_0.png","battery_1.png","battery_2.png","battery_3.png","battery_4.png","battery_5.png","battery_6.png","battery_7.png","battery_8.png","battery_9.png","battery_10.png","battery_11.png","battery_12.png","battery_13.png","battery_14.png","battery_15.png","battery_16.png","battery_17.png"],
              image_length: 18,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 119,
              font_array: ["S_numbs_steps_00.png","S_numbs_steps_01.png","S_numbs_steps_02.png","S_numbs_steps_03.png","S_numbs_steps_04.png","S_numbs_steps_05.png","S_numbs_steps_06.png","S_numbs_steps_07.png","S_numbs_steps_08.png","S_numbs_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 228,
              y: 90,
              image_array: ["hr_0.png","hr_1.png","hr_2.png","hr_3.png","hr_4.png","hr_5.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 70,
              // start_y: 128,
              // color: 0xFF000000,
              // lenght: 75,
              // line_width: 5,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 116,
              y: 96,
              font_array: ["S_numbs_steps_00.png","S_numbs_steps_01.png","S_numbs_steps_02.png","S_numbs_steps_03.png","S_numbs_steps_04.png","S_numbs_steps_05.png","S_numbs_steps_06.png","S_numbs_steps_07.png","S_numbs_steps_08.png","S_numbs_steps_09.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 161,
              y: 410,
              src: '0118.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 60,
              y: 304,
              src: 'ALARM.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 80,
              hour_startY: 270,
              hour_array: ["B_numbers_00.png","B_numbers_01.png","B_numbers_02.png","B_numbers_03.png","B_numbers_04.png","B_numbers_05.png","B_numbers_06.png","B_numbers_07.png","B_numbers_08.png","B_numbers_09.png"],
              hour_zero: 1,
              hour_space: -38,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 220,
              minute_startY: 270,
              minute_array: ["B_numbers_00.png","B_numbers_01.png","B_numbers_02.png","B_numbers_03.png","B_numbers_04.png","B_numbers_05.png","B_numbers_06.png","B_numbers_07.png","B_numbers_08.png","B_numbers_09.png"],
              minute_zero: 1,
              minute_space: -38,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 362,
              second_startY: 277,
              second_array: ["L_numbers_00.png","L_numbers_01.png","L_numbers_02.png","L_numbers_03.png","L_numbers_04.png","L_numbers_05.png","L_numbers_06.png","L_numbers_07.png","L_numbers_08.png","L_numbers_09.png"],
              second_zero: 1,
              second_space: -12,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0119.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 70,
              hour_startY: 251,
              hour_array: ["AOD_B_numbers_00.png","AOD_B_numbers_01.png","AOD_B_numbers_02.png","AOD_B_numbers_03.png","AOD_B_numbers_04.png","AOD_B_numbers_05.png","AOD_B_numbers_06.png","AOD_B_numbers_07.png","AOD_B_numbers_08.png","AOD_B_numbers_09.png"],
              hour_zero: 1,
              hour_space: -30,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 244,
              minute_startY: 251,
              minute_array: ["AOD_B_numbers_00.png","AOD_B_numbers_01.png","AOD_B_numbers_02.png","AOD_B_numbers_03.png","AOD_B_numbers_04.png","AOD_B_numbers_05.png","AOD_B_numbers_06.png","AOD_B_numbers_07.png","AOD_B_numbers_08.png","AOD_B_numbers_09.png"],
              minute_zero: 1,
              minute_space: -30,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 212,
              y: 196,
              src: 'bluetooth.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0120.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 25,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 9,
              // conneсnt_vibrate_type: 9,
              // conneсnt_toast_text: CONNECTION RESTORED,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  vibro(9);
                }
                if(status) {
                  hmUI.showToast({text: "CONNECTION RESTORED"});
                  vibro(9);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 0,
              y: 199,
              w: 47,
              h: 96,
              src: 'click_e.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 112,
              y: 236,
              w: 170,
              h: 35,
              src: 'click_e.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 64,
              y: 150,
              w: 130,
              h: 80,
              src: 'click_e.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 81,
              w: 94,
              h: 68,
              src: 'click_e.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 88,
              y: 81,
              w: 111,
              h: 66,
              src: 'click_e.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 234,
              y: 156,
              w: 94,
              h: 70,
              src: 'click_e.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 70;
                  let start_y_normal_step = 128;
                  let lenght_ls_normal_step = 75;
                  let line_width_ls_normal_step = 5;
                  let color_ls_normal_step = 0xFF000000;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = lenght_ls_normal_step;
                  let line_width_ls_normal_step_draw = line_width_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    lenght_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_x_normal_step_draw = start_x_normal_step - lenght_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
