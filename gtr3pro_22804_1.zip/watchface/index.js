﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

  (() => {

    const __$$app$$__ = __$$hmAppManager$$__.currentApp;
    const __$$module$$__ = __$$app$$__.current;
    //drink is a name,can modify
    const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

    'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end

    /**
     * SMOOTH SECONDS SCRIPTS
     */
    let now;
    let lastTime = 0;
    let animTimer;
    let widgetDelegate;
    const animDuration = 5000;
    const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion

    function setSec() {
      const screenType = hmSetting.getScreenType();
      if (screenType === hmSetting.screen_type.AOD) {
        return stopSecAnim();
      }
      if (!now) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
      }
      if (widgetDelegate) return;

      widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {
          console.log('ui resume');

          if (animTimer) return;

          let duration = 0;
          const diffTime = now.utc - lastTime;
          if (diffTime < animDuration) {
            duration = animDuration - diffTime;
          }

          animTimer = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim(now.second * 6);
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
          stopSecAnim();
        }),
      });
    }

    function startSecAnim(sec) {
      const secAnim = {
        anim_rate: 'linear',
        anim_duration: animDuration,
        anim_from: sec,
        anim_to: sec + animDuration * 6 / 1000,
        repeat_count: 1,
        anim_fps: animFps,
        anim_key: "angle",
        anim_status: 1,
      }

      normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()
     */
    function stopSecAnim() {
      if (animTimer) {
        timer.stopTimer(animTimer);
        animTimer = undefined;
      }
    }

    /** END SMOOTH SECOND SCRIPTS */

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Blue.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 314,
              day_startY: 350,
              day_sc_array: ["wht0.png","wht1.png","wht2.png","wht3.png","wht4.png","wht5.png","wht6.png","wht7.png","wht8.png","wht9.png"],
              day_tc_array: ["wht0.png","wht1.png","wht2.png","wht3.png","wht4.png","wht5.png","wht6.png","wht7.png","wht8.png","wht9.png"],
              day_en_array: ["wht0.png","wht1.png","wht2.png","wht3.png","wht4.png","wht5.png","wht6.png","wht7.png","wht8.png","wht9.png"],
              day_zero: 0,
              day_space: -68,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'BlueHour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'BlueMin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

        // Smooth Seconds
        normal_analog_clock_time_pointer_second = normal_analog_clock_time_pointer_second || hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
          w: 480,
          h: 480,
          pos_x: 480 / 2 - 30,
          pos_y: 480 / 2 - 240,
          center_x: 240,
          center_y: 240,
          src: "BlueSec.png",
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        setSec();

/*            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'BlueSec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 30,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
*/

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aodhour.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 30,
              hour_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aodmin.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 30,
              minute_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

      onDestroy() {
        console.log('index page.js on destroy invoke')
        stopSecAnim();
      },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  