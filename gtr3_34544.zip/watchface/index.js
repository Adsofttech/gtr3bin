﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_year_TextCircle = new Array(4);
        let normal_year_TextCircle_ASCIIARRAY = new Array(10);
        let normal_year_TextCircle_img_width = 7;
        let normal_year_TextCircle_img_height = 15;
        let normal_timerTextUpdate = undefined;
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_distance_TextRotate = new Array(5);
        let normal_distance_TextRotate_ASCIIARRAY = new Array(10);
        let normal_distance_TextRotate_img_width = 13;
        let normal_distance_TextRotate_unit = null;
        let normal_distance_TextRotate_unit_width = 29;
        let normal_distance_TextRotate_dot_width = 6;
        let normal_distance_TextRotate_error_img_width = 13;
        let normal_calorie_TextRotate = new Array(4);
        let normal_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let normal_calorie_TextRotate_img_width = 13;
        let normal_calorie_TextRotate_error_img_width = 13;
        let normal_step_TextRotate = new Array(5);
        let normal_step_TextRotate_ASCIIARRAY = new Array(10);
        let normal_step_TextRotate_img_width = 13;
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time_minute = ''
        let normal_digital_clock_img_time_hour = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSecSmooth = undefined;
        let idle_image_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_year_TextCircle = new Array(4);
        let idle_year_TextCircle_ASCIIARRAY = new Array(10);
        let idle_year_TextCircle_img_width = 7;
        let idle_year_TextCircle_img_height = 15;
        let idle_timerTextUpdate = undefined;
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_distance_TextRotate = new Array(5);
        let idle_distance_TextRotate_ASCIIARRAY = new Array(10);
        let idle_distance_TextRotate_img_width = 13;
        let idle_distance_TextRotate_unit = null;
        let idle_distance_TextRotate_unit_width = 29;
        let idle_distance_TextRotate_dot_width = 6;
        let idle_distance_TextRotate_error_img_width = 13;
        let idle_calorie_TextRotate = new Array(4);
        let idle_calorie_TextRotate_ASCIIARRAY = new Array(10);
        let idle_calorie_TextRotate_img_width = 13;
        let idle_calorie_TextRotate_error_img_width = 13;
        let idle_step_TextRotate = new Array(5);
        let idle_step_TextRotate_ASCIIARRAY = new Array(10);
        let idle_step_TextRotate_img_width = 13;
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time_minute = ''
        let idle_digital_clock_img_time_hour = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let timeSensor = ''

//////////////////////////////////////////////////////////////////////////////////////////////////

        // Start color change
        let btncolor = ''
        let colornumber = 1
        let totalcolors = 7
        let namecolor = ''

        function click_Color() {
            if(colornumber>=totalcolors) {
            colornumber=1;
                }
            else {
                colornumber=colornumber+1;
            }

if ( colornumber == 1) { namecolor = "GREEN"}
if ( colornumber == 2) { namecolor = "LEMON"}
if ( colornumber == 3) { namecolor = "ORANGE"}
if ( colornumber == 4) { namecolor = "RED"}
if ( colornumber == 5) { namecolor = "BLUE"}
if ( colornumber == 6) { namecolor = "PINK"}
if ( colornumber == 7) { namecolor = "BLACK & WHITE"}
hmUI.showToast({text: namecolor });

             //hmUI.showToast({text: "color " + parseInt(colornumber) });
             normal_background_bg_img.setProperty(hmUI.prop.SRC, "main" + parseInt(colornumber) + ".png");
             normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "Hand_Second" + parseInt(colornumber) + ".png");                        
        }

/////////////////////////////////////////////////////////////////////////////////////////////////


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 85,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_Second1.png',
              // center_x: 227,
              // center_y: 227,
              // x: 98,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 98,
              pos_y: 227 - 238,
              center_x: 227,
              center_y: 227,
              src: 'Hand_Second1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -11,
              y: 161,
              src: 'TopWing.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 133,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 80,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 334,
              font_array: ["Pulse_0.png","Pulse_1.png","Pulse_2.png","Pulse_3.png","Pulse_4.png","Pulse_5.png","Pulse_6.png","Pulse_7.png","Pulse_8.png","Pulse_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 185,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 116,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 113,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 332,
              // circle_center_Y: 337,
              // font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              // radius: 25,
              // angle: -136,
              // char_space_angle: 14,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_year_TextCircle_ASCIIARRAY[0] = 'Batt_Font_01.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[1] = 'Batt_Font_02.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[2] = 'Batt_Font_03.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[3] = 'Batt_Font_04.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[4] = 'Batt_Font_05.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[5] = 'Batt_Font_06.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[6] = 'Batt_Font_07.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[7] = 'Batt_Font_08.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[8] = 'Batt_Font_09.png';  // set of images with numbers
            normal_year_TextCircle_ASCIIARRAY[9] = 'Batt_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 332,
                center_y: 337,
                pos_x: 332 - normal_year_TextCircle_img_width / 2,
                pos_y: 337 + 18,
                src: 'Batt_Font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const timeNaw = hmSensor.createSensor(hmSensor.id.TIME);
            
            function toDegree (radian) {
              return radian * (180 / Math.PI);
            };

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 313,
              day_startY: 309,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 313,
              month_startY: 254,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 197,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 166,
              image_array: ["Batt_icon_00.png","Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png","Batt_icon_11.png","Batt_icon_12.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 251,
              // y: 335,
              // font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // unit_en: 'Act_KM.png',
              // imperial_unit_en: 'Act_Mi.png',
              // invalid_image: 'Act_Font_01.png',
              // dot_image: 'Act_Dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_distance_TextRotate_ASCIIARRAY[0] = 'Act_Font_01.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[1] = 'Act_Font_02.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[2] = 'Act_Font_03.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[3] = 'Act_Font_04.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[4] = 'Act_Font_05.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[5] = 'Act_Font_06.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[6] = 'Act_Font_07.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[7] = 'Act_Font_08.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[8] = 'Act_Font_09.png';  // set of images with numbers
            normal_distance_TextRotate_ASCIIARRAY[9] = 'Act_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 251,
                center_y: 335,
                pos_x: 251,
                pos_y: 335,
                angle: -90,
                src: 'Act_Font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            normal_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 251,
              center_y: 335,
              pos_x: 251,
              pos_y: 335,
              angle: -90,
              src: 'Act_KM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            const mileageUnit = hmSetting.getMileageUnit();
            if (mileageUnit == 1) {
              normal_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Act_Mi.png');
            };
            //end of ignored block
            
            const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
            distance.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 185,
              // y: 319,
              // font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -90,
              // invalid_image: 'Act_Font_01.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_calorie_TextRotate_ASCIIARRAY[0] = 'Act_Font_01.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[1] = 'Act_Font_02.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[2] = 'Act_Font_03.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[3] = 'Act_Font_04.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[4] = 'Act_Font_05.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[5] = 'Act_Font_06.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[6] = 'Act_Font_07.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[7] = 'Act_Font_08.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[8] = 'Act_Font_09.png';  // set of images with numbers
            normal_calorie_TextRotate_ASCIIARRAY[9] = 'Act_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              normal_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 185,
                center_y: 319,
                pos_x: 185,
                pos_y: 319,
                angle: -90,
                src: 'Act_Font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            // normal_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 213,
              // y: 331,
              // font_array: ["Act_black_Font_01.png","Act_black_Font_02.png","Act_black_Font_03.png","Act_black_Font_04.png","Act_black_Font_05.png","Act_black_Font_06.png","Act_black_Font_07.png","Act_black_Font_08.png","Act_black_Font_09.png","Act_black_Font_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_TextRotate_ASCIIARRAY[0] = 'Act_black_Font_01.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[1] = 'Act_black_Font_02.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[2] = 'Act_black_Font_03.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[3] = 'Act_black_Font_04.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[4] = 'Act_black_Font_05.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[5] = 'Act_black_Font_06.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[6] = 'Act_black_Font_07.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[7] = 'Act_black_Font_08.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[8] = 'Act_black_Font_09.png';  // set of images with numbers
            normal_step_TextRotate_ASCIIARRAY[9] = 'Act_black_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              normal_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 214,
                center_y: 331,
                pos_x: 214,
                pos_y: 331,
                angle: -90,
                src: 'Act_black_Font_01.png',
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
              normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              text_update();
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 379,
              y: 185,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 124,
              am_y: 256,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 124,
              pm_y: 256,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 169,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 169,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main7.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 273,
              y: 85,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'Hand_Second7.png',
              // center_x: 227,
              // center_y: 227,
              // x: 98,
              // y: 238,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 98,
              pos_y: 227 - 238,
              center_x: 227,
              center_y: 227,
              src: 'Hand_Second7.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -11,
              y: 161,
              src: 'TopWing.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 133,
              font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Weather_symbo_01.png',
              unit_tc: 'Weather_symbo_01.png',
              unit_en: 'Weather_symbo_01.png',
              negative_image: 'Weather_symbo_02.png',
              invalid_image: 'Weather_symbo_02.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 201,
              y: 80,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 334,
              font_array: ["Pulse_0.png","Pulse_1.png","Pulse_2.png","Pulse_3.png","Pulse_4.png","Pulse_5.png","Pulse_6.png","Pulse_7.png","Pulse_8.png","Pulse_9.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 8,
              y: 185,
              image_array: ["Zone1.png","Zone2.png","Zone3.png","Zone4.png","Zone5.png","Zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 114,
              y: 116,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 312,
              y: 113,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_year_text_circle_img = hmUI.createWidget(hmUI.widget.Text_Circle, {
              // circle_center_X: 332,
              // circle_center_Y: 337,
              // font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              // radius: 25,
              // angle: -136,
              // char_space_angle: 14,
              // zero: true,
              // reverse_direction: true,
              // unit_in_alignment: true,
              // vertical_alignment: CENTER_V,
              // horizontal_alignment: LEFT,
              // type: hmUI.data_type.YEAR,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_year_TextCircle_ASCIIARRAY[0] = 'Batt_Font_01.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[1] = 'Batt_Font_02.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[2] = 'Batt_Font_03.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[3] = 'Batt_Font_04.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[4] = 'Batt_Font_05.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[5] = 'Batt_Font_06.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[6] = 'Batt_Font_07.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[7] = 'Batt_Font_08.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[8] = 'Batt_Font_09.png';  // set of images with numbers
            idle_year_TextCircle_ASCIIARRAY[9] = 'Batt_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_year_TextCircle[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 332,
                center_y: 337,
                pos_x: 332 - idle_year_TextCircle_img_width / 2,
                pos_y: 337 + 18,
                src: 'Batt_Font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 313,
              day_startY: 309,
              day_sc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_tc_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_en_array: ["Day_0.png","Day_1.png","Day_2.png","Day_3.png","Day_4.png","Day_5.png","Day_6.png","Day_7.png","Day_8.png","Day_9.png"],
              day_zero: 0,
              day_space: 3,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 313,
              month_startY: 254,
              month_sc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_tc_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_en_array: ["Month_icon_01.png","Month_icon_02.png","Month_icon_03.png","Month_icon_04.png","Month_icon_05.png","Month_icon_06.png","Month_icon_07.png","Month_icon_08.png","Month_icon_09.png","Month_icon_10.png","Month_icon_11.png","Month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 197,
              font_array: ["Batt_Font_01.png","Batt_Font_02.png","Batt_Font_03.png","Batt_Font_04.png","Batt_Font_05.png","Batt_Font_06.png","Batt_Font_07.png","Batt_Font_08.png","Batt_Font_09.png","Batt_Font_10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'Batt_symbo.png',
              unit_tc: 'Batt_symbo.png',
              unit_en: 'Batt_symbo.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 287,
              y: 166,
              image_array: ["Batt_icon_00.png","Batt_icon_01.png","Batt_icon_02.png","Batt_icon_03.png","Batt_icon_04.png","Batt_icon_05.png","Batt_icon_06.png","Batt_icon_07.png","Batt_icon_08.png","Batt_icon_09.png","Batt_icon_10.png","Batt_icon_11.png","Batt_icon_12.png"],
              image_length: 13,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_distance_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 251,
              // y: 335,
              // font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 3,
              // angle: -90,
              // unit_en: 'Act_KM.png',
              // imperial_unit_en: 'Act_Mi.png',
              // invalid_image: 'Act_Font_01.png',
              // dot_image: 'Act_Dot.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.DISTANCE,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_distance_TextRotate_ASCIIARRAY[0] = 'Act_Font_01.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[1] = 'Act_Font_02.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[2] = 'Act_Font_03.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[3] = 'Act_Font_04.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[4] = 'Act_Font_05.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[5] = 'Act_Font_06.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[6] = 'Act_Font_07.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[7] = 'Act_Font_08.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[8] = 'Act_Font_09.png';  // set of images with numbers
            idle_distance_TextRotate_ASCIIARRAY[9] = 'Act_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_distance_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 251,
                center_y: 335,
                pos_x: 251,
                pos_y: 335,
                angle: -90,
                src: 'Act_Font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };

            idle_distance_TextRotate_unit = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              center_x: 251,
              center_y: 335,
              pos_x: 251,
              pos_y: 335,
              angle: -90,
              src: 'Act_KM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);

            if (mileageUnit == 1) {
              idle_distance_TextRotate_unit.setProperty(hmUI.prop.SRC, 'Act_Mi.png');
            };
            //end of ignored block

            // idle_calorie_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 185,
              // y: 319,
              // font_array: ["Act_Font_01.png","Act_Font_02.png","Act_Font_03.png","Act_Font_04.png","Act_Font_05.png","Act_Font_06.png","Act_Font_07.png","Act_Font_08.png","Act_Font_09.png","Act_Font_10.png"],
              // zero: true,
              // unit_in_alignment: false,
              // h_space: 4,
              // angle: -90,
              // invalid_image: 'Act_Font_01.png',
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_calorie_TextRotate_ASCIIARRAY[0] = 'Act_Font_01.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[1] = 'Act_Font_02.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[2] = 'Act_Font_03.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[3] = 'Act_Font_04.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[4] = 'Act_Font_05.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[5] = 'Act_Font_06.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[6] = 'Act_Font_07.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[7] = 'Act_Font_08.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[8] = 'Act_Font_09.png';  // set of images with numbers
            idle_calorie_TextRotate_ASCIIARRAY[9] = 'Act_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 4; i++) {
              idle_calorie_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 185,
                center_y: 319,
                pos_x: 185,
                pos_y: 319,
                angle: -90,
                src: 'Act_Font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            // idle_step_text_rotate_img = hmUI.createWidget(hmUI.widget.Text_Rotate, {
              // x: 213,
              // y: 331,
              // font_array: ["Act_black_Font_01.png","Act_black_Font_02.png","Act_black_Font_03.png","Act_black_Font_04.png","Act_black_Font_05.png","Act_black_Font_06.png","Act_black_Font_07.png","Act_black_Font_08.png","Act_black_Font_09.png","Act_black_Font_10.png"],
              // zero: false,
              // unit_in_alignment: false,
              // h_space: 2,
              // angle: -90,
              // align_h: hmUI.align.CENTER_H,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_step_TextRotate_ASCIIARRAY[0] = 'Act_black_Font_01.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[1] = 'Act_black_Font_02.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[2] = 'Act_black_Font_03.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[3] = 'Act_black_Font_04.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[4] = 'Act_black_Font_05.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[5] = 'Act_black_Font_06.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[6] = 'Act_black_Font_07.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[7] = 'Act_black_Font_08.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[8] = 'Act_black_Font_09.png';  // set of images with numbers
            idle_step_TextRotate_ASCIIARRAY[9] = 'Act_black_Font_10.png';  // set of images with numbers

            //start of ignored block
            for (let i = 0; i < 5; i++) {
              idle_step_TextRotate[i] = hmUI.createWidget(hmUI.widget.IMG, {
                x: 0,
                y: 0,
                w: 454,
                h: 454,
                center_x: 214,
                center_y: 331,
                pos_x: 214,
                pos_y: 331,
                angle: -90,
                src: 'Act_black_Font_01.png',
                show_level: hmUI.show_level.ONLY_AOD,
              });
              idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
            };
            //end of ignored block

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 379,
              y: 185,
              week_en: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_tc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              week_sc: ["Week1.png","Week2.png","Week3.png","Week4.png","Week5.png","Week6.png","Week7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 124,
              am_y: 256,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 124,
              pm_y: 256,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 169,
              minute_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_hour = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 91,
              hour_startY: 169,
              hour_array: ["Time_0.png","Time_1.png","Time_2.png","Time_3.png","Time_4.png","Time_5.png","Time_6.png","Time_7.png","Time_8.png","Time_9.png"],
              hour_zero: 1,
              hour_space: 8,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 213,
              y: 203,
              w: 45,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 108,
              y: 203,
              w: 48,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 307,
              y: 115,
              w: 46,
              h: 44,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 264,
              y: 80,
              w: 42,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 107,
              w: 60,
              h: 48,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 251,
              y: 259,
              w: 44,
              h: 39,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 295,
              w: 81,
              h: 40,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 80,
              y: 338,
              w: 82,
              h: 41,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

	// calendar
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 309,
              y: 312,
              w: 50,
              h: 50,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


		// GO ACTIVITY
	hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 211,
              y: 263,
              w: 31,
              h: 29,
	 text: '',
	  normal_src: '0_Empty.png',
	  press_src: '0_Empty.png',
	  click_func: () => {
	hmApp.startApp({ url: 'SportListScreen', native: true });
	  },
	  show_level: hmUI.show_level.ONLY_NORMAL,
	});


            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 212,
              y: 295,
              w: 31,
              h: 85,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            function text_update() {

              console.log('update text circle year_TIME');
              let valueYear = timeNaw.year;
              let normal_year_circle_string = parseInt(valueYear).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 44;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && normal_year_circle_string.length > 0 && normal_year_circle_string.length < 6) {  // display data if it was possible to get it
                  let normal_year_TextCircle_img_angle = 0;
                  let normal_year_TextCircle_dot_img_angle = 0;
                  normal_year_TextCircle_img_angle = toDegree(Math.atan2(normal_year_TextCircle_img_width/2, 25));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of normal_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= normal_year_TextCircle_img_angle;
                      firstSymbol = false;
                      normal_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 332 - normal_year_TextCircle_img_width / 2);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.SRC, normal_year_TextCircle_ASCIIARRAY[charCode]);
                      normal_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= normal_year_TextCircle_img_angle + 14;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate DISTANCE');
              let distanceCurrent = distance.current;
              let normal_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && normal_distance_rotate_string.length > 0 && normal_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_distance_TextRotate_posOffset = normal_distance_TextRotate_img_width * normal_distance_rotate_string.length;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset - normal_distance_TextRotate_img_width + normal_distance_TextRotate_dot_width;
                  normal_distance_TextRotate_posOffset = normal_distance_TextRotate_posOffset + 3 * (normal_distance_rotate_string.length - 1);
                  img_offset -= normal_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 251 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, normal_distance_TextRotate_ASCIIARRAY[charCode]);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_img_width + 3;
                      index++;
                    }  // end if digit
                    else { 
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 251 + img_offset);
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Act_Dot.png');
                      normal_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_distance_TextRotate_dot_width + 3;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 251 + img_offset);
                  normal_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 251 - normal_distance_TextRotate_error_img_width / 2);
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_01.png');
                  normal_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let valueCalories = calorie.current;
              let normal_calorie_rotate_string = parseInt(valueCalories).toString();
              normal_calorie_rotate_string = normal_calorie_rotate_string.padStart(4, '0');

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  normal_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && normal_calorie_rotate_string.length > 0 && normal_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_img_width * normal_calorie_rotate_string.length;
                  normal_calorie_TextRotate_posOffset = normal_calorie_TextRotate_posOffset + 4 * (normal_calorie_rotate_string.length - 1);
                  img_offset -= normal_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 185 + img_offset);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, normal_calorie_TextRotate_ASCIIARRAY[charCode]);
                      normal_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_calorie_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 185 - normal_calorie_TextRotate_error_img_width / 2);
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_01.png');
                  normal_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let valueStep = step.current;
              let normal_step_rotate_string = parseInt(valueStep).toString();

              if (screenType != hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  normal_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && normal_step_rotate_string.length > 0 && normal_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let normal_step_TextRotate_posOffset = normal_step_TextRotate_img_width * normal_step_rotate_string.length;
                  normal_step_TextRotate_posOffset = normal_step_TextRotate_posOffset + 2 * (normal_step_rotate_string.length - 1);
                  img_offset -= normal_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of normal_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      normal_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 213 + img_offset);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.SRC, normal_step_TextRotate_ASCIIARRAY[charCode]);
                      normal_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += normal_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text circle year_TIME');
              let idle_year_circle_string = parseInt(valueYear).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_year_TextCircle[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                let char_Angle = 44;
                if (valueYear != null && valueYear != undefined && isFinite(valueYear) && idle_year_circle_string.length > 0 && idle_year_circle_string.length < 6) {  // display data if it was possible to get it
                  let idle_year_TextCircle_img_angle = 0;
                  let idle_year_TextCircle_dot_img_angle = 0;
                  idle_year_TextCircle_img_angle = toDegree(Math.atan2(idle_year_TextCircle_img_width/2, 25));
                  
                  let firstSymbol = true;
                  let index = 0;
                  for (let char of idle_year_circle_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      if (!firstSymbol) char_Angle -= idle_year_TextCircle_img_angle;
                      firstSymbol = false;
                      idle_year_TextCircle[index].setProperty(hmUI.prop.ANGLE, char_Angle);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.POS_X, 332 - idle_year_TextCircle_img_width / 2);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.SRC, idle_year_TextCircle_ASCIIARRAY[charCode]);
                      idle_year_TextCircle[index].setProperty(hmUI.prop.VISIBLE, true);
                      char_Angle -= idle_year_TextCircle_img_angle + 14;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

              console.log('update text rotate DISTANCE');
              let idle_distance_rotate_string = (distanceCurrent / 1000).toFixed(2);

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_distance_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, false);
                if (distanceCurrent != null && distanceCurrent != undefined && isFinite(distanceCurrent) && idle_distance_rotate_string.length > 0 && idle_distance_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_distance_TextRotate_posOffset = idle_distance_TextRotate_img_width * idle_distance_rotate_string.length;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset - idle_distance_TextRotate_img_width + idle_distance_TextRotate_dot_width;
                  idle_distance_TextRotate_posOffset = idle_distance_TextRotate_posOffset + 3 * (idle_distance_rotate_string.length - 1);
                  img_offset -= idle_distance_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_distance_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 251 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, idle_distance_TextRotate_ASCIIARRAY[charCode]);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_img_width + 3;
                      index++;
                    }  // end if digit
                    else { 
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.POS_X, 251 + img_offset);
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.SRC, 'Act_Dot.png');
                      idle_distance_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_distance_TextRotate_dot_width + 3;
                      index++;
                    };  // end if dot point 
                  };  // end char of string
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.POS_X, 251 + img_offset);
                  idle_distance_TextRotate_unit.setProperty(hmUI.prop.VISIBLE, true);
                }  // end isFinite
                else {
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.POS_X, 251 - idle_distance_TextRotate_error_img_width / 2);
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_01.png');
                  idle_distance_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate calorie_CALORIE');
              let idle_calorie_rotate_string = parseInt(valueCalories).toString();
              idle_calorie_rotate_string = idle_calorie_rotate_string.padStart(4, '0');

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 4; i++) {  // hide all symbols
                  idle_calorie_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueCalories != null && valueCalories != undefined && isFinite(valueCalories) && idle_calorie_rotate_string.length > 0 && idle_calorie_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_calorie_TextRotate_posOffset = idle_calorie_TextRotate_img_width * idle_calorie_rotate_string.length;
                  idle_calorie_TextRotate_posOffset = idle_calorie_TextRotate_posOffset + 4 * (idle_calorie_rotate_string.length - 1);
                  img_offset -= idle_calorie_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_calorie_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 4) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.POS_X, 185 + img_offset);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.SRC, idle_calorie_TextRotate_ASCIIARRAY[charCode]);
                      idle_calorie_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_calorie_TextRotate_img_width + 4;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite
                else {
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.POS_X, 185 - idle_calorie_TextRotate_error_img_width / 2);
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.SRC, 'Act_Font_01.png');
                  idle_calorie_TextRotate[0].setProperty(hmUI.prop.VISIBLE, true);
                };  // end else isFinite

              };

              console.log('update text rotate step_STEP');
              let idle_step_rotate_string = parseInt(valueStep).toString();

              if (screenType == hmSetting.screen_type.AOD) {
                for (var i = 1; i < 5; i++) {  // hide all symbols
                  idle_step_TextRotate[i].setProperty(hmUI.prop.VISIBLE, false);
                };
                if (valueStep != null && valueStep != undefined && isFinite(valueStep) && idle_step_rotate_string.length > 0 && idle_step_rotate_string.length < 6) {  // display data if it was possible to get it
                  let img_offset = 0;
                  // alignment = CENTER_H
                  let idle_step_TextRotate_posOffset = idle_step_TextRotate_img_width * idle_step_rotate_string.length;
                  idle_step_TextRotate_posOffset = idle_step_TextRotate_posOffset + 2 * (idle_step_rotate_string.length - 1);
                  img_offset -= idle_step_TextRotate_posOffset/2;
                  // alignment end
                  
                  let index = 0;
                  for (let char of idle_step_rotate_string) {
                    let charCode = char.charCodeAt()-48;
                    if (index >= 5) break;
                    if (charCode >= 0 && charCode < 10) { 
                      idle_step_TextRotate[index].setProperty(hmUI.prop.POS_X, 213 + img_offset);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.SRC, idle_step_TextRotate_ASCIIARRAY[charCode]);
                      idle_step_TextRotate[index].setProperty(hmUI.prop.VISIBLE, true);
                      img_offset += idle_step_TextRotate_img_width + 2;
                      index++;
                    };  // end if digit
                  };  // end char of string
                }  // end isFinite

              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                time_update(true, true);
                text_update();
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerTextUpdate) {
                    normal_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    idle_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerTextUpdate) {
                    idle_timerTextUpdate = timer.createTimer(0, 1000, (function (option) {
                      text_update();
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                if (normal_timerTextUpdate) {
                  timer.stopTimer(normal_timerTextUpdate);
                  normal_timerTextUpdate = undefined;
                }
                if (idle_timerUpdateSecSmooth) {
                  timer.stopTimer(idle_timerUpdateSecSmooth);
                  idle_timerUpdateSecSmooth = undefined;
                }
                if (idle_timerTextUpdate) {
                  timer.stopTimer(idle_timerTextUpdate);
                  idle_timerTextUpdate = undefined;
                }

              }),
            });

//////////////////////////////////////////////////////////////////////////////////////////////////  
          // Change color background shortcut start
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 175,
              y: 386,
              text: '',
              w: 105,
              h: 40,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            //Change color background shortcut end

    
//////////////////////////////////////////////////////////////////////////////////////////////////

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}