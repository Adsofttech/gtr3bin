﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_step_linear_scale = ''
        let normal_step_current_text_img = ''
        let normal_pai_icon_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_system_disconnect_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_stress_icon_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_system_disconnect_img = ''
        let idle_pai_icon_img = ''
        let idle_stress_icon_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF013041',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: -5,
              // start_y: 73,
              // color: 0xFF028ABD,
              // lenght: 339,
              // line_width: 80,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 14,
              y: 128,
              font_array: ["Tiny_white_Ginza_0001.png","Tiny_white_Ginza_0002.png","Tiny_white_Ginza_0003.png","Tiny_white_Ginza_0004.png","Tiny_white_Ginza_0005.png","Tiny_white_Ginza_0006.png","Tiny_white_Ginza_0007.png","Tiny_white_Ginza_0008.png","Tiny_white_Ginza_0009.png","Tiny_white_Ginza_0010.png"],
              padding: false,
              h_space: -32,
              unit_sc: 'simple_analog_percent.png',
              unit_tc: 'simple_analog_percent.png',
              unit_en: 'simple_analog_percent.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_step_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 395,
              // start_y: 64,
              // color: 0xFF028ABD,
              // lenght: 339,
              // line_width: 93,
              // vertical: True,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 392,
              y: 125,
              font_array: ["Tiny_white_Ginza_0001.png","Tiny_white_Ginza_0002.png","Tiny_white_Ginza_0003.png","Tiny_white_Ginza_0004.png","Tiny_white_Ginza_0005.png","Tiny_white_Ginza_0006.png","Tiny_white_Ginza_0007.png","Tiny_white_Ginza_0008.png","Tiny_white_Ginza_0009.png","Tiny_white_Ginza_0010.png"],
              padding: false,
              h_space: -32,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -23,
              y: -251,
              src: 'backwatch 3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 347,
              am_y: 363,
              am_sc_path: 'AMPM_white_Ginza_0001.png',
              am_en_path: 'AMPM_white_Ginza_0001.png',
              pm_x: 347,
              pm_y: 363,
              pm_sc_path: 'AMPM_white_Ginza_0002.png',
              pm_en_path: 'AMPM_white_Ginza_0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: -28,
              hour_array: ["Minute_white_Ginza_0001.png","Minute_white_Ginza_0002.png","Minute_white_Ginza_0003.png","Minute_white_Ginza_0004.png","Minute_white_Ginza_0005.png","Minute_white_Ginza_0006.png","Minute_white_Ginza_0007.png","Minute_white_Ginza_0008.png","Minute_white_Ginza_0009.png","Minute_white_Ginza_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 113,
              minute_startY: 140,
              minute_array: ["Hour_amber_Ginza_0001.png","Hour_amber_Ginza_0002.png","Hour_amber_Ginza_0003.png","Hour_amber_Ginza_0004.png","Hour_amber_Ginza_0005.png","Hour_amber_Ginza_0006.png","Hour_amber_Ginza_0007.png","Hour_amber_Ginza_0008.png","Hour_amber_Ginza_0009.png","Hour_amber_Ginza_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 410,
              y: 216,
              src: 'steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 26,
              y: 226,
              src: 'Batt.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 240,
              y: 403,
              src: 'HeartRate.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 403,
              font_array: ["Normal_white_Ginza_0001.png","Normal_white_Ginza_0002.png","Normal_white_Ginza_0003.png","Normal_white_Ginza_0004.png","Normal_white_Ginza_0005.png","Normal_white_Ginza_0006.png","Normal_white_Ginza_0007.png","Normal_white_Ginza_0008.png","Normal_white_Ginza_0009.png","Normal_white_Ginza_0010.png"],
              padding: false,
              h_space: -27,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -13,
              y: 126,
              src: 'Picture2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 103,
              y: 403,
              src: 'Calories.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 163,
              y: 402,
              font_array: ["Normal_white_Ginza_0001.png","Normal_white_Ginza_0002.png","Normal_white_Ginza_0003.png","Normal_white_Ginza_0004.png","Normal_white_Ginza_0005.png","Normal_white_Ginza_0006.png","Normal_white_Ginza_0007.png","Normal_white_Ginza_0008.png","Normal_white_Ginza_0009.png","Normal_white_Ginza_0010.png"],
              padding: false,
              h_space: -29,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 217,
              y: 402,
              src: 'slash.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 444,
              src: '21.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 238,
              day_startY: 30,
              day_sc_array: ["Normal_white_Ginza_0001.png","Normal_white_Ginza_0002.png","Normal_white_Ginza_0003.png","Normal_white_Ginza_0004.png","Normal_white_Ginza_0005.png","Normal_white_Ginza_0006.png","Normal_white_Ginza_0007.png","Normal_white_Ginza_0008.png","Normal_white_Ginza_0009.png","Normal_white_Ginza_0010.png"],
              day_tc_array: ["Normal_white_Ginza_0001.png","Normal_white_Ginza_0002.png","Normal_white_Ginza_0003.png","Normal_white_Ginza_0004.png","Normal_white_Ginza_0005.png","Normal_white_Ginza_0006.png","Normal_white_Ginza_0007.png","Normal_white_Ginza_0008.png","Normal_white_Ginza_0009.png","Normal_white_Ginza_0010.png"],
              day_en_array: ["Normal_white_Ginza_0001.png","Normal_white_Ginza_0002.png","Normal_white_Ginza_0003.png","Normal_white_Ginza_0004.png","Normal_white_Ginza_0005.png","Normal_white_Ginza_0006.png","Normal_white_Ginza_0007.png","Normal_white_Ginza_0008.png","Normal_white_Ginza_0009.png","Normal_white_Ginza_0010.png"],
              day_zero: 1,
              day_space: -30,
              day_align: hmUI.align.RIGHT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: -1,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 153,
              y: 18,
              week_en: ["Day_white_Ginza_0001.png","Day_white_Ginza_0002.png","Day_white_Ginza_0003.png","Day_white_Ginza_0004.png","Day_white_Ginza_0005.png","Day_white_Ginza_0006.png","Day_white_Ginza_0007.png"],
              week_tc: ["Day_white_Ginza_0001.png","Day_white_Ginza_0002.png","Day_white_Ginza_0003.png","Day_white_Ginza_0004.png","Day_white_Ginza_0005.png","Day_white_Ginza_0006.png","Day_white_Ginza_0007.png"],
              week_sc: ["Day_white_Ginza_0001.png","Day_white_Ginza_0002.png","Day_white_Ginza_0003.png","Day_white_Ginza_0004.png","Day_white_Ginza_0005.png","Day_white_Ginza_0006.png","Day_white_Ginza_0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -48,
              y: -48,
              src: 'Picture2-Ring239.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 347,
              am_y: 363,
              am_sc_path: 'AMPM_white_Ginza_0001.png',
              am_en_path: 'AMPM_white_Ginza_0001.png',
              pm_x: 347,
              pm_y: 363,
              pm_sc_path: 'AMPM_white_Ginza_0002.png',
              pm_en_path: 'AMPM_white_Ginza_0002.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 114,
              hour_startY: -28,
              hour_array: ["Minute_white_Ginza_0001.png","Minute_white_Ginza_0002.png","Minute_white_Ginza_0003.png","Minute_white_Ginza_0004.png","Minute_white_Ginza_0005.png","Minute_white_Ginza_0006.png","Minute_white_Ginza_0007.png","Minute_white_Ginza_0008.png","Minute_white_Ginza_0009.png","Minute_white_Ginza_0010.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 113,
              minute_startY: 140,
              minute_array: ["Minute_white_Ginza_0001.png","Minute_white_Ginza_0002.png","Minute_white_Ginza_0003.png","Minute_white_Ginza_0004.png","Minute_white_Ginza_0005.png","Minute_white_Ginza_0006.png","Minute_white_Ginza_0007.png","Minute_white_Ginza_0008.png","Minute_white_Ginza_0009.png","Minute_white_Ginza_0010.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -18,
              y: 126,
              src: 'Picture2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 221,
              y: 444,
              src: '21.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: -28,
              y: -22,
              src: 'AOB Overlay.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 206,
              y: 0,
              src: 'icon_Picture - OG.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = -5;
                  let start_y_normal_battery = 73;
                  let lenght_ls_normal_battery = 339;
                  let line_width_ls_normal_battery = 80;
                  let color_ls_normal_battery = 0xFF028ABD;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = line_width_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = lenght_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    line_width_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_y_normal_battery_draw = start_y_normal_battery_draw - line_width_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_ls_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_linear_scale
                  // initial parameters
                  let start_x_normal_step = 395;
                  let start_y_normal_step = 64;
                  let lenght_ls_normal_step = 339;
                  let line_width_ls_normal_step = 93;
                  let color_ls_normal_step = 0xFF028ABD;
                  
                  // calculated parameters
                  let start_x_normal_step_draw = start_x_normal_step;
                  let start_y_normal_step_draw = start_y_normal_step;
                  lenght_ls_normal_step = lenght_ls_normal_step * progress_ls_normal_step;
                  let lenght_ls_normal_step_draw = line_width_ls_normal_step;
                  let line_width_ls_normal_step_draw = lenght_ls_normal_step;
                  if (lenght_ls_normal_step < 0){
                    line_width_ls_normal_step_draw = -lenght_ls_normal_step;
                    start_y_normal_step_draw = start_y_normal_step_draw - line_width_ls_normal_step_draw;
                  };
                  
                  normal_step_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_step_draw,
                    y: start_y_normal_step_draw,
                    w: lenght_ls_normal_step_draw,
                    h: line_width_ls_normal_step_draw,
                    color: color_ls_normal_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}