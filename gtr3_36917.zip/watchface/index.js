﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_distance_icon_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let timeSensor = ''

        let set_p_button = ''
        let step_cal_state = 0 // смена показаний
        let step_cal_state_txt = ''

        function step_cal_Switcher() {

          let step_cal_state_total = 6;
  
          step_cal_state = (step_cal_state + 1) % step_cal_state_total;
  
          switch (step_cal_state) {
  
              case 0:
                
                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                 
                step_cal_state_txt = 'Заряд';
              break;
  
              case 1:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Пульс'; 
              break;

              case 2:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Шаги'; 
              break;

              case 3:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Дистанция'; 
              break;

              case 4:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Погода'; 
              break;

              case 5:

                normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, true);
                normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_icon_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_battery_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
                step_cal_state_txt = 'Цифровое время'; 
              break;

              default:
                  break;
          }
  
          hmUI.showToast({ text: step_cal_state_txt });
        }
  
        let hands_smoth_btn = ''
        let hands_smoth_state = 0 // 0 - smoth, 1 - normal
        let hands_smoth_state_txt = ''

        function click_bot_hsmoth_Switcher() {
  
          let bot_hands_state_total = 2;
  
          hands_smoth_state = (hands_smoth_state + 1) % bot_hands_state_total;
  
          switch (hands_smoth_state) {
  
              case 0:
  
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, true);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);
  
                hands_smoth_state_txt = 'Плавная стрелка';
                  break;
  
              case 1:
  
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.VISIBLE, false);
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, true);
  
                hands_smoth_state_txt = 'Нормальная стрелка';
                  break;
  
              default:
                  break;
          }
  
          hmUI.showToast({ text: hands_smoth_state_txt });
        }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 218,
              y: 218,
              src: '0114.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 183,
              hour_startY: 367,
              hour_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dig_32_dots.png',
              hour_unit_tc: 'dig_32_dots.png',
              hour_unit_en: 'dig_32_dots.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 323,
              src: 'mode_ru_6.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 151,
              y: 323,
              src: 'mode_ru_5.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 195,
              y: 367,
              font_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'd32_w_degr.png',
              unit_tc: 'd32_w_degr.png',
              unit_en: 'd32_w_degr.png',
              negative_image: 'd32_w_minus.png',
              invalid_image: 'd32_w_minus.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 323,
              src: 'mode_ru_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 367,
              font_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              dot_image: 'd32_w_dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 149,
              y: 323,
              src: 'mode_ru_3.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 185,
              y: 367,
              font_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 323,
              src: 'mode_ru_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 367,
              font_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 148,
              y: 323,
              src: 'mode_ru_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 367,
              font_array: ["d32_w_0.png","d32_w_1.png","d32_w_2.png","d32_w_3.png","d32_w_4.png","d32_w_5.png","d32_w_6.png","d32_w_7.png","d32_w_8.png","d32_w_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 149,
              y: 78,
              week_en: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              week_tc: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              week_sc: ["week_ru_1.png","week_ru_2.png","week_ru_3.png","week_ru_4.png","week_ru_5.png","week_ru_6.png","week_ru_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 138,
              day_sc_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_tc_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_en_array: ["d32_or_0.png","d32_or_1.png","d32_or_2.png","d32_or_3.png","d32_or_4.png","d32_or_5.png","d32_or_6.png","d32_or_7.png","d32_or_8.png","d32_or_9.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'arr_hour_14-173.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 14,
              hour_posY: 170,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'arr_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 14,
              minute_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'arr_sec.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 14,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.VISIBLE, false);

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_sec.png',
              // center_x: 227,
              // center_y: 227,
              // x: 14,
              // y: 218,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 14,
              pos_y: 227 - 218,
              center_x: 227,
              center_y: 227,
              src: 'arr_sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 2,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_digital_clock_img_time.setProperty(hmUI.prop.VISIBLE, false);
            normal_digital_clock_minute_separator_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            hands_smoth_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 180,
              text: '',
              w: 95,
              h: 95,
              normal_src: '',
              press_src: '',
              click_func: () => {
                click_bot_hsmoth_Switcher();
                  //vibro(9);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
          });
          hands_smoth_btn.setProperty(hmUI.prop.VISIBLE, true);

          set_p_button = hmUI.createWidget(hmUI.widget.BUTTON, {
            x: 180,
            y: 312,
            text: '',
            w: 95,
            h: 95,
            normal_src: '',
            press_src: '',
            click_func: () => {
              step_cal_Switcher();
                //vibro(9);
            },
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           set_p_button.setProperty(hmUI.prop.VISIBLE, true);

              // календарь
              hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 180,
                y: 54,
                w: 95,
                h: 95,
                text: '',
                normal_src: '',
                press_src: '',
                click_func: () => {
                hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
               });	


            console.log('Watch_Face.ScreenAOD');

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'arr_hour_14-173.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 14,
              hour_posY: 170,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'arr_min.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 14,
              minute_posY: 216,
              minute_cover_path: 'up.png',
              minute_cover_x: 215,
              minute_cover_y: 215,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*(second + (timeSensor.utc % 1000)/1000)/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let animDelay = 0;
                    let animRepeat = 1000/15;
                    normal_timerUpdateSecSmooth = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}