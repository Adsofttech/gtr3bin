﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_pai_icon_img = ''
        let normal_stress_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_step_icon_img = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg = ''
        let idle_image_img = ''
        let idle_heart_rate_pointer_progress_img_pointer = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_stress_icon_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_pai_image_progress_img_level = ''

        let timeSensor = ''

       // смена безеля
       //let bezel_img = ''
       let btn_bezel = ''
       let btn_bezel_state = 0 // 0 - тип 1, 1 - тип 2
       let btn_bezel_state_txt = ''
 
       function click_Bezel() {
 
         let bot_bezel_state_total = 2;
 
         btn_bezel_state = (btn_bezel_state + 1) % bot_bezel_state_total;
 
         switch (btn_bezel_state) {

          case 0:
                 
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, true);

            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_1.png',
              center_x: 138,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_1.png',
              center_x: 342,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
              
            btn_bezel_state_txt = 'Стандартный';
            break;

            case 1:
                 
            normal_step_icon_img.setProperty(hmUI.prop.VISIBLE, false);
            
            normal_heart_rate_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_2.png',
              center_x: 138,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
           
            normal_step_pointer_progress_img_pointer.setProperty(hmUI.prop.MORE, {
              src: 'pointer_2.png',
              center_x: 342,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
              
            btn_bezel_state_txt = 'Инверсный';
            break;

            default:
              break;
      }

      hmUI.showToast({ text: btn_bezel_state_txt });
    }

        // смена маски
        //let bot_circle_btn = ''
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 7
            
       function click_mask() {
         if(mask_num>=mask_all) {mask_num=1;}
          else { mask_num=mask_num+1;}
           hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
           normal_pai_icon_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
       }

       //смена окантовки
        let okan_num = 1
        let okan_all = 8
            
       function click_okan() {
         if(okan_num>=okan_all) {okan_num=1;}
          else { okan_num=okan_num+1;}
           hmUI.showToast({text: "<Окантовка> " + parseInt(okan_num) });
           normal_stress_icon_img.setProperty(hmUI.prop.SRC, "okan_" + parseInt(okan_num) + ".png");
       }

       let hands_smoth_btn = ''
       let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
       let sec_smoth_state_txt = ''
 
       function click_bot_ssmoth_Switcher() {
 
         let bot_sec_state_total = 4;
 
         sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;
 
         switch (sec_smoth_state) {
 
             case 0:
                 
               normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                hour_path: 'hour_1.png',
                hour_centerX: 240,
                hour_centerY: 240,
                hour_posX: 59,
                hour_posY: 240,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
              normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                minute_path: 'min_1.png',
                minute_centerX: 240,
                minute_centerY: 240,
                minute_posX: 59,
                minute_posY: 240,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                second_path: 'sec_1.png',
                second_centerX: 240,
                second_centerY: 240,
                second_posX: 59,
                second_posY: 240,
                show_level: hmUI.show_level.ONLY_NORMAL,
              });
  
       
               sec_smoth_state_txt = 'Стрелка 1';
                 break;
 
             case 1:
 
             normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: 'hour_2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 59,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: 'min_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 59,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
              second_path: 'sec_2.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 59,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

             sec_smoth_state_txt = 'Стрелка 2';
                 break;

                 case 2:
 
                 normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                  hour_path: 'hour_3.png',
                  hour_centerX: 240,
                  hour_centerY: 240,
                  hour_posX: 59,
                  hour_posY: 240,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                  minute_path: 'min_3.png',
                  minute_centerX: 240,
                  minute_centerY: 240,
                  minute_posX: 59,
                  minute_posY: 240,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
    
                normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                  second_path: 'sec_1.png',
                  second_centerX: 240,
                  second_centerY: 240,
                  second_posX: 59,
                  second_posY: 240,
                  show_level: hmUI.show_level.ONLY_NORMAL,
                });
                     sec_smoth_state_txt = 'Стрелка 3';
                     break;

                     case 3:
 
                     normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                      hour_path: 'hour_4.png',
                      hour_centerX: 240,
                      hour_centerY: 240,
                      hour_posX: 59,
                      hour_posY: 240,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                      minute_path: 'min_4.png',
                      minute_centerX: 240,
                      minute_centerY: 240,
                      minute_posX: 59,
                      minute_posY: 240,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
        
                    normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.MORE, {
                      second_path: 'sec_2.png',
                      second_centerX: 240,
                      second_centerY: 240,
                      second_posX: 59,
                      second_posY: 240,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                         sec_smoth_state_txt = 'Стрелка 4';
                         break;
    
             default:
                 break;
         }
 
         hmUI.showToast({ text: sec_smoth_state_txt });
       }

       let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
       
       let switch_checkBT;
       let switch_hourlyVibro;
       
       const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider1_on.png' : 'slider1_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   
   //--------------------- вибрация каждый час  ---------------------
       function setEveryHourVibro() {
         curTime.addEventListener(curTime.event.MINUTEEND, function () {
             if (everyHourVibro && !(curTime.minute % 60)) {
               vibro(27);
               hmUI.showToast({text: "Новый час!!!"});
             }
         });
           }
   
   //----------------- вибрация каждый час: включение/отключение  ------------------
       function toggleEveryHourVibro() {
         everyHourVibro = !everyHourVibro;
         vibro();
         hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 
         hmUI.showToast({text: "Ежечасная вибрация " + (everyHourVibro ? "включена" : "отключена")});
           }
   
   
   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
         if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
           everyHourVibro = false;
           hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         } else {
           everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
         }
     
       }

       //const curTime = hmSensor.createSensor(hmSensor.id.TIME);
       //------------------------ автозамена иконок погоды -----------------------------------
       
       let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
       
       let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
       let weatherData = weather.getForecastWeather();
       let forecastData = weatherData.forecastData;
       let sunData = weatherData.tideData;
       let today = '';
       let sunriseMins = '';
       let sunsetMins = '';
       let sunriseMins_def = 8 * 60;			// время восхода
       let sunsetMins_def = 20 * 60;			// и заката по умолчанию
       
       let curMins = '';
       
       let isDayIcons = true;
       let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
       
       function autoToggleWeatherIcons() {
       
       weatherData = weather.getForecastWeather();
       sunData = weatherData.tideData;
       if (sunData.count > 0){
       today = sunData.data[0];
       sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
       sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
       } else {
       sunriseMins = sunriseMins_def;
       sunsetMins = sunsetMins_def;
       }
       
       curMins = curTime.hour * 60 + curTime.minute;
       let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
       
       if(isDayNow){
       if(!isDayIcons){
         for (let i = 0; i < wiReplacement.length; i++) {
           weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
         }
         isDayIcons = true;
       }
       } else {
       if(isDayIcons){
         for (let i = 0; i < wiReplacement.length; i++) {
           weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
         }
         isDayIcons = false;
       }
       }
       }
       
       //------------------------ автозамена иконок погоды ----------------------------------- \\		

       let delay_Timer = null;
       let clicks = 0;
       let clicksDelay = 400;       // задержка между кликами в мс 
     
     //--------------------- обработка множественных кликов (тапов) 1, 2, 3, ...  ---------------------		
         function checkClicks() {

           switch(clicks) {
             case 1:
               click_mask();
            break;
             case 2:
              click_Bezel(); // функции на двойной клик
            break;
            // case 3:
            //   click_mask();// функции на тройной клик
            // break;
            // case 4:
              // функции на 4-ной клик
            //break;
             default:
            break;
          }
           
          timer.stopTimer(delay_Timer);
          clicks = 0;

         }
           
       
     
         function getClick() {		
     
           clicks++;
           if(delay_Timer) timer.stopTimer(delay_Timer);
           delay_Timer = timer.createTimer(clicksDelay, 0, checkClicks, {});
     
         }


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 284,
              y: 53,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 185,
              y: 52,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'df_2.png',
              // center_x: 240,
              // center_y: 240,
              // x: 71,
              // y: 71,
              // start_angle: 360,
              // end_angle: 0,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 71,
              pos_y: 240 - 71,
              center_x: 240,
              center_y: 240,
              src: 'df_2.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'df_1.png',
              // center_x: 240,
              // center_y: 240,
              // x: 71,
              // y: 71,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 240 - 71,
              pos_y: 240 - 71,
              center_x: 240,
              center_y: 240,
              src: 'df_1.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["inmask_1.png"],
              image_length: 1,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'okan_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 218,
              y: 132,
              font_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 308,
              day_startY: 321,
              day_sc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_tc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_en_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 299,
              y: 360,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 138,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 124,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 142,
              y: 104,
              src: 'heart_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 342,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 280,
              y: 124,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 295,
              y: 104,
              src: 'Step_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'dot_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 322,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_13.png',
              unit_tc: 'num_13.png',
              unit_en: 'num_13.png',
              negative_image: 'num_11.png',
              invalid_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 129,
              y: 360,
              src: 'temp_icon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 334,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 59,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 59,
              minute_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 59,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 298,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              click_func: () => {
                click_okan();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);
      
            btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 82,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              click_func: () => {
                  getClick();
                  vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);

            hands_smoth_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 190,
              y: 190,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              click_func: () => {
                  click_bot_ssmoth_Switcher();
                  vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            hands_smoth_btn.setProperty(hmUI.prop.VISIBLE, true);


      // кнопка включения/отключения ежечасного сигнала
      switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
        x: 68,
        y: 338,
        w: 70,
        h: 70,
        src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
          switch_hourlyVibro.addEventListener(hmUI.event.CLICK_UP, function () {
          toggleEveryHourVibro();
       });


      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 340,
        y: 338,
        w: 70,
        h: 70,
        src: checkBT ? 'slider1_on.png' : 'slider1_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });

                // низкий заряд
                hmUI.createWidget(hmUI.widget.BUTTON, {
                  x: 205,
                  y: 100,
                  w: 64,
                  h: 72,
                  text: '',
                  normal_src: '',
                  press_src: '',
                  click_func: () => {
                  hmApp.startApp({ url: 'LowBatteryScreen', native: true });
                  },
                  show_level: hmUI.show_level.ONLY_NORMAL,
              });				
       
              // календарь
              hmUI.createWidget(hmUI.widget.BUTTON, {
                x: 290,
                y: 289,
                w: 48,
                h: 95,
                text: '',
                normal_src: '',
                press_src: '',
                click_func: () => {
                hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
                },
                show_level: hmUI.show_level.ONLY_NORMAL,
               });	

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'aod_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 138,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 342,
              center_y: 240,
              x: 64,
              y: 64,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_stress_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 57,
              y: 156,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'aos_h_1.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 59,
              hour_posY: 240,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'aos_m_1.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 59,
              minute_posY: 240,
              minute_cover_path: 'aod_center.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 190,
              y: 324,
              w: 100,
              h: 100,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 100,
              y: 66,
              w: 100,
              h: 100,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 274,
              y: 65,
              w: 100,
              h: 100,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function time_update(updateHour = false, updateMinute = false) {
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              let normal_fullAngle_second = -360;
              let normal_angle_second = 360 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                stopVibro();
                checkConnection(checkBT);
                autoToggleWeatherIcons();
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                stopVibro();
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }

              }),
            });

            setEveryHourVibro();

                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}