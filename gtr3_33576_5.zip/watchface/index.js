﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSecSmooth = undefined;
        let lastTime = 0;
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_sun_high_text_img = ''
        let normal_sun_high_separator_img = ''
        let normal_sun_low_text_img = ''
        let normal_sun_low_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_temperature_current_separator_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let image_top_img = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stress_jumpable_img_click = ''
        let timeSensor = ''
		let calendar_btn = ''
		let battery_btn = ''
		let next_panel_btn = ''
		let prev_panel_btn = ''
		let btnchangehands = ''
		let handsnumber = 0
        let totalhands = 3

function loadSettings() {
			if (hmFS.SysProGetInt('lk_panel') === undefined) {
			 panel_state = 0;
			 hmFS.SysProSetInt('lk_panel', panel_state);
			}
			else {
			panel_state = hmFS.SysProGetInt('lk_panel');
			}
		}
		
		function click_panel_Switcher() {

			let panel_state_total = 7;

			panel_state = (panel_state + 1) % panel_state_total;
			
			hmFS.SysProSetInt('lk_panel', panel_state);

			apply_panel_switch();
		}

		function click_panel_Switcher_reverse() {

			let panel_state_total = 7;

			if (panel_state == 0) {
			panel_state = panel_state_total - 1;
			} else {
			panel_state = (panel_state - 1) % panel_state_total;
		}
		
		hmFS.SysProSetInt('lk_panel', panel_state);

		apply_panel_switch();
		}
		
		function apply_panel_switch() {
			switch (panel_state) {

        case 0:
		//panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'STEPS'});
		 
          break;

        case 1:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'DISTANCE'});

          break;

        case 2:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'HEARTRATE'});

          break;
		  
		  case 3:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, true);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
          normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'WEATHER'});

          break;
		  
		  case 4:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

		  hmUI.showToast({text: 'CALORIES'});
		  
          break;
		  
		  case 5:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, true);
      normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  
		  hmUI.showToast({text: 'SUNRISE'});

          break;
		  
		  case 6:
    //panel 1
		  normal_step_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_step_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 2
		  normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 3
		  normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 4
		  normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);
		  normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 5
		  normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		  normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);
      normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);
		//panel 6
		  normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, true);
		  normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, true);
		  
		  hmUI.showToast({text: 'SUNSET'});

        default:
          break;
      }
    }

        function click_ChangeHands() {
          handsnumber=handsnumber+1;
          switch (handsnumber) {
            case 1:
              ChangeHands(1); break;
			case 2:
              ChangeHands(2); break;
			case 3:
              ChangeHands(3); break;
            default:
              ChangeHands(0); handsnumber=0;
          }
      if(handsnumber==1) hmUI.showToast({text: 'RED HANDS'});
		  if(handsnumber==2) hmUI.showToast({text: 'DARK HANDS'});
		  if(handsnumber==3) hmUI.showToast({text: 'LIGHT HANDS'});
		  if(handsnumber==0) hmUI.showToast({text: 'GRAY HANDS'});
        }
		
		 function ChangeHands(number) {
           if(number==1) {
				  hourstring='hands_hour.png';
                  minstring='hands_minute.png';
             } else if(number==2) {
                  hourstring='hands_hour_B.png';
                  minstring='hands_minute_B.png';
             } else if(number==3) {
                  hourstring='hands_hour_W.png';
                  minstring='hands_minute_W.png';
             } else {
                  hourstring='hands_hour_G.png';
                  minstring='hands_minute_G.png';
             }
              
			normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
              hour_path: hourstring,
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 129,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
              minute_path: minstring,
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
        }
        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'sec.png',
              // center_x: 227,
              // center_y: 236,
              // x: 162,
              // y: 162,
              // start_angle: 29,
              // end_angle: 389,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 162,
              pos_y: 236 - 162,
              center_x: 227,
              center_y: 236,
              src: 'sec.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec, animDuration) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + (360*(animDuration*6/1000))/360,
                repeat_count: 1,
                anim_fps: 15,
                anim_key: 'angle',
                anim_status: 1,
              }
              normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANIM, secAnim);
            }
            // normal_analog_clock_pro_smooth_second = hmUI.createWidget(hmUI.widget.SMOOTH_SECOND, {
              // type: 1,
              // fps: 15,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 229,
              // center_y: 228,
              // start_angle: 4,
              // end_angle: 120,
              // radius: 212,
              // line_width: 19,
              // line_cap: Rounded,
              // color: 0xFFFF0000,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 229,
              center_y: 228,
              start_angle: 4,
              end_angle: 120,
              radius: 203,
              line_width: 19,
              corner_flag: 0,
              color: 0xFFFF0000,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'overlay1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 183,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_1steps.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["overlay0.png"],
              image_length: 1,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              dot_image: 'Act_Small_Font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_6sr.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_high_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 187,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              dot_image: 'Act_Small_Font_12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_sun_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_7ss.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sun_low_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 97,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 3,
              angle: 0,
              unit_sc: 'Act_Small_Font_km.png',
              unit_tc: 'Act_Small_Font_km.png',
              unit_en: 'Act_Small_Font_km.png',
              dot_image: 'Act_Small_Font_11.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_2dist.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_distance_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 5,
              angle: 0,
              invalid_image: 'zone1.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_3pulse.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_text_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 310,
              y: 333,
              image_array: ["zone1.png","zone2.png","zone3.png","zone4.png","zone5.png","zone6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_rate_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 220,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              unit_sc: 'Weather_symbo_02.png',
              unit_tc: 'Weather_symbo_02.png',
              unit_en: 'Weather_symbo_02.png',
              negative_image: 'Weather_symbo_01.png',
              invalid_image: 'Weather_symbo_01.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_4weather.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 180,
              y: 327,
              image_array: ["weather_icon_01.png","weather_icon_02.png","weather_icon_03.png","weather_icon_04.png","weather_icon_05.png","weather_icon_06.png","weather_icon_07.png","weather_icon_08.png","weather_icon_09.png","weather_icon_10.png","weather_icon_11.png","weather_icon_12.png","weather_icon_13.png","weather_icon_14.png","weather_icon_15.png","weather_icon_16.png","weather_icon_17.png","weather_icon_18.png","weather_icon_19.png","weather_icon_20.png","weather_icon_21.png","weather_icon_22.png","weather_icon_23.png","weather_icon_24.png","weather_icon_25.png","weather_icon_26.png","weather_icon_27.png","weather_icon_28.png","weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_weather_image_progress_img_level.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 190,
              y: 333,
              font_array: ["Act_Small_Font_01.png","Act_Small_Font_02.png","Act_Small_Font_03.png","Act_Small_Font_04.png","Act_Small_Font_05.png","Act_Small_Font_06.png","Act_Small_Font_07.png","Act_Small_Font_08.png","Act_Small_Font_09.png","Act_Small_Font_10.png"],
              padding: false,
              h_space: 5,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_text_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'icon_5cal.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_calorie_current_separator_img.setProperty(hmUI.prop.VISIBLE, false);

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 111,
              y: 325,
              image_array: ["Moon_01.png","Moon_02.png","Moon_03.png","Moon_04.png","Moon_05.png","Moon_06.png","Moon_07.png","Moon_08.png","Moon_09.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Batt_pointer.png',
              center_x: 324,
              center_y: 227,
              x: 10,
              y: 47,
              start_angle: 480,
              end_angle: 240,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 242,
              font_array: ["Battery_font_01.png","Battery_font_02.png","Battery_font_03.png","Battery_font_04.png","Battery_font_05.png","Battery_font_06.png","Battery_font_07.png","Battery_font_08.png","Battery_font_09.png","Battery_font_10.png"],
              padding: false,
              h_space: 2,
              angle: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 131,
              src: 'system_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 132,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 44,
              y: 45,
              week_en: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_tc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              week_sc: ["WEEK1.png","WEEK2.png","WEEK3.png","WEEK4.png","WEEK5.png","WEEK6.png","WEEK7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'month_pointer.png',
              center_x: 130,
              center_y: 226,
              posX: 21,
              posY: 78,
              start_angle: -30,
              end_angle: 330,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 105,
              day_startY: 201,
              day_sc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_tc_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_en_array: ["Date_font_01.png","Date_font_02.png","Date_font_03.png","Date_font_04.png","Date_font_05.png","Date_font_06.png","Date_font_07.png","Date_font_08.png","Date_font_09.png","Date_font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 221,
              am_y: 44,
              am_sc_path: 'Clock_AM.png',
              am_en_path: 'Clock_AM.png',
              pm_x: 221,
              pm_y: 44,
              pm_sc_path: 'Clock_PM.png',
              pm_en_path: 'Clock_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 113,
              hour_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 113,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: -9,
              second_startY: 122,
              second_array: ["Time_sec_00.png","Time_sec_01.png","Time_sec_02.png","Time_sec_03.png","Time_sec_04.png","Time_sec_05.png","Time_sec_06.png","Time_sec_07.png","Time_sec_08.png","Time_sec_09.png"],
              second_zero: 1,
              second_space: 227,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour_G.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 129,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute_G.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'hands_seconds_s.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 217,
              second_cover_path: 'miiddle.png',
              second_cover_x: 213,
              second_cover_y: 213,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 136,
              y: 131,
              src: 'system_BT_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 298,
              y: 132,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 163,
              hour_startY: 113,
              hour_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 113,
              minute_array: ["time_font_01.png","time_font_02.png","time_font_03.png","time_font_04.png","time_font_05.png","time_font_06.png","time_font_07.png","time_font_08.png","time_font_09.png","time_font_10.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 122,
              src: 'digital_dot.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hands_hour_B.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 34,
              hour_posY: 129,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'hands_minute_B.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 34,
              minute_posY: 208,
              minute_cover_path: 'miiddle.png',
              minute_cover_x: 213,
              minute_cover_y: 213,
              show_level: hmUI.show_level.ONLY_AOD,
            });
            
            // disconnectAlert = hmUI.createWidget(hmUI.widget.DisconnectAlert, {
              // disconneсnt_vibrate_type: 27,
              // disconneсnt_toast_text: Bluetooth OFF,
              // conneсnt_vibrate_type: 0,
              // conneсnt_toast_text: Bluetooth ON,
            // });

            // vibration when connecting or disconnecting

            function checkConnection() {
              hmBle.removeListener;
              hmBle.addListener(function (status) {
                if(!status) {
                  hmUI.showToast({text: "Bluetooth OFF"});
                  vibro(27);
                }
                if(status) {
                  hmUI.showToast({text: "Bluetooth ON"});
                  vibro(0);
                }
              });
            }

            // end vibration when connecting or disconnecting
            // vibrate function

            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let timer_StopVibrate = null;


            function vibro(scene = 25) {
              let stopDelay = 50;
              stopVibro();
              vibrate.stop();
              vibrate.scene = scene;
              if(scene < 23 || scene > 25) stopDelay = 1300;
              vibrate.start();
              timer_StopVibrate = timer.createTimer(stopDelay, 3000, stopVibro, {});
            }

            function stopVibro(){
              vibrate.stop();
              if(timer_StopVibrate) timer.stopTimer(timer_StopVibrate);
            }

            // end vibrate function

            image_top_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'ring.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 227,
              y: 85,
              w: 76,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 151,
              y: 85,
              w: 76,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_spo2_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_pai_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_temperature_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_sunrise_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);
			
			btnchangehands = hmUI.createWidget(hmUI.widget.BUTTON, {
			  x: 180,
              y: 175,
              text: '',
              w: 95,
              h: 104,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
              click_func: () => {
                click_ChangeHands();
                vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 284,
              w: 95,
              h: 95,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			normal_heart_jumpable_img_click.setProperty(hmUI.prop.VISIBLE, false);

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 14,
              w: 95,
              h: 66,
              src: '0_Empty.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
			
			next_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 276,
				y: 360,
				text: '',
				w: 62,
				h: 62,
				normal_src: '0_Empty.png',
                press_src: '0_Empty.png',
				click_func: () => {
					click_panel_Switcher();
					vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

			prev_panel_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
				x: 119,
				y: 360,
				text: '',
				w: 62,
				h: 62,
				normal_src: '0_Empty.png',
                press_src: '0_Empty.png',
				click_func: () => {
					click_panel_Switcher_reverse();
					vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			calendar_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 76,
              y: 175,
			  text: '',
              w: 104,
              h: 104,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'ScheduleCalScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
			battery_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 274,
              y: 175,
			  text: '',
              w: 104,
              h: 104,
              normal_src: '0_Empty.png',
              press_src: '0_Empty.png',
			  click_func: () => {
				hmApp.startApp({ appid: 1, url: 'LowBatteryScreen', native: true });
				vibro(25);
				},
				show_level: hmUI.show_level.ONLY_NORMAL,
			});

            function scale_call() {

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 229,
                      center_y: 228,
                      start_angle: 4,
                      end_angle: 120,
                      radius: 203,
                      line_width: 19,
                      corner_flag: 0,
                      color: 0xFFFF0000,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };
			
			loadSettings();

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                let secAngle = 29 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, secAngle);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSecSmooth) {
                    let duration = 0;
                    let animDuration = 5000;
                    if (timeSensor.second > 55) animDuration = 1000*(60.1 - (timeSensor.second - (timeSensor.utc % 1000) / 1000));
                    let diffTime = timeSensor.utc - lastTime;
                    if (diffTime < animDuration) duration = animDuration - diffTime;
                    normal_timerUpdateSecSmooth = timer.createTimer(duration, animDuration, (function (option) {
                      lastTime = timeSensor.utc;
                      secAngle = 29 + (360*6)*(timeSensor.second + ((timeSensor.utc % 1000) / 1000))/360;
                      startSecAnim(secAngle, animDuration);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                checkConnection();
                stopVibro();

              }),
              pause_call: (function () {
                if (normal_timerUpdateSecSmooth) {
                  timer.stopTimer(normal_timerUpdateSecSmooth);
                  normal_timerUpdateSecSmooth = undefined;
                }
                stopVibro();

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}