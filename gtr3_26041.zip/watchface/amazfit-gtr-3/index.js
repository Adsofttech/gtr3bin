try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
    //-----01此处添加下列代码 代码块 开始位置 ------

    let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 1000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 200,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 454,/*屏幕宽度  3p 480*/
          h: 454,/*屏幕宽度  3p 480*/
          pos_x: 454 / 2 - 14,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 454 / 2 - 225,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 227, /*表盘旋转中心 3p 240*/
          center_y: 227,/*表盘旋转中心 3p 240*/
          src: '68.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
     
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘

          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          easeInAnim();
          easeInAnim();
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------        
		const n = e.current,
            {
                px: g
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, n)), e.app.__globals__),
            _ = Logger.getLogger("watchface6");
        n.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 200,
                    y: 150,
                    type: hmUI.data_type.STEP,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 153,
                    y: 52,
                    src: "13.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "14.png",
                    center_x: 227,
                    center_y: 128,
                    x: 6,
                    y: 58,
                    type: hmUI.data_type.STEP,
                    start_angle: 0,
                    end_angle: 360,
                    cover_path: "",
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 215,
                    y: 338,
                    type: hmUI.data_type.HEART,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    invalid_image: "15.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 153,
                    y: 240,
                    src: "16.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "17.png",
                    center_x: 227,
                    center_y: 315,
                    x: 6,
                    y: 58,
                    type: hmUI.data_type.HEART,
                    start_angle: 0,
                    end_angle: 360,
                    cover_path: "",
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 351,
                    y: 216,
                    week_sc: ["18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_DATE, {
                    day_startX: 413,
                    day_startY: 214,
                    day_sc_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_tc_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_en_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    day_align: hmUI.align.LEFT,
                    day_zero: 1,
                    day_follow: 0,
                    day_space: 0,
                    day_is_character: !1,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 12,
                    y: 205,
                    image_array: ["35.png", "36.png", "37.png", "38.png", "39.png", "40.png", "41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png", "51.png", "52.png", "53.png", "54.png", "55.png", "56.png", "57.png", "58.png", "59.png", "60.png", "61.png", "62.png", "63.png"],
                    image_length: 29,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 58,
                    y: 214,
                    type: hmUI.data_type.WEATHER_CURRENT,
                    font_array: ["25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png", "33.png", "34.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    negative_image: "65.png",
                    invalid_image: "64.png",
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 14,
                    hour_posY: 206,
                    hour_path: "66.png",
                    hour_cover_path: "",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 13,
                    minute_posY: 206,
                    minute_path: "67.png",
                    minute_cover_path: "",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 1001,
                    second_posY: 1001,
                    second_path: "68.png",
                    second_cover_path: "",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 
				    setSec()
				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "69.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 15,
                    hour_posY: 227,
                    hour_path: "70.png",
                    hour_cover_path: "",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 15,
                    minute_posY: 227,
                    minute_path: "71.png",
                    minute_cover_path: "",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_path: '68.png',
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 14,
                    second_posY: 225,
					enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 212,
                    y: 274,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_AOD,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "72.png",
                    center_x: 227,
                    center_y: 304,
                    x: 8,
                    y: 50,
                    type: hmUI.data_type.BATTERY,
                    start_angle: 0,
                    end_angle: 360,
                    cover_path: "",
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_AOD
                })
            }, onInit() {
                _.log("index page.js on init invoke")
            }, build() {
                this.init_view(), _.log("index page.js on ready invoke")
            }, onDestory() {
                _.log("index page.js on destory invoke")
            stopSecAnim()
			}
        })
    })()
} catch (e) {
    console.log(e)
}