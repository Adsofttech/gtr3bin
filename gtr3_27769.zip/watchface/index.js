﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'fon.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -454,
              hour_startY: 0,
              hour_array: ["0000.png","0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
              hour_zero: 1,
              hour_space: -454,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 142,
              minute_startY: 140,
              minute_array: ["m_000.png","m_001.png","m_002.png","m_003.png","m_004.png","m_005.png","m_006.png","m_007.png","m_008.png","m_009.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '0012.png',
              am_en_path: '0012.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '0012.png',
              pm_en_path: '0012.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 312,
              font_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'dat_010.png',
              unit_tc: 'dat_010.png',
              unit_en: 'dat_010.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 267,
              week_en: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              week_tc: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              week_sc: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 254,
              month_startY: 262,
              month_sc_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_tc_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_en_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 267,
              day_sc_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_tc_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_en_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 185,
              y: 98,
              src: '0015.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 101,
              src: '0035.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 217,
              y: 100,
              src: '0034.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 193,
              y: 100,
              src: '0033.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0013.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'fon.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: -454,
              hour_startY: 0,
              hour_array: ["0000.png","0001.png","0002.png","0003.png","0004.png","0005.png","0006.png","0007.png","0008.png","0009.png"],
              hour_zero: 1,
              hour_space: -454,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 142,
              minute_startY: 140,
              minute_array: ["m_000.png","m_001.png","m_002.png","m_003.png","m_004.png","m_005.png","m_006.png","m_007.png","m_008.png","m_009.png"],
              minute_zero: 1,
              minute_space: 5,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 0,
              am_y: 0,
              am_sc_path: '0012.png',
              am_en_path: '0012.png',
              pm_x: 0,
              pm_y: 0,
              pm_sc_path: '0012.png',
              pm_en_path: '0012.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 192,
              y: 312,
              font_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              padding: false,
              h_space: 2,
              unit_sc: '0029.png',
              unit_tc: '0029.png',
              unit_en: '0029.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 143,
              y: 267,
              week_en: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              week_tc: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              week_sc: ["wek_000.png","wek_001.png","wek_002.png","wek_003.png","wek_004.png","wek_005.png","wek_006.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 254,
              month_startY: 262,
              month_sc_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_tc_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_en_array: ["mon_000.png","mon_001.png","mon_002.png","mon_003.png","mon_004.png","mon_005.png","mon_006.png","mon_007.png","mon_008.png","mon_009.png","mon_010.png","mon_011.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 267,
              day_sc_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_tc_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_en_array: ["dat_000.png","dat_001.png","dat_002.png","dat_003.png","dat_004.png","dat_005.png","dat_006.png","dat_007.png","dat_008.png","dat_009.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  