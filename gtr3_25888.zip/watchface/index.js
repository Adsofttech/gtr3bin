﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_frame_animation_2 = ''
        let normal_frame_animation_3 = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_date_img_date_week_img = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_step_current_text_img = ''
        let idle_step_current_separator_img = ''
        let idle_distance_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_minute_separator_img = ''
        let idle_digital_clock_img_time_AmPm = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 106,
              y: 19,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "empty",
              anim_fps: 4,
              anim_size: 2,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_2 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 45,
              y: 330,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "Pic",
              anim_fps: 4,
              anim_size: 8,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_3 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 106,
              y: 23,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: "PokeBall",
              anim_fps: 4,
              anim_size: 18,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 69,
              week_en: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_tc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_sc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 88,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 143,
              day_startY: 87,
              day_sc_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_tc_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_en_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 396,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 145,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 406,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 79,
              // start_y: 361,
              // color: 0xFF00FF00,
              // lenght: 24,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 379,
              font_array: ["Batt_Black_01.png","Batt_Black_02.png","Batt_Black_03.png","Batt_Black_04.png","Batt_Black_05.png","Batt_Black_06.png","Batt_Black_07.png","Batt_Black_08.png","Batt_Black_09.png","Batt_Black_10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_Black_11.png',
              unit_tc: 'Batt_Black_11.png',
              unit_en: 'Batt_Black_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 28,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 376,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 344,
              src: 'icon_act.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 348,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_Black_14.png',
              unit_tc: 'Act_Black_14.png',
              unit_en: 'Act_Black_14.png',
              dot_image: 'Act_Black_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 16,
              y: 136,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_Black_12.png',
              unit_tc: 'Act_Black_12.png',
              unit_en: 'Act_Black_12.png',
              negative_image: 'Act_Black_11.png',
              invalid_image: 'Act_Black_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 75,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 183,
              hour_array: ["number_Black_01.png","number_Black_02.png","number_Black_03.png","number_Black_04.png","number_Black_05.png","number_Black_06.png","number_Black_07.png","number_Black_08.png","number_Black_09.png","number_Black_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 187,
              minute_array: ["number_Black_01.png","number_Black_02.png","number_Black_03.png","number_Black_04.png","number_Black_05.png","number_Black_06.png","number_Black_07.png","number_Black_08.png","number_Black_09.png","number_Black_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 23,
              second_startY: 273,
              second_array: ["number_small_Black_01.png","number_small_Black_02.png","number_small_Black_03.png","number_small_Black_04.png","number_small_Black_05.png","number_small_Black_06.png","number_small_Black_07.png","number_small_Black_08.png","number_small_Black_09.png","number_small_Black_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 286,
              y: 53,
              src: '24H.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 276,
              am_y: 51,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 276,
              pm_y: 51,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 197,
              y: 203,
              w: 79,
              h: 53,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 24,
              y: 273,
              w: 84,
              h: 34,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 105,
              y: 32,
              w: 35,
              h: 42,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 27,
              w: 45,
              h: 46,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 35,
              y: 106,
              w: 62,
              h: 50,
              src: '0_Empty.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 136,
              y: 338,
              w: 148,
              h: 32,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 397,
              w: 37,
              h: 36,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 206,
              y: 401,
              w: 122,
              h: 30,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 149,
              y: 371,
              w: 150,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main_AOD.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 163,
              y: 69,
              week_en: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_tc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              week_sc: ["week_day_01.png","week_day_02.png","week_day_03.png","week_day_04.png","week_day_05.png","week_day_06.png","week_day_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 205,
              month_startY: 88,
              month_sc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_tc_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_en_array: ["Month_01.png","Month_02.png","Month_03.png","Month_04.png","Month_05.png","Month_06.png","Month_07.png","Month_08.png","Month_09.png","Month_10.png","Month_11.png","Month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 143,
              day_startY: 87,
              day_sc_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_tc_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_en_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 115,
              y: 396,
              src: 'System_BT_OFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 411,
              y: 145,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 210,
              y: 406,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 79,
              // start_y: 361,
              // color: 0xFF00FF00,
              // lenght: 24,
              // line_width: 10,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 379,
              font_array: ["Batt_Black_01.png","Batt_Black_02.png","Batt_Black_03.png","Batt_Black_04.png","Batt_Black_05.png","Batt_Black_06.png","Batt_Black_07.png","Batt_Black_08.png","Batt_Black_09.png","Batt_Black_10.png"],
              padding: false,
              h_space: -1,
              unit_sc: 'Batt_Black_11.png',
              unit_tc: 'Batt_Black_11.png',
              unit_en: 'Batt_Black_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 114,
              y: 28,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 189,
              y: 376,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 134,
              y: 344,
              src: 'icon_act.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 166,
              y: 348,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_Black_14.png',
              unit_tc: 'Act_Black_14.png',
              unit_en: 'Act_Black_14.png',
              dot_image: 'Act_Black_13.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 16,
              y: 136,
              font_array: ["Act_Black_01.png","Act_Black_02.png","Act_Black_03.png","Act_Black_04.png","Act_Black_05.png","Act_Black_06.png","Act_Black_07.png","Act_Black_08.png","Act_Black_09.png","Act_Black_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act_Black_12.png',
              unit_tc: 'Act_Black_12.png',
              unit_en: 'Act_Black_12.png',
              negative_image: 'Act_Black_11.png',
              invalid_image: 'Act_Black_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 55,
              y: 75,
              image_array: ["Weather_icon_01.png","Weather_icon_02.png","Weather_icon_03.png","Weather_icon_04.png","Weather_icon_05.png","Weather_icon_06.png","Weather_icon_07.png","Weather_icon_08.png","Weather_icon_09.png","Weather_icon_10.png","Weather_icon_11.png","Weather_icon_12.png","Weather_icon_13.png","Weather_icon_14.png","Weather_icon_15.png","Weather_icon_16.png","Weather_icon_17.png","Weather_icon_18.png","Weather_icon_19.png","Weather_icon_20.png","Weather_icon_21.png","Weather_icon_22.png","Weather_icon_23.png","Weather_icon_24.png","Weather_icon_25.png","Weather_icon_26.png","Weather_icon_27.png","Weather_icon_28.png","Weather_icon_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 10,
              hour_startY: 183,
              hour_array: ["number_Black_01.png","number_Black_02.png","number_Black_03.png","number_Black_04.png","number_Black_05.png","number_Black_06.png","number_Black_07.png","number_Black_08.png","number_Black_09.png","number_Black_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 243,
              minute_startY: 187,
              minute_array: ["number_Black_01.png","number_Black_02.png","number_Black_03.png","number_Black_04.png","number_Black_05.png","number_Black_06.png","number_Black_07.png","number_Black_08.png","number_Black_09.png","number_Black_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 23,
              second_startY: 273,
              second_array: ["number_small_Black_01.png","number_small_Black_02.png","number_small_Black_03.png","number_small_Black_04.png","number_small_Black_05.png","number_small_Black_06.png","number_small_Black_07.png","number_small_Black_08.png","number_small_Black_09.png","number_small_Black_10.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 286,
              y: 53,
              src: '24H.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 276,
              am_y: 51,
              am_sc_path: 'Times_AM.png',
              am_en_path: 'Times_AM.png',
              pm_x: 276,
              pm_y: 51,
              pm_sc_path: 'Times_PM.png',
              pm_en_path: 'Times_PM.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 79;
                  let start_y_normal_battery = 361;
                  let lenght_ls_normal_battery = 24;
                  let line_width_ls_normal_battery = 10;
                  let color_ls_normal_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 79;
                  let start_y_idle_battery = 361;
                  let lenght_ls_idle_battery = 24;
                  let line_width_ls_idle_battery = 10;
                  let color_ls_idle_battery = 0xFF00FF00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_2.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);
                normal_frame_animation_3.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  