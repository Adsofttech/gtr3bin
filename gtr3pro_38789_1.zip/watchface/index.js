﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 125,
              hour_startY: 30,
              hour_array: ["wh00.png","wh01.png","wh02.png","wh03.png","wh04.png","wh05.png","wh06.png","wh07.png","wh08.png","wh09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'whdd.png',
              hour_unit_tc: 'whdd.png',
              hour_unit_en: 'whdd.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 207,
              minute_startY: 30,
              minute_array: ["wh00.png","wh01.png","wh02.png","wh03.png","wh04.png","wh05.png","wh06.png","wh07.png","wh08.png","wh09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_unit_sc: 'whdd.png',
              minute_unit_tc: 'whdd.png',
              minute_unit_en: 'whdd.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 289,
              second_startY: 30,
              second_array: ["wh00.png","wh01.png","wh02.png","wh03.png","wh04.png","wh05.png","wh06.png","wh07.png","wh08.png","wh09.png"],
              second_zero: 1,
              second_space: -5,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 125,
              hour_startY: 30,
              hour_array: ["wh00.png","wh01.png","wh02.png","wh03.png","wh04.png","wh05.png","wh06.png","wh07.png","wh08.png","wh09.png"],
              hour_zero: 1,
              hour_space: -5,
              hour_angle: 0,
              hour_unit_sc: 'whdd.png',
              hour_unit_tc: 'whdd.png',
              hour_unit_en: 'whdd.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 207,
              minute_startY: 30,
              minute_array: ["wh00.png","wh01.png","wh02.png","wh03.png","wh04.png","wh05.png","wh06.png","wh07.png","wh08.png","wh09.png"],
              minute_zero: 1,
              minute_space: -5,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}