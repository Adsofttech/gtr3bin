﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_pai_icon_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_sun_image_progress_img_level = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_moon_image_progress_img_level = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_progress = ''
        let normal_date_img_date_week_img = ''
        let idle_background_bg = ''
        let idle_digital_clock_img_time = ''
        let idle_image_img = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

        
        let checkBT = true				// включен/отключен контроль потери связи
        
        let switch_checkBT;
        
        
        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
            const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
            let stopVibro_Timer = null;
        
        function vibro(scene = 25) {
          let stopDelay = 50;
          vibrate.stop();
          vibrate.scene = scene;
          if(scene < 23 || scene > 25) stopDelay = 1220;
          vibrate.start();
          stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
            }		
    
        function stopVibro(){
          vibrate.stop();
          timer.stopTimer(stopVibro_Timer);
        }
    
        
    //--------------------- контроль потери связи  ---------------------
        function checkConnection(check = true) {
          hmBle.removeListener;
          if (check){
            hmBle.addListener(function (status) {
              if(!status && checkBT) {
                hmUI.showToast({text: "Нет связи!!!"});
                vibro(9);
              }
              if(status && checkBT) {
                hmUI.showToast({text: "Снова на связи!"});
                vibro(0);
              }
            })			
          } 
        }
    
    //----------------- контроль потери связи: включение/отключение  ------------------
        function toggleСheckConnection() {
          checkBT = !checkBT;
          hmFS.SysProSetBool('nsw_checkBT', checkBT);
          vibro();
          checkConnection(checkBT);
          switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png');
          hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
        }
    
    
        function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
          
          if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
            checkBT = false;
            hmFS.SysProSetBool('nsw_checkBT', checkBT);
          } else {
            checkBT = hmFS.SysProGetBool('nsw_checkBT');
          }
         
     
        }

       
        // смена безеля
       let bezel_img = ''
       let btn_bezel = ''
       let bezel_num = 1
       let bezel_all = 10

       function click_Bezel() {
           if(bezel_num>=bezel_all) {bezel_num=1;}
           else { bezel_num=bezel_num+1;}
           hmUI.showToast({text: "<Цвет> " + parseInt(bezel_num) });
           normal_background_bg_img.setProperty(hmUI.prop.SRC, "Bezel_" + parseInt(bezel_num) + ".png");
       }
                //------------------------ автозамена иконок погоды -----------------------------------
                
                let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
                
                let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
                let weatherData = weather.getForecastWeather();
                let forecastData = weatherData.forecastData;
                let sunData = weatherData.tideData;
                let today = '';
                let sunriseMins = '';
                let sunsetMins = '';
                let sunriseMins_def = 8 * 60;			// время восхода
                let sunsetMins_def = 20 * 60;			// и заката по умолчанию
                
                let curMins = '';
                
                let isDayIcons = true;
                let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
                
                function autoToggleWeatherIcons() {
                
                weatherData = weather.getForecastWeather();
                sunData = weatherData.tideData;
                if (sunData.count > 0){
                today = sunData.data[0];
                sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                sunriseMins = sunriseMins_def;
                sunsetMins = sunsetMins_def;
                }
                
                curMins = curTime.hour * 60 + curTime.minute;
                let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
                
                if(isDayNow){
                  normal_pai_icon_img.setProperty(hmUI.prop.SRC, "z_3.png");
                if(!isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
                  }
                  isDayIcons = true;
                }
                } else {
                  normal_pai_icon_img.setProperty(hmUI.prop.SRC, "z_1.png");
                if(isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
                  }
                  isDayIcons = false;
                }
                }
                }
                
                //------------------------ автозамена иконок погоды ----------------------------------- \\		

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 76,
              month_startY: 212,
              month_sc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_tc_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_en_array: ["mes_1.png","mes_2.png","mes_3.png","mes_4.png","mes_5.png","mes_6.png","mes_7.png","mes_8.png","mes_9.png","mes_10.png","mes_11.png","mes_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 20,
              day_startY: 212,
              day_sc_array: ["blnum_1.png","blnum_2.png","blnum_3.png","blnum_4.png","blnum_5.png","blnum_6.png","blnum_7.png","blnum_8.png","blnum_9.png","blnum_10.png"],
              day_tc_array: ["blnum_1.png","blnum_2.png","blnum_3.png","blnum_4.png","blnum_5.png","blnum_6.png","blnum_7.png","blnum_8.png","blnum_9.png","blnum_10.png"],
              day_en_array: ["blnum_1.png","blnum_2.png","blnum_3.png","blnum_4.png","blnum_5.png","blnum_6.png","blnum_7.png","blnum_8.png","blnum_9.png","blnum_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 19,
              hour_startY: 232,
              hour_array: ["cnum_1.png","cnum_2.png","cnum_3.png","cnum_4.png","cnum_5.png","cnum_6.png","cnum_7.png","cnum_8.png","cnum_9.png","cnum_10.png"],
              hour_zero: 1,
              hour_space: -6,
              hour_angle: 0,
              hour_unit_sc: 'cnum_11.png',
              hour_unit_tc: 'cnum_11.png',
              hour_unit_en: 'cnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["cnum_1.png","cnum_2.png","cnum_3.png","cnum_4.png","cnum_5.png","cnum_6.png","cnum_7.png","cnum_8.png","cnum_9.png","cnum_10.png"],
              minute_zero: 1,
              minute_space: -6,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              second_startX: 317,
              second_startY: 248,
              second_array: ["secn_1.png","secn_2.png","secn_3.png","secn_4.png","secn_5.png","secn_6.png","secn_7.png","secn_8.png","secn_9.png","secn_10.png"],
              second_zero: 1,
              second_space: 2,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 133,
              y: 379,
              src: 'bt_off.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'bpointer.png',
              center_x: 239,
              center_y: 390,
              x: 47,
              y: 37,
              start_angle: -5,
              end_angle: 295,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 367,
              font_array: ["bnum_1.png","bnum_2.png","bnum_3.png","bnum_4.png","bnum_5.png","bnum_6.png","bnum_7.png","bnum_8.png","bnum_9.png","bnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'z_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 368,
              y: 203,
              src: 'vs2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 205,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              dot_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 368,
              y: 203,
              image_array: ["vs1.png","vs2.png"],
              image_length: 2,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 74,
              y: 332,
              w: 115,
              h: 30,
              text_size: 20,
              char_space: 0,
              line_space: 0,
              color: 0xFF000000,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 67,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_14.png',
              unit_tc: 'num_14.png',
              unit_en: 'num_14.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 297,
              y: 60,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 175,
              y: 100,
              image_array: ["112.png","113.png","114.png","115.png","116.png","117.png","118.png","119.png","120.png","121.png","122.png","123.png","124.png","125.png","126.png","127.png","128.png","129.png","130.png","131.png","132.png","133.png","135.png","136.png","137.png","138.png","139.png","140.png","141.png","142.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 312,
              y: 160,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 0,
              y: 0,
              image_array: ["zona_1.png","zona_2.png","zona_3.png","zona_4.png","zona_5.png","zona_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 245,
              y: 112,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_progress = hmUI.createWidget(hmUI.widget.IMG_PROGRESS, {
              x: [0,0,0,0,0,0,0,0,0,0],
              y: [0,0,0,0,0,0,0,0,0,0],
              image_array: ["step_1.png","step_2.png","step_3.png","step_4.png","step_5.png","step_6.png","step_7.png","step_8.png","step_9.png","step_10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 0,
              y: 0,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 338,
              y: 338,
              text: '',
              w: 100,
              h: 100,
              normal_src: '',
              press_src: '',
              click_func: () => {
               click_Bezel();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

       	// низкий заряд
         hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 190,
          y: 340,
          w: 100,
          h: 100,
          text: '',
          normal_src: '',
          press_src: '',
          click_func: () => {
          hmApp.startApp({ url: 'LowBatteryScreen', native: true });
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
      });			

            // календарь
            hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 20,
              y: 164,
              w: 100,
              h: 80,
              text: '',
              normal_src: '',
              press_src: '',
              click_func: () => {
              hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
             });	
      
      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 412,
        y: 255,
        w: 67,
        h: 80,
        src: checkBT ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });
            

            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 94,
              hour_startY: 185,
              hour_array: ["aodcnum_1.png","aodcnum_2.png","aodcnum_3.png","aodcnum_4.png","aodcnum_5.png","aodcnum_6.png","aodcnum_7.png","aodcnum_8.png","aodcnum_9.png","aodcnum_10.png"],
              hour_zero: 1,
              hour_space: -2,
              hour_angle: 0,
              hour_unit_sc: 'aodcnum_11.png',
              hour_unit_tc: 'aodcnum_11.png',
              hour_unit_en: 'aodcnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["aodcnum_1.png","aodcnum_2.png","aodcnum_3.png","aodcnum_4.png","aodcnum_5.png","aodcnum_6.png","aodcnum_7.png","aodcnum_8.png","aodcnum_9.png","aodcnum_10.png"],
              minute_zero: 1,
              minute_space: -2,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 241,
              y: 196,
              w: 176,
              h: 47,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 214,
              y: 41,
              w: 132,
              h: 56,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 268,
              y: 151,
              w: 153,
              h: 43,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 246,
              y: 100,
              w: 144,
              h: 47,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

              console.log('Weather city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                autoToggleWeatherIcons();
                checkConnection(checkBT);
                stopVibro();
              }),
              pause_call: (function () {
                stopVibro();

              }),

            });

                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}