﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_pai_icon_img = ''
        let normal_image_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_image_img = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''

       // let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
        
       let switch_checkBT;
      // let switch_hourlyVibro;
       
       const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider_on.png' : 'slider_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   

   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
    
       }

        // смена безеля
        //let bezel_img = ''
        let btn_bezel = ''
        let bezel_num = 1
        let bezel_all = 10
     
        function click_Bezel() {
            if(bezel_num>=bezel_all) {bezel_num=1;}
            else { bezel_num=bezel_num+1;}
            hmUI.showToast({text: "<Цвет фона> " + parseInt(bezel_num) });
            normal_background_bg_img.setProperty(hmUI.prop.SRC, "bgl_" + parseInt(bezel_num) + ".png");
            //normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(bezel_num) + ".png");
        }    

        // смена маски
        //let bot_circle_btn = ''
        //let mask_img = ''
         let btn_mask = ''
         let mask_num = 1
         let mask_all = 10
             
        function click_mask() {
          if(mask_num>=mask_all) {mask_num=1;}
           else { mask_num=mask_num+1;}
            hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
            normal_image_img.setProperty(hmUI.prop.SRC, "mask_" + parseInt(mask_num) + ".png");
        }
        

                //------------------------ автозамена иконок погоды -----------------------------------
                
                let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
                
                let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
                let weatherData = weather.getForecastWeather();
                let forecastData = weatherData.forecastData;
                let sunData = weatherData.tideData;
                let today = '';
                let sunriseMins = '';
                let sunsetMins = '';
                let sunriseMins_def = 8 * 60;			// время восхода
                let sunsetMins_def = 20 * 60;			// и заката по умолчанию
                
                let curMins = '';
                
                let isDayIcons = true;
                let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
                
                function autoToggleWeatherIcons() {
                
                weatherData = weather.getForecastWeather();
                sunData = weatherData.tideData;
                if (sunData.count > 0){
                today = sunData.data[0];
                sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                sunriseMins = sunriseMins_def;
                sunsetMins = sunsetMins_def;
                }
                
                curMins = curTime.hour * 60 + curTime.minute;
                let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
                
                if(isDayNow){
                if(!isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
                  }
                  isDayIcons = true;
                }
                } else {
                if(isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
                  }
                  isDayIcons = false;
                }
                }
                }
                
                //------------------------ автозамена иконок погоды ----------------------------------- \\		

                let hands_smoth_btn = ''
                let sec_smoth_state = 0 // 0 - тип 1, 1 - тип 2
                let sec_smoth_state_txt = ''
          
                function click_bot_ssmoth_Switcher() {
          
                  let bot_sec_state_total = 9;
          
                  sec_smoth_state = (sec_smoth_state + 1) % bot_sec_state_total;
          
                  switch (sec_smoth_state) {
          
                      case 0:
                        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                          hour_path: 'hour_1.png',
                          hour_centerX: 227,
                          hour_centerY: 227,
                          hour_posX: 227,
                          hour_posY: 227,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                        });
            
                        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                          minute_path: 'min_1.png',
                          minute_centerX: 227,
                          minute_centerY: 227,
                          minute_posX: 227,
                          minute_posY: 227,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                        });
        
            
                        //normal_battery_pointer_progress_img_pointer.setProperty(hmUI.prop.SRC, "pointer_1.png");
                        //normal_week_pointer_progress_date_pointer.setProperty(hmUI.prop.SRC, "dnp_1.png");
                          //normal_analog_clock_pro_second_pointer_img .setProperty(hmUI.prop.SRC, "s_1.png");
                
                        sec_smoth_state_txt = 'Стрелка 1';
                          break;
          
                      case 1:
          
                        normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                          hour_path: 'hour_2.png',
                          hour_centerX: 227,
                          hour_centerY: 227,
                          hour_posX: 227,
                          hour_posY: 227,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                        });
            
                        normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                          minute_path: 'min_2.png',
                          minute_centerX: 227,
                          minute_centerY: 227,
                          minute_posX: 227,
                          minute_posY: 227,
                          show_level: hmUI.show_level.ONLY_NORMAL,
                        });
        
                        sec_smoth_state_txt = 'Стрелка 2';
                          break;
 
                          case 2:
          
                          normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                            hour_path: 'hour_3.png',
                            hour_centerX: 227,
                            hour_centerY: 227,
                            hour_posX: 227,
                            hour_posY: 227,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                          });
              
                          normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                            minute_path: 'min_3.png',
                            minute_centerX: 227,
                            minute_centerY: 227,
                            minute_posX: 227,
                            minute_posY: 227,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                          });
          
                          sec_smoth_state_txt = 'Стрелка 3';
                            break;

                            case 3:
          
                            normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                              hour_path: 'hour_4.png',
                              hour_centerX: 227,
                              hour_centerY: 227,
                              hour_posX: 227,
                              hour_posY: 227,
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
                
                            normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                              minute_path: 'min_4.png',
                              minute_centerX: 227,
                              minute_centerY: 227,
                              minute_posX: 227,
                              minute_posY: 227,
                              show_level: hmUI.show_level.ONLY_NORMAL,
                            });
            
                            sec_smoth_state_txt = 'Стрелка 4';
                              break;

                              case 4:
          
                              normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                                hour_path: 'hour_5.png',
                                hour_centerX: 227,
                                hour_centerY: 227,
                                hour_posX: 227,
                                hour_posY: 227,
                                show_level: hmUI.show_level.ONLY_NORMAL,
                              });
                  
                              normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                                minute_path: 'min_5.png',
                                minute_centerX: 227,
                                minute_centerY: 227,
                                minute_posX: 227,
                                minute_posY: 227,
                                show_level: hmUI.show_level.ONLY_NORMAL,
                              });
              
                              sec_smoth_state_txt = 'Стрелка 5';
                                break;
 
                                case 5:
          
                                normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                                  hour_path: 'hour_6.png',
                                  hour_centerX: 227,
                                  hour_centerY: 227,
                                  hour_posX: 227,
                                  hour_posY: 227,
                                  show_level: hmUI.show_level.ONLY_NORMAL,
                                });
                    
                                normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                                  minute_path: 'min_6.png',
                                  minute_centerX: 227,
                                  minute_centerY: 227,
                                  minute_posX: 227,
                                  minute_posY: 227,
                                  show_level: hmUI.show_level.ONLY_NORMAL,
                                });
                
                                sec_smoth_state_txt = 'Стрелка 6';
                                  break;

                                  case 6:
          
                                  normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                                    hour_path: 'hour_7.png',
                                    hour_centerX: 227,
                                    hour_centerY: 227,
                                    hour_posX: 227,
                                    hour_posY: 227,
                                    show_level: hmUI.show_level.ONLY_NORMAL,
                                  });
                      
                                  normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                                    minute_path: 'min_7.png',
                                    minute_centerX: 227,
                                    minute_centerY: 227,
                                    minute_posX: 227,
                                    minute_posY: 227,
                                    show_level: hmUI.show_level.ONLY_NORMAL,
                                  });
                  
                                  sec_smoth_state_txt = 'Стрелка 7';
                                    break;

                                    case 7:
          
                                    normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                                      hour_path: 'hour_8.png',
                                      hour_centerX: 227,
                                      hour_centerY: 227,
                                      hour_posX: 227,
                                      hour_posY: 227,
                                      show_level: hmUI.show_level.ONLY_NORMAL,
                                    });
                        
                                    normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                                      minute_path: 'min_8.png',
                                      minute_centerX: 227,
                                      minute_centerY: 227,
                                      minute_posX: 227,
                                      minute_posY: 227,
                                      show_level: hmUI.show_level.ONLY_NORMAL,
                                    });
                    
                                    sec_smoth_state_txt = 'Стрелка 8';
                                      break;

                                      case 8:
          
                                      normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, {
                                        hour_path: 'hour_9.png',
                                        hour_centerX: 227,
                                        hour_centerY: 227,
                                        hour_posX: 227,
                                        hour_posY: 227,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                      });
                          
                                      normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, {
                                        minute_path: 'min_9.png',
                                        minute_centerX: 227,
                                        minute_centerY: 227,
                                        minute_posX: 227,
                                        minute_posY: 227,
                                        show_level: hmUI.show_level.ONLY_NORMAL,
                                      });
                      
                                      sec_smoth_state_txt = 'Стрелка 9';
                                        break;
              
                      default:
                          break;
                  }
          
                  hmUI.showToast({ text: sec_smoth_state_txt });
                }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bgl_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 303,
              y: 229,
              src: '0074.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 301,
              y: 197,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 325,
              day_startY: 346,
              day_sc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_tc_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_en_array: ["dnum_1.png","dnum_2.png","dnum_3.png","dnum_4.png","dnum_5.png","dnum_6.png","dnum_7.png","dnum_8.png","dnum_9.png","dnum_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 329,
              y: 314,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 328,
              y: 132,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'num_11.png',
              unit_tc: 'num_11.png',
              unit_en: 'num_11.png',
              negative_image: 'num_12.png',
              invalid_image: 'num_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 339,
              y: 89,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 227,
              center_y: 327,
              x: 61,
              y: 61,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 321,
              y: 283,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 213,
              y: 87,
              image_array: ["zona_1.png","zona_2.png","zona_3.png","zona_4.png","zona_5.png","zona_6.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 87,
              src: 'picon_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 227,
              center_y: 127,
              x: 61,
              y: 61,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 129,
              y: 195,
              image_array: ["bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_2.png',
              center_x: 121,
              center_y: 227,
              x: 61,
              y: 61,
              start_angle: 45,
              end_angle: 360,
              cover_path: 'point_p.png',
              cover_x: 0,
              cover_y: 0,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 331,
              hour_startY: 174,
              hour_array: ["tnum_1.png","tnum_2.png","tnum_3.png","tnum_4.png","tnum_5.png","tnum_6.png","tnum_7.png","tnum_8.png","tnum_9.png","tnum_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 331,
              minute_startY: 226,
              minute_array: ["tnum_1.png","tnum_2.png","tnum_3.png","tnum_4.png","tnum_5.png","tnum_6.png","tnum_7.png","tnum_8.png","tnum_9.png","tnum_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 55,
              second_posY: 227,
              second_cover_path: 'sec_p.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

    			// кнопка включения/отключения котроля потери связи
          switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
            x: 69,
            y: 312,
            w: 76,
            h: 76,
            src: checkBT ? 'slider_on.png' : 'slider_off.png',
            show_level: hmUI.show_level.ONLY_NORMAL,
           });
           switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
             toggleСheckConnection();
           });
 
           btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
             x: 180,
             y: 378,
             text: '',
             w: 95,
             h: 76,
             normal_src: '',
             press_src: '',
             click_func: () => {
                 click_mask();
                 vibro(25);
             },
             show_level: hmUI.show_level.ONLY_NORMAL,
           });
           btn_mask.setProperty(hmUI.prop.VISIBLE, true);
 
 
          // низкий заряд
         hmUI.createWidget(hmUI.widget.BUTTON, {
           x: 71,
           y: 180,
           w: 95,
           h: 95,
           text: '',
           normal_src: '',
           press_src: '',
           click_func: () => {
           hmApp.startApp({ url: 'LowBatteryScreen', native: true });
           },
           show_level: hmUI.show_level.ONLY_NORMAL,
       });				

       // календарь
       hmUI.createWidget(hmUI.widget.BUTTON, {
         x: 305,
         y: 308,
         w: 95,
         h: 95,
         text: '',
         normal_src: '',
         press_src: '',
         click_func: () => {
         hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
         },
         show_level: hmUI.show_level.ONLY_NORMAL,
        });	

        btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 322,
          y: 180,
          text: '',
          w: 95,
          h: 95,
          normal_src: '',
          press_src: '',
          click_func: () => {
            click_Bezel();
              vibro(25);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

        hands_smoth_btn = hmUI.createWidget(hmUI.widget.BUTTON, {
          x: 180,
          y: 180,
          text: '',
          w: 95,
          h: 95,
          normal_src: '',
          press_src: '',
          click_func: () => {
            click_bot_ssmoth_Switcher();
              vibro(25);
          },
          show_level: hmUI.show_level.ONLY_NORMAL,
        });
        hands_smoth_btn.setProperty(hmUI.prop.VISIBLE, true);

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_2.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 227,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_2.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 227,
              minute_posY: 227,
              minute_cover_path: 'sec_p.png',
              minute_cover_x: 0,
              minute_cover_y: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 306,
              y: 75,
              w: 95,
              h: 95,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 82,
              w: 95,
              h: 95,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 180,
              y: 278,
              w: 95,
              h: 95,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                stopVibro();
                checkConnection(checkBT);
                autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),
            });
            setEveryHourVibro();

                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}