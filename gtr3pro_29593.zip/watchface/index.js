﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_battery_icon_img = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_heart_rate_icon_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_calorie_icon_img = ''
        let normal_calorie_current_text_img = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_system_disconnect_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_icon_img = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fundo.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 119,
              y: 142,
              image_array: ["b000.png","b001.png","b002.png","b003.png","b004.png","b005.png","b006.png","b007.png","b008.png"],
              image_length: 9,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 191,
              y: 131,
              src: 'pow001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 213,
              y: 135,
              font_array: ["46.png","47.png","48.png","49.png","50.png","51.png","52.png","53.png","54.png","55.png"],
              padding: false,
              h_space: 0,
              unit_sc: '106.png',
              unit_tc: '106.png',
              unit_en: '106.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 205,
              y: 84,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 1,
              unit_sc: '105.png',
              unit_tc: '105.png',
              unit_en: '105.png',
              negative_image: '103.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 200,
              y: 8,
              image_array: ["w44.png","w45.png","w46.png","w47.png","w48.png","w49.png","w50.png","w51.png","w52.png","w53.png","w54.png","w55.png","w56.png","w57.png","w58.png","w59.png","w60.png","w61.png","w62.png","w63.png","w64.png","w65.png","w66.png","w67.png","w68.png","w69.png","w70.png","w71.png","w72.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 322,
              y: 347,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              dot_image: '73.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 348,
              y: 369,
              src: 'dist001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 351,
              y: 61,
              src: 'bat001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 330,
              y: 112,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 90,
              y: 61,
              src: 'cal001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 71,
              y: 112,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 369,
              src: 'pas001.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 56,
              y: 347,
              font_array: ["56.png","57.png","58.png","59.png","60.png","61.png","62.png","63.png","64.png","65.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 210,
              y: 411,
              week_en: ["s70.png","s71.png","s72.png","s73.png","s74.png","s75.png","s76.png"],
              week_tc: ["s70.png","s71.png","s72.png","s73.png","s74.png","s75.png","s76.png"],
              week_sc: ["s70.png","s71.png","s72.png","s73.png","s74.png","s75.png","s76.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 206,
              day_startY: 365,
              day_sc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_tc_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_en_array: ["29.png","30.png","31.png","32.png","33.png","34.png","35.png","36.png","37.png","38.png"],
              day_zero: 0,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 222,
              src: 'bl001.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 193,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 3,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 264,
              minute_startY: 193,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 3,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'p02.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 10,
              hour_posY: 145,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'p03.png',
              minute_centerX: 241,
              minute_centerY: 239,
              minute_posX: 14,
              minute_posY: 208,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'p04.png',
              second_centerX: 240,
              second_centerY: 239,
              second_posX: 7,
              second_posY: 218,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'fundo2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 232,
              y: 219,
              src: 'aod_0012.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 62,
              hour_startY: 193,
              hour_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.LEFT,

              minute_startX: 264,
              minute_startY: 193,
              minute_array: ["2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png","10.png","11.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  