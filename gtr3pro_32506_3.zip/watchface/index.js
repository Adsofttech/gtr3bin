﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let editBg = ''
        let normal_battery_circle_scale = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_weather_image_progress_img_level = ''
        let normal_uvi_text_text_img = ''
        let normal_pai_day_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_week_pointer_progress_date_pointer = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_step_current_text_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let idle_background_bg_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_weather_image_progress_img_level = ''
        let idle_uvi_text_text_img = ''
        let idle_pai_day_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_week_pointer_progress_date_pointer = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let editableTimePointers = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            editBg = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_BG, {
              edit_id: 1002,
              x: 0,
              y: 0,
              // w: 480,
              // h: 480,
              // AOD_show: False,
              bg_config: [
                { id: 1, preview: 'preview_bg_0.png', path: 'bg_0.png' },
                { id: 2, preview: 'preview_bg_1.png', path: 'bg_1.png' },
                { id: 3, preview: 'preview_bg_2.png', path: 'bg_2.png' },
                { id: 4, preview: 'preview_bg_3.png', path: 'bg_3.png' },
                { id: 5, preview: 'preview_bg_4.png', path: 'bg_4.png' },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_bg: 'mask.png',
              tips_x: 167,
              tips_y: 47,
              show_level: hmUI.show_level.ONLY_NORMAL | hmUI.show_level.ONLY_EDIT,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 98,
              // center_y: 240,
              // start_angle: 2,
              // end_angle: 360,
              // radius: 54,
              // line_width: 4,
              // color: 0xFF3B3B3B,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 97,
              center_y: 240,
              x: 9,
              y: 57,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 180,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 396,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 49,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 125,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 293,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 314,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 314,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 382,
              center_y: 240,
              posX: 9,
              posY: 57,
              start_angle: -80,
              end_angle: 219,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 363,
              year_startY: 256,
              year_sc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_tc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_en_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 348,
              month_startY: 217,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 298,
              day_startY: 222,
              day_sc_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_tc_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_en_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 230,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 132,
              am_y: 90,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 132,
              pm_y: 90,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 106,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'pointer_2.png',
              hour_unit_tc: 'pointer_2.png',
              hour_unit_en: 'pointer_2.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 106,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 89,
              second_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 98,
              // center_y: 240,
              // start_angle: 2,
              // end_angle: 360,
              // radius: 54,
              // line_width: 4,
              // color: 0xFF3B3B3B,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 97,
              center_y: 240,
              x: 9,
              y: 57,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 209,
              y: 180,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'percent.png',
              unit_tc: 'percent.png',
              unit_en: 'percent.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 172,
              y: 396,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km.png',
              unit_tc: 'km.png',
              unit_en: 'km.png',
              imperial_unit_sc: 'ml.png',
              imperial_unit_tc: 'ml.png',
              imperial_unit_en: 'ml.png',
              dot_image: 'pointer_3.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 222,
              y: 49,
              image_array: ["Moon_1.png","Moon_2.png","Moon_3.png","Moon_4.png","Moon_5.png","Moon_6.png","Moon_7.png","Moon_8.png","Moon_9.png","Moon_10.png","Moon_11.png","Moon_12.png","Moon_13.png","Moon_14.png","Moon_15.png","Moon_16.png","Moon_17.png","Moon_18.png","Moon_19.png","Moon_20.png","Moon_21.png","Moon_22.png","Moon_23.png","Moon_24.png","Moon_25.png","Moon_26.png","Moon_27.png","Moon_28.png","Moon_29.png","Moon_30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 57,
              y: 125,
              image_array: ["weather_1.png","weather_2.png","weather_3.png","weather_4.png","weather_5.png","weather_6.png","weather_7.png","weather_8.png","weather_9.png","weather_10.png","weather_11.png","weather_12.png","weather_13.png","weather_14.png","weather_15.png","weather_16.png","weather_17.png","weather_18.png","weather_19.png","weather_20.png","weather_21.png","weather_22.png","weather_23.png","weather_24.png","weather_25.png","weather_26.png","weather_27.png","weather_28.png","weather_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_uvi_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 225,
              y: 293,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 0,
              invalid_image: 'dot.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.UVI,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_day_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 282,
              y: 314,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.PAI_DAILY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 154,
              y: 314,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'dot.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_week_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'pointer_1.png',
              center_x: 382,
              center_y: 240,
              posX: 9,
              posY: 57,
              start_angle: -80,
              end_angle: 219,
              type: hmUI.date.WEEK,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 363,
              year_startY: 256,
              year_sc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_tc_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_en_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 348,
              month_startY: 217,
              month_sc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_1.png","month_2.png","month_3.png","month_4.png","month_5.png","month_6.png","month_7.png","month_8.png","month_9.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 298,
              day_startY: 222,
              day_sc_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_tc_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_en_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              day_zero: 0,
              day_space: 1,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 57,
              y: 230,
              font_array: ["font_act_0.png","font_act_1.png","font_act_2.png","font_act_3.png","font_act_4.png","font_act_5.png","font_act_6.png","font_act_7.png","font_act_8.png","font_act_9.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 132,
              am_y: 90,
              am_sc_path: 'am.png',
              am_en_path: 'am.png',
              pm_x: 132,
              pm_y: 90,
              pm_sc_path: 'pm.png',
              pm_en_path: 'pm.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 160,
              hour_startY: 106,
              hour_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_unit_sc: 'pointer_2.png',
              hour_unit_tc: 'pointer_2.png',
              hour_unit_en: 'pointer_2.png',
              hour_align: hmUI.align.LEFT,

              minute_startX: 256,
              minute_startY: 106,
              minute_array: ["font_time_0.png","font_time_1.png","font_time_2.png","font_time_3.png","font_time_4.png","font_time_5.png","font_time_6.png","font_time_7.png","font_time_8.png","font_time_9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 321,
              second_startY: 89,
              second_array: ["font_small_0.png","font_small_1.png","font_small_2.png","font_small_3.png","font_small_4.png","font_small_5.png","font_small_6.png","font_small_7.png","font_small_8.png","font_small_9.png"],
              second_zero: 1,
              second_space: 1,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            const pointerEdit = hmUI.createWidget(hmUI.widget.WATCHFACE_EDIT_POINTER, {
              edit_id: 1003,
              x: 0,
              y: 0,
              config: [
                {
                  id: 1,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 227,
                    path: 'second_0.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 159,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 210,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_1_preview.png',
                },
                {
                  id: 2,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 227,
                    path: 'second_1.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 159,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 210,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_2_preview.png',
                },
                {
                  id: 3,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 227,
                    path: 'second_2.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 159,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 210,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_3_preview.png',
                },
                {
                  id: 4,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 227,
                    path: 'second_3.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 159,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 210,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_4_preview.png',
                },
                {
                  id: 5,
                  second: {
                    centerX: 240,
                    centerY: 240,
                    posX: 12,
                    posY: 227,
                    path: 'second_4.png',
                  },
                  hour: {
                    centerX: 240,
                    centerY: 240,
                    posX: 23,
                    posY: 159,
                    path: 'hour.png',
                  },
                  minute: {
                    centerX: 240,
                    centerY: 240,
                    posX: 22,
                    posY: 210,
                    path: 'minute.png',
                  },
                  preview: 'pointer_edit_5_preview.png',
                },
              ],
              count: 5,
              default_id: 1,
              fg: '.png',
              tips_x: 219,
              tips_y: 164,
              tips_bg: 'mask_1.png',
            });
            const pointerProp = pointerEdit.getProperty(hmUI.prop.CURRENT_CONFIG, true);
            editableTimePointers = hmUI.createWidget(hmUI.widget.TIME_POINTER, pointerProp);

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 42,
              y: 306,
              w: 60,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 158,
              y: 373,
              w: 165,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 112,
              w: 60,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 284,
              y: 202,
              w: 60,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 166,
              y: 105,
              w: 165,
              h: 44,
              src: 'dot.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 211,
              y: 37,
              w: 60,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 43,
              y: 111,
              w: 60,
              h: 61,
              src: 'dot.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 296,
              y: 312,
              w: 60,
              h: 50,
              src: 'dot.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 127,
              y: 312,
              w: 60,
              h: 50,
              src: 'dot.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 377,
              y: 308,
              w: 60,
              h: 60,
              src: 'dot.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -88;
                  let end_angle_normal_battery = 270;
                  let center_x_normal_battery = 98;
                  let center_y_normal_battery = 240;
                  let radius_normal_battery = 54;
                  let line_width_cs_normal_battery = 4;
                  let color_cs_normal_battery = 0xFF3B3B3B;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -88;
                  let end_angle_idle_battery = 270;
                  let center_x_idle_battery = 98;
                  let center_y_idle_battery = 240;
                  let radius_idle_battery = 54;
                  let line_width_cs_idle_battery = 4;
                  let color_cs_idle_battery = 0xFF3B3B3B;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
