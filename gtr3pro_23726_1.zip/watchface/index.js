﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_current_separator_img = ''
        let normal_distance_text_text_img = ''
        let normal_distance_text_separator_img = ''
        let normal_step_current_text_img = ''
        let normal_step_current_separator_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_text_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_system_lock_img = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let idle_system_lock_img = ''
        let idle_system_dnd_img = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_text_separator_img = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        let idle_date_img_date_day = ''
        let idle_date_day_separator_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bck-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 310,
              y: 345,
              font_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              padding: true,
              h_space: 0,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 281,
              y: 344,
              src: 'cal-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 311,
              font_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              padding: false,
              h_space: 0,
              dot_image: 'dis-0001.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 282,
              y: 313,
              src: 'dis-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 103,
              y: 324,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: -1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 63,
              y: 324,
              src: 'st-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 308,
              y: 101,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 324,
              y: 61,
              src: 'cuo-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 73,
              y: 100,
              font_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              padding: true,
              h_space: -2,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 128,
              y: 58,
              src: 'bat-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 242,
              y: 383,
              src: 'lu-0000.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 196,
              y: 382,
              src: 'dn-0000.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 150,
              y: 382,
              src: 'bl-0000.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 288,
              y: 384,
              src: 'sv-0000.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 84,
              y: 166,
              week_en: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              week_tc: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              week_sc: ["gio-0001.png","gio-0002.png","gio-0003.png","gio-0004.png","gio-0005.png","gio-0006.png","gio-0007.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 191,
              year_startY: 102,
              year_sc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_tc_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_en_array: ["n-0000.png","n-0001.png","n-0002.png","n-0003.png","n-0004.png","n-0005.png","n-0006.png","n-0007.png","n-0008.png","n-0009.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 184,
              month_startY: 28,
              month_sc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_tc_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_en_array: ["mes-0001.png","mes-0002.png","mes-0003.png","mes-0004.png","mes-0005.png","mes-0006.png","mes-0007.png","mes-0008.png","mes-0009.png","mes-0010.png","mes-0011.png","mes-0012.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 205,
              day_startY: 61,
              day_sc_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_tc_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_en_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 25,
              hour_startY: 209,
              hour_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              hour_zero: 1,
              hour_space: -20,
              hour_align: hmUI.align.LEFT,

              minute_startX: 195,
              minute_startY: 209,
              minute_array: ["num-0000.png","num-0001.png","num-0002.png","num-0003.png","num-0004.png","num-0005.png","num-0006.png","num-0007.png","num-0008.png","num-0009.png"],
              minute_zero: 1,
              minute_space: -19,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 375,
              second_startY: 240,
              second_array: ["nu-0000.png","nu-0001.png","nu-0002.png","nu-0003.png","nu-0004.png","nu-0005.png","nu-0006.png","nu-0007.png","nu-0008.png","nu-0009.png"],
              second_zero: 1,
              second_space: -1,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 171,
              y: 210,
              src: 'pun-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 353,
              y: 235,
              src: 'p-0000.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'san-0000.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 39,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 45,
              y: 212,
              w: 320,
              h: 80,
              src: 'con-0000.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 139,
              y: 374,
              w: 200,
              h: 100,
              src: 'con-0000.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 320,
              y: 60,
              w: 100,
              h: 70,
              src: 'con-0000.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_system_lock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 297,
              y: 30,
              src: 'lu-0000.png',
              type: hmUI.system_status.LOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 247,
              y: 30,
              src: 'dn-0000.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 198,
              y: 30,
              src: 'bl-0000.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 146,
              y: 30,
              src: 'sv-0000.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 200,
              y: 400,
              font_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              padding: true,
              h_space: 5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 157,
              y: 399,
              src: 'bat-0100.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 277,
              year_startY: 100,
              year_sc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              year_tc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              year_en_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              year_zero: 1,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 183,
              month_startY: 100,
              month_sc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              month_tc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              month_en_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 257,
              y: 116,
              src: 'dis-0101.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 90,
              day_startY: 100,
              day_sc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              day_tc_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              day_en_array: ["nu-0100.png","nu-0101.png","nu-0102.png","nu-0103.png","nu-0104.png","nu-0105.png","nu-0106.png","nu-0107.png","nu-0108.png","nu-0109.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 164,
              y: 117,
              src: 'dis-0101.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 38,
              hour_startY: 200,
              hour_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              hour_zero: 1,
              hour_space: -14,
              hour_align: hmUI.align.LEFT,

              minute_startX: 255,
              minute_startY: 200,
              minute_array: ["num-0100.png","num-0101.png","num-0102.png","num-0103.png","num-0104.png","num-0105.png","num-0106.png","num-0107.png","num-0108.png","num-0109.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 213,
              y: 200,
              src: 'pun-0100.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  