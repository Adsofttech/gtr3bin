﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {
    (()=>{
        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_battery_text_text_img = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''


        //dynamic modify end
        const e = __$$hmAppManager$$__.currentApp;
        const o = e.current
          , {px: i} = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e,o)),
        e.__globals__)
          , n = Logger.getLogger("watchface6");
        o.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0047.png',
              center_x: 227,
              center_y: 341,
              x: 18,
              y: 75,
              start_angle: -179,
              end_angle: 180,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 364,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0048.png',
              unit_tc: '0048.png',
              unit_en: '0048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 363,
              y: 185,
              font_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0079.png',
              unit_tc: '0079.png',
              unit_en: '0079.png',
              negative_image: '0078.png',
              invalid_image: '0046.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 317,
              y: 162,
              image_array: ["0049.png","0050.png","0051.png","0052.png","0053.png","0054.png","0055.png","0056.png","0057.png","0058.png","0059.png","0060.png","0061.png","0062.png","0063.png","0064.png","0065.png","0066.png","0067.png","0068.png","0069.png","0070.png","0071.png","0072.png","0073.png","0074.png","0075.png","0076.png","0077.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0045.png',
              center_x: 127,
              center_y: 227,
              x: 17,
              y: 54,
              start_angle: -179,
              end_angle: 180,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 109,
              y: 243,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0033.png',
              center_x: 227,
              center_y: 105,
              x: 18,
              y: 75,
              start_angle: -115,
              end_angle: 115,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 194,
              y: 151,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 380,
              month_startY: 252,
              month_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              month_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              month_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              month_zero: 1,
              month_space: -1,
              month_align: hmUI.align.LEFT,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 311,
              year_startY: 252,
              year_sc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              year_tc_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              year_en_array: ["0006.png","0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png"],
              year_zero: 1,
              year_space: -1,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 316,
              y: 219,
              week_en: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_tc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              week_sc: ["0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 375,
              day_startY: 219,
              day_sc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_tc_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_en_array: ["0016.png","0017.png","0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png","0025.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 40,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 40,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   second_path: '0005.png',
            //   second_centerX: 227,
            //   second_centerY: 227,
            //   second_posX: 40,
            //   second_posY: 227,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

		let second_centerX = 227;
            let second_centerY = 227;
            let second_posX = 40;
            let second_posY = 227;
            let second_path = "0005.png";
            // ----------------------------
            let lastTime = 0;
            let animTimer;
            const animDuration = 5000;
            const animFps = 25; // 8 for 28800VPH, 10 for 36000VPH, 25 for smooth motion
            const deviceInfo = hmSetting.getDeviceInfo();   // Needed for automatic screen size detection
            
            // Smooth Seconds
            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: second_centerX - second_posX,
              pos_y: second_centerY - second_posY,
              center_x: second_centerX,
              center_y: second_centerY,
              src: second_path,
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            function startSecAnim(sec) {
              const secAnim = {
                anim_rate: 'linear',
                anim_duration: animDuration,
                anim_from: sec,
                anim_to: sec + animDuration * 6 / 1000,
                repeat_count: 1,
                anim_fps: animFps,
                anim_key: "angle",
                anim_status: 1,
              }
              normal_analog_clock_time_pointer_second.setProperty(hmUI.prop.ANIM, secAnim);
            }

            const now = hmSensor.createSensor(hmSensor.id.TIME);

            let widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {  // when the screen turns on, create a timer to update the animation
                console.log('ui resume');
      
                const screenType = hmSetting.getScreenType();
                if (screenType != hmSetting.screen_type.WATCHFACE) return;  // if not the main screen of the dial, then do nothing
                if (animTimer) return;  // if the timer is already running, then do nothing
      
                let duration = 0;
                const diffTime = now.utc - lastTime;
                if (diffTime < animDuration) {
                  duration = animDuration - diffTime;  // we calculate the timer start delay, depending on the time of its last start (so that there is no overlap of two animations)
                }
      
                console.log('createTimer');
                animTimer = timer.createTimer(duration, animDuration, (function (option) {
                  lastTime = now.utc;
                  let sec = (now.second * 6) + (((now.utc % 1000) / 1000) * 6);  // we calculate the angle of the second hand depending on the seconds and milliseconds.
                  startSecAnim(sec);
                }));
              }),
              pause_call: (function () {  // when the screen turns off, delete the timer
                console.log('ui pause');
                if (animTimer) {
                  timer.stopTimer(animTimer);
                  animTimer = undefined;
                }
              }),
            });

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0001.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 201,
              y: 364,
              font_array: ["0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png","0041.png","0042.png","0043.png"],
              padding: false,
              h_space: 0,
              unit_sc: '0048.png',
              unit_tc: '0048.png',
              unit_en: '0048.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0080.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 40,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0081.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 40,
              minute_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                n.log("index page.js on init invoke")
            },
            build() {
                this.init_view(),
                n.log("index page.js on ready invoke")
            },
            onDestroy() {
                n.log("index page.js on destroy invoke")
            }
        })
    }
    )()
} catch (e) {
    console.log("Mini Program Error", e),
    e && e.stack && e.stack.split(/\n/).forEach((e=>console.log("error stack", e)))
}
