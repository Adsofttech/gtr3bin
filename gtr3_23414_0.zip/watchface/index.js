﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month = ''
        let normal_date_img_date_year = ''
        let normal_digital_clock_img_time = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month = ''
        let idle_date_img_date_year = ''
        let idle_digital_clock_img_time = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 300,
              y: 305,
              font_array: ["steppulse_0.png","steppulse_1.png","steppulse_2.png","steppulse_3.png","steppulse_4.png","steppulse_5.png","steppulse_6.png","steppulse_7.png","steppulse_8.png","steppulse_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 182,
              y: 354,
              font_array: ["bat_0.png","bat_1.png","bat_2.png","bat_3.png","bat_4.png","bat_5.png","bat_6.png","bat_7.png","bat_8.png","bat_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 108,
              day_startY: 70,
              day_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              day_zero: 1,
              day_space: -2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 188,
              month_startY: 70,
              month_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              month_zero: 1,
              month_space: 2,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 271,
              year_startY: 70,
              year_sc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_tc_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_en_array: ["date_0.png","date_1.png","date_2.png","date_3.png","date_4.png","date_5.png","date_6.png","date_7.png","date_8.png","date_9.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 26,
              hour_startY: 160,
              hour_array: ["0_clock.png","1_clock.png","2_clock.png","3_clock.png","4_clock.png","5_clock.png","6_clock.png","7_clock.png","8_clock.png","9_clock.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 161,
              minute_startY: 160,
              minute_array: ["0_clock.png","1_clock.png","2_clock.png","3_clock.png","4_clock.png","5_clock.png","6_clock.png","7_clock.png","8_clock.png","9_clock.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 296,
              second_startY: 160,
              second_array: ["0_clock.png","1_clock.png","2_clock.png","3_clock.png","4_clock.png","5_clock.png","6_clock.png","7_clock.png","8_clock.png","9_clock.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 181,
              y: 356,
              font_array: ["AOD_Bat_0.png","AOD_Bat_1.png","AOD_Bat_2.png","AOD_Bat_3.png","AOD_Bat_4.png","AOD_Bat_5.png","AOD_Bat_6.png","AOD_Bat_7.png","AOD_Bat_8.png","AOD_Bat_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 108,
              day_startY: 74,
              day_sc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              day_tc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              day_en_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 189,
              month_startY: 74,
              month_sc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              month_tc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              month_en_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              month_zero: 1,
              month_space: 4,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 273,
              year_startY: 74,
              year_sc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              year_tc_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              year_en_array: ["AOD_Date_0.png","AOD_Date_1.png","AOD_Date_2.png","AOD_Date_3.png","AOD_Date_4.png","AOD_Date_5.png","AOD_Date_6.png","AOD_Date_7.png","AOD_Date_8.png","AOD_Date_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.CENTER_H,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 28,
              hour_startY: 167,
              hour_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              hour_zero: 1,
              hour_space: 6,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 164,
              minute_startY: 168,
              minute_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              minute_zero: 1,
              minute_space: 6,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              second_startX: 299,
              second_startY: 167,
              second_array: ["AOD_0.png","AOD_1.png","AOD_2.png","AOD_3.png","AOD_4.png","AOD_5.png","AOD_6.png","AOD_7.png","AOD_8.png","AOD_9.png"],
              second_zero: 1,
              second_space: 6,
              second_follow: 0,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  