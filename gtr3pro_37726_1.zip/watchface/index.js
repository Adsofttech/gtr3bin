﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_digital_clock_minute_separator_img = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_minute_separator_img = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 377,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 149,
              year_startY: 313,
              year_sc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_tc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_en_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 74,
              month_startY: 311,
              month_sc_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_tc_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_en_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 339,
              day_startY: 144,
              day_sc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_tc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_en_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 267,
              y: 142,
              week_en: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              week_tc: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              week_sc: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 403,
              am_y: 231,
              am_sc_path: 'time-AM.png',
              am_en_path: 'time-AM.png',
              pm_x: 403,
              pm_y: 231,
              pm_sc_path: 'time-PM.png',
              pm_en_path: 'time-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 192,
              hour_array: ["D94_00.png","D94_01.png","D94_02.png","D94_03.png","D94_04.png","D94_05.png","D94_06.png","D94_07.png","D94_08.png","D94_09.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 267,
              minute_startY: 192,
              minute_array: ["D94_00.png","D94_01.png","D94_02.png","D94_03.png","D94_04.png","D94_05.png","D94_06.png","D94_07.png","D94_08.png","D94_09.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 230,
              second_startY: 48,
              second_array: ["A-20-0.png","A-20-1.png","A-20-2.png","A-20-3.png","A-20-4.png","A-20-5.png","A-20-6.png","A-20-7.png","A-20-8.png","A-20-9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 183,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 183,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 218,
              y: 377,
              image_array: ["bat_01.png","bat_02.png","bat_03.png","bat_04.png","bat_05.png","bat_06.png","bat_07.png","bat_08.png","bat_09.png","bat_10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 149,
              year_startY: 313,
              year_sc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_tc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_en_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              year_zero: 0,
              year_space: 0,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 74,
              month_startY: 311,
              month_sc_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_tc_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_en_array: ["STAA25_18.png","STAA25_19.png","STAA25_20.png","STAA25_21.png","STAA25_22.png","STAA25_23.png","STAA25_24.png","STAA25_25.png","STAA25_26.png","STAA25_27.png","STAA25_28.png","STAA25_29.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 339,
              day_startY: 144,
              day_sc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_tc_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_en_array: ["S25_NUM_0.png","S25_NUM_1.png","S25_NUM_2.png","S25_NUM_3.png","S25_NUM_4.png","S25_NUM_5.png","S25_NUM_6.png","S25_NUM_7.png","S25_NUM_8.png","S25_NUM_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 267,
              y: 142,
              week_en: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              week_tc: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              week_sc: ["STAA25_0.png","STAA25_1.png","STAA25_2.png","STAA25_3.png","STAA25_4.png","STAA25_5.png","STAA25_6.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 403,
              am_y: 231,
              am_sc_path: 'time-AM.png',
              am_en_path: 'time-AM.png',
              pm_x: 403,
              pm_y: 231,
              pm_sc_path: 'time-PM.png',
              pm_en_path: 'time-PM.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 106,
              hour_startY: 192,
              hour_array: ["D94_00.png","D94_01.png","D94_02.png","D94_03.png","D94_04.png","D94_05.png","D94_06.png","D94_07.png","D94_08.png","D94_09.png"],
              hour_zero: 1,
              hour_space: 9,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 267,
              minute_startY: 192,
              minute_array: ["D94_00.png","D94_01.png","D94_02.png","D94_03.png","D94_04.png","D94_05.png","D94_06.png","D94_07.png","D94_08.png","D94_09.png"],
              minute_zero: 1,
              minute_space: 9,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 230,
              second_startY: 48,
              second_array: ["A-20-0.png","A-20-1.png","A-20-2.png","A-20-3.png","A-20-4.png","A-20-5.png","A-20-6.png","A-20-7.png","A-20-8.png","A-20-9.png"],
              second_zero: 1,
              second_space: -1,
              second_angle: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 89,
              y: 183,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_minute_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 250,
              y: 183,
              src: 'shadow.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 202,
              y: 204,
              w: 73,
              h: 70,
              src: 'transparent.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 140,
              y: 35,
              w: 205,
              h: 93,
              src: 'transparent.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 203,
              y: 344,
              w: 73,
              h: 70,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}