﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_pointer_progress_img_pointer = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 360,
              y: 170,
              src: 'system_Blutoothoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 324,
              y: 172,
              src: 'system_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 335,
              y: 324,
              font_array: ["ACT-Orange_font_01.png","ACT-Orange_font_02.png","ACT-Orange_font_03.png","ACT-Orange_font_04.png","ACT-Orange_font_05.png","ACT-Orange_font_06.png","ACT-Orange_font_07.png","ACT-Orange_font_08.png","ACT-Orange_font_09.png","ACT-Orange_font_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Act-W_Font_12.png',
              unit_tc: 'Act-W_Font_12.png',
              unit_en: 'Act-W_Font_12.png',
              negative_image: 'Act-W_Font_11.png',
              invalid_image: 'Act-W_Font_12.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 330,
              y: 274,
              image_array: ["Weather_icons_01.png","Weather_icons_02.png","Weather_icons_03.png","Weather_icons_04.png","Weather_icons_05.png","Weather_icons_06.png","Weather_icons_07.png","Weather_icons_08.png","Weather_icons_09.png","Weather_icons_10.png","Weather_icons_11.png","Weather_icons_12.png","Weather_icons_13.png","Weather_icons_14.png","Weather_icons_15.png","Weather_icons_16.png","Weather_icons_17.png","Weather_icons_18.png","Weather_icons_19.png","Weather_icons_20.png","Weather_icons_21.png","Weather_icons_22.png","Weather_icons_23.png","Weather_icons_24.png","Weather_icons_25.png","Weather_icons_26.png","Weather_icons_27.png","Weather_icons_28.png","Weather_icons_29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_04.png',
              center_x: 227,
              center_y: 323,
              x: 12,
              y: 50,
              start_angle: 90,
              end_angle: 270,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 199,
              y: 285,
              font_array: ["ACT-Orange_font_01.png","ACT-Orange_font_02.png","ACT-Orange_font_03.png","ACT-Orange_font_04.png","ACT-Orange_font_05.png","ACT-Orange_font_06.png","ACT-Orange_font_07.png","ACT-Orange_font_08.png","ACT-Orange_font_09.png","ACT-Orange_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 93,
              y: 192,
              week_en: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_tc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              week_sc: ["week_1.png","week_2.png","week_3.png","week_4.png","week_5.png","week_6.png","week_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 335,
              day_startY: 126,
              day_sc_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              day_tc_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              day_en_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Hand_04.png',
              center_x: 227,
              center_y: 129,
              x: 12,
              y: 50,
              start_angle: 253,
              end_angle: 450,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 198,
              y: 153,
              font_array: ["ACT-Orange_font_01.png","ACT-Orange_font_02.png","ACT-Orange_font_03.png","ACT-Orange_font_04.png","ACT-Orange_font_05.png","ACT-Orange_font_06.png","ACT-Orange_font_07.png","ACT-Orange_font_08.png","ACT-Orange_font_09.png","ACT-Orange_font_10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 274,
              hour_startY: 215,
              hour_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 337,
              minute_startY: 215,
              minute_array: ["Time_HM_Font_01.png","Time_HM_Font_02.png","Time_HM_Font_03.png","Time_HM_Font_04.png","Time_HM_Font_05.png","Time_HM_Font_06.png","Time_HM_Font_07.png","Time_HM_Font_08.png","Time_HM_Font_09.png","Time_HM_Font_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 224,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 22,
              minute_posY: 229,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 216,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 59,
              y: 289,
              w: 100,
              h: 100,
              src: '0076.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 58,
              y: 59,
              w: 100,
              h: 100,
              src: '0076.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '2.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 19,
              hour_posY: 224,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '3.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 22,
              minute_posY: 229,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '4.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 28,
              second_posY: 216,
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  