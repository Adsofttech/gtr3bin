﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_step_current_text_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_date_img_date_day = ''
        let normal_analog_clock_pro_hour_pointer_img = ''
        let normal_analog_clock_pro_minute_pointer_img = ''
        let normal_analog_clock_pro_second_pointer_img = ''
        let normal_timerUpdateSec = undefined;
        let idle_background_bg_img = ''
        let idle_step_current_text_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_date_img_date_day = ''
        let idle_analog_clock_pro_hour_pointer_img = ''
        let idle_analog_clock_pro_minute_pointer_img = ''
        let idle_analog_clock_pro_second_pointer_img = ''
        let idle_timerUpdateSec = undefined;
        let timeSensor = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 303,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arr_p.png',
              center_x: 87,
              center_y: 226,
              x: 18,
              y: 54,
              start_angle: 179,
              end_angle: -179,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 358,
              day_startY: 208,
              day_sc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_tc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_en_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            const deviceInfo = hmSetting.getDeviceInfo();
            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(true, true);
            });

            // normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_h.png',
              // center_x: 227,
              // center_y: 227,
              // x: 18,
              // y: 134,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 18,
              pos_y: 227 - 134,
              center_x: 227,
              center_y: 227,
              src: 'arr_h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_m.png',
              // center_x: 227,
              // center_y: 227,
              // x: 18,
              // y: 180,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 18,
              pos_y: 227 - 180,
              center_x: 227,
              center_y: 227,
              src: 'arr_m.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_s.png',
              // center_x: 227,
              // center_y: 227,
              // x: 9,
              // y: 199,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });


            normal_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 9,
              pos_y: 227 - 199,
              center_x: 227,
              center_y: 227,
              src: 'arr_s.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();

            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 184,
              y: 303,
              font_array: ["dig_small_0.png","dig_small_1.png","dig_small_2.png","dig_small_3.png","dig_small_4.png","dig_small_5.png","dig_small_6.png","dig_small_7.png","dig_small_8.png","dig_small_9.png"],
              padding: false,
              h_space: 2,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'arr_p.png',
              center_x: 87,
              center_y: 226,
              x: 18,
              y: 54,
              start_angle: 179,
              end_angle: -179,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 358,
              day_startY: 208,
              day_sc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_tc_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_en_array: ["dig_0.png","dig_1.png","dig_2.png","dig_3.png","dig_4.png","dig_5.png","dig_6.png","dig_7.png","dig_8.png","dig_9.png"],
              day_zero: 1,
              day_space: 0,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_h.png',
              // center_x: 227,
              // center_y: 227,
              // x: 18,
              // y: 134,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.hour,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_hour_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 18,
              pos_y: 227 - 134,
              center_x: 227,
              center_y: 227,
              src: 'arr_h.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_m.png',
              // center_x: 227,
              // center_y: 227,
              // x: 18,
              // y: 180,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.minute,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_minute_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 18,
              pos_y: 227 - 180,
              center_x: 227,
              center_y: 227,
              src: 'arr_m.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.TIME_POINTER_PRO, {
              // src: 'arr_s.png',
              // center_x: 227,
              // center_y: 227,
              // x: 9,
              // y: 199,
              // start_angle: 0,
              // end_angle: 360,
              // type: hmUI.data_type.second,
              // show_level: hmUI.show_level.ONLY_AOD,
            // });


            idle_analog_clock_pro_second_pointer_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: deviceInfo.width,
              h: deviceInfo.height,
              pos_x: 227 - 9,
              pos_y: 227 - 199,
              center_x: 227,
              center_y: 227,
              src: 'arr_s.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');
              let hour = timeSensor.hour;
              let minute = timeSensor.minute;
              let second = timeSensor.second;

              if (updateHour) {
                let normal_hour = hour;
                let normal_fullAngle_hour = 360;
                if (normal_hour > 11) normal_hour -= 12;
                let normal_angle_hour = 0 + normal_fullAngle_hour*normal_hour/12 + (normal_fullAngle_hour/12)*minute/60;
                if (normal_analog_clock_pro_hour_pointer_img) normal_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_hour);
              };

              if (updateMinute) {
                let normal_fullAngle_minute = 360;
                let normal_angle_minute = 0 + normal_fullAngle_minute*minute/60;
                if (normal_analog_clock_pro_minute_pointer_img) normal_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_minute);
              };

              let normal_fullAngle_second = 360;
              let normal_angle_second = 0 + normal_fullAngle_second*second/60;
              if (normal_analog_clock_pro_second_pointer_img) normal_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, normal_angle_second);

              if (updateHour) {
                let idle_hour = hour;
                let idle_fullAngle_hour = 360;
                if (idle_hour > 11) idle_hour -= 12;
                let idle_angle_hour = 0 + idle_fullAngle_hour*idle_hour/12 + (idle_fullAngle_hour/12)*minute/60;
                if (idle_analog_clock_pro_hour_pointer_img) idle_analog_clock_pro_hour_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_hour);
              };

              if (updateMinute) {
                let idle_fullAngle_minute = 360;
                let idle_angle_minute = 0 + idle_fullAngle_minute*minute/60;
                if (idle_analog_clock_pro_minute_pointer_img) idle_analog_clock_pro_minute_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_minute);
              };

              let idle_fullAngle_second = 360;
              let idle_angle_second = 0 + idle_fullAngle_second*second/60;
              if (idle_analog_clock_pro_second_pointer_img) idle_analog_clock_pro_second_pointer_img.setProperty(hmUI.prop.ANGLE, idle_angle_second);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                time_update(true, true);
                if (screenType == hmSetting.screen_type.WATCHFACE) {
                  if (!normal_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    normal_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType

                if (screenType == hmSetting.screen_type.AOD) {
                  if (!idle_timerUpdateSec) {
                    let animDelay = timeSensor.utc % 1000;
                    let animRepeat = 1000;
                    idle_timerUpdateSec = timer.createTimer(animDelay, animRepeat, (function (option) {
                      time_update(false, false);
                    }));  // end timer 
                  };  // end timer check
                };  // end screenType


              }),
              pause_call: (function () {
                console.log('pause_call()');
                if (normal_timerUpdateSec) {
                  timer.stopTimer(normal_timerUpdateSec);
                  normal_timerUpdateSec = undefined;
                }
                if (idle_timerUpdateSec) {
                  timer.stopTimer(idle_timerUpdateSec);
                  idle_timerUpdateSec = undefined;
                }

              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}