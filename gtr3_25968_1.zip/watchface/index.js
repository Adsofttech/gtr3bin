﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_frame_animation_1 = ''
        let normal_city_name_text = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_text_separator_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_date_img_date_week_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_digital_clock_img_time = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_battery_image_progress_img_level = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_digital_clock_img_time_minute = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0002.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_frame_animation_1 = hmUI.createWidget(hmUI.widget.IMG_ANIM, {
              x: 0,
              y: 0,
              anim_path: "animation",
              anim_ext: "png",
              anim_prefix: " anim",
              anim_fps: 17,
              anim_size: 90,
              repeat_count: 0,
              anim_repeat: true,
              anim_status:hmUI.anim_status.START,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 146,
              y: 355,
              w: 160,
              h: 40,
              text_size: 22,
              char_space: -2,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.ELLIPSIS,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 98,
              y: 325,
              src: '0049.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 332,
              y: 320,
              src: '0050.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 72,
              y: 215,
              font_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              padding: false,
              h_space: 9,
              unit_sc: '0035.png',
              unit_tc: '0035.png',
              unit_en: '0035.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 57,
              y: 200,
              src: '0036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 340,
              day_startY: 215,
              day_sc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_tc_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_en_array: ["0025.png","0026.png","0027.png","0028.png","0029.png","0030.png","0031.png","0032.png","0033.png","0034.png"],
              day_zero: 0,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 266,
              y: 200,
              src: '0036.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 280,
              y: 214,
              week_en: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_tc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              week_sc: ["0018.png","0019.png","0020.png","0021.png","0022.png","0023.png","0024.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 25,
              hour_posY: 141,
              hour_cover_path: '0006.png',
              hour_cover_x: 0,
              hour_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 26,
              minute_posY: 210,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 19,
              second_posY: 212,
              second_cover_path: '0037.png',
              second_cover_x: 182,
              second_cover_y: 67,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 135,
              hour_startY: 295,
              hour_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_unit_sc: '0017.png',
              hour_unit_tc: '0017.png',
              hour_unit_en: '0017.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 252,
              minute_startY: 295,
              minute_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 324,
              y: 161,
              w: 120,
              h: 120,
              src: '0051.png',
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 10,
              y: 161,
              w: 120,
              h: 120,
              src: '0051.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 328,
              w: 120,
              h: 120,
              src: '0051.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 162,
              y: 6,
              w: 120,
              h: 120,
              src: '0051.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: '0052.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 199,
              y: 347,
              image_array: ["0038.png","0039.png","0040.png","0041.png","0042.png","0043.png","0044.png","0045.png","0046.png","0047.png","0048.png"],
              image_length: 11,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0053.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 71,
              hour_posY: 216,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_minute = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              minute_startX: 192,
              minute_startY: 198,
              minute_array: ["0007.png","0008.png","0009.png","0010.png","0011.png","0012.png","0013.png","0014.png","0015.png","0016.png"],
              minute_zero: 1,
              minute_space: 15,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.START);

              }),
              pause_call: (function () {
                normal_frame_animation_1.setProperty(hmUI.prop.ANIM_STATUS,hmUI.anim_status.STOP);

              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  