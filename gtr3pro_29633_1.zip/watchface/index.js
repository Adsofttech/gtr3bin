﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_system_clock_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_linear_scale = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_linear_scale = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_day = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Background_03.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 276,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 209,
              src: 'Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 113,
              src: 'BATT_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // normal_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 202,
              // start_y: 116,
              // color: 0xFFFF8C00,
              // lenght: 24,
              // line_width: 9,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 113,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Per_Icon.png',
              unit_tc: 'Per_Icon.png',
              unit_en: 'Per_Icon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 251,
              day_startY: 351,
              day_sc_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_tc_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_en_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 351,
              month_sc_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_tc_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_en_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 343,
              y: 233,
              week_en: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_tc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_sc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 206,
              hour_array: ["T_W-0.png","T_W-1.png","T_W-2.png","T_W-3.png","T_W-4.png","T_W-5.png","T_W-6.png","T_W-7.png","T_W-8.png","T_W-9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 82,
              minute_startY: 246,
              minute_array: ["T_W-0.png","T_W-1.png","T_W-2.png","T_W-3.png","T_W-4.png","T_W-5.png","T_W-6.png","T_W-7.png","T_W-8.png","T_W-9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 137,
              second_startY: 247,
              second_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'H_T_2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 178,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'H_min_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 214,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'H_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'Background_04.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 349,
              y: 276,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 199,
              y: 113,
              src: 'BATT_2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.FILL_RECT);
            };

            // idle_battery_linear_scale = hmUI.createWidget(hmUI.widget.Linear_Scale, {
              // start_x: 202,
              // start_y: 116,
              // color: 0xFFFF8C00,
              // lenght: 24,
              // line_width: 9,
              // vertical: False,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 240,
              y: 113,
              font_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'Per_Icon.png',
              unit_tc: 'Per_Icon.png',
              unit_en: 'Per_Icon.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 251,
              day_startY: 351,
              day_sc_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_tc_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_en_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 351,
              month_sc_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_tc_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_en_array: ["MW_01.png","MW_02.png","MW_03.png","MW_04.png","MW_05.png","MW_06.png","MW_07.png","MW_08.png","MW_09.png","MW_10.png","MW_11.png","MW_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 343,
              y: 233,
              week_en: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_tc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              week_sc: ["W_01.png","W_02.png","W_03.png","W_04.png","W_05.png","W_06.png","W_07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 82,
              hour_startY: 206,
              hour_array: ["T_W-0.png","T_W-1.png","T_W-2.png","T_W-3.png","T_W-4.png","T_W-5.png","T_W-6.png","T_W-7.png","T_W-8.png","T_W-9.png"],
              hour_zero: 1,
              hour_space: 2,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 82,
              minute_startY: 246,
              minute_array: ["T_W-0.png","T_W-1.png","T_W-2.png","T_W-3.png","T_W-4.png","T_W-5.png","T_W-6.png","T_W-7.png","T_W-8.png","T_W-9.png"],
              minute_zero: 1,
              minute_space: 2,
              minute_follow: 0,
              minute_align: hmUI.align.RIGHT,

              second_startX: 137,
              second_startY: 247,
              second_array: ["N_0.png","N_1.png","N_2.png","N_3.png","N_4.png","N_5.png","N_6.png","N_7.png","N_8.png","N_9.png"],
              second_zero: 1,
              second_space: 2,
              second_follow: 0,
              second_align: hmUI.align.RIGHT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'H_T_2.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 24,
              hour_posY: 178,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'H_min_2.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 24,
              minute_posY: 214,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'H_sec.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 26,
              second_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_ls_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_linear_scale
                  // initial parameters
                  let start_x_normal_battery = 202;
                  let start_y_normal_battery = 116;
                  let lenght_ls_normal_battery = 24;
                  let line_width_ls_normal_battery = 9;
                  let color_ls_normal_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_normal_battery_draw = start_x_normal_battery;
                  let start_y_normal_battery_draw = start_y_normal_battery;
                  lenght_ls_normal_battery = lenght_ls_normal_battery * progress_ls_normal_battery;
                  let lenght_ls_normal_battery_draw = lenght_ls_normal_battery;
                  let line_width_ls_normal_battery_draw = line_width_ls_normal_battery;
                  if (lenght_ls_normal_battery < 0){
                    lenght_ls_normal_battery_draw = -lenght_ls_normal_battery;
                    start_x_normal_battery_draw = start_x_normal_battery - lenght_ls_normal_battery_draw;
                  };
                  
                  normal_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_normal_battery_draw,
                    y: start_y_normal_battery_draw,
                    w: lenght_ls_normal_battery_draw,
                    h: line_width_ls_normal_battery_draw,
                    color: color_ls_normal_battery,
                  });
                };

                console.log('update scales BATTERY');
                let progress_ls_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_linear_scale
                  // initial parameters
                  let start_x_idle_battery = 202;
                  let start_y_idle_battery = 116;
                  let lenght_ls_idle_battery = 24;
                  let line_width_ls_idle_battery = 9;
                  let color_ls_idle_battery = 0xFFFF8C00;
                  
                  // calculated parameters
                  let start_x_idle_battery_draw = start_x_idle_battery;
                  let start_y_idle_battery_draw = start_y_idle_battery;
                  lenght_ls_idle_battery = lenght_ls_idle_battery * progress_ls_idle_battery;
                  let lenght_ls_idle_battery_draw = lenght_ls_idle_battery;
                  let line_width_ls_idle_battery_draw = line_width_ls_idle_battery;
                  if (lenght_ls_idle_battery < 0){
                    lenght_ls_idle_battery_draw = -lenght_ls_idle_battery;
                    start_x_idle_battery_draw = start_x_idle_battery - lenght_ls_idle_battery_draw;
                  };
                  
                  idle_battery_linear_scale.setProperty(hmUI.prop.MORE, {
                    x: start_x_idle_battery_draw,
                    y: start_y_idle_battery_draw,
                    w: lenght_ls_idle_battery_draw,
                    h: line_width_ls_idle_battery_draw,
                    color: color_ls_idle_battery,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  