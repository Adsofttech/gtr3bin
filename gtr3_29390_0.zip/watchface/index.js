﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_weekly_text_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_spo2_text_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_image_progress_img_level = ''
        let normal_date_img_date_year = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_heart_rate_text_text_img = ''
        let normal_heart_rate_image_progress_img_level = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_date_img_date_week_img = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_second_separator_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_city_name_text = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_sunrise_jumpable_img_click = ''
        let normal_spo2_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let normal_sleep_jumpable_img_click = ''
        let normal_pai_jumpable_img_click = ''
        let idle_background_bg_img = ''
        let idle_pai_weekly_text_img = ''
        let idle_sun_high_text_img = ''
        let idle_sun_low_text_img = ''
        let idle_spo2_text_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_image_progress_img_level = ''
        let idle_date_img_date_year = ''
        let idle_date_img_date_month_img = ''
        let idle_date_img_date_day = ''
        let idle_heart_rate_text_text_img = ''
        let idle_heart_rate_image_progress_img_level = ''
        let idle_system_disconnect_img = ''
        let idle_system_clock_img = ''
        let idle_date_img_date_week_img = ''
        let idle_digital_clock_img_time_AmPm = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_second_separator_img = ''
        let idle_battery_text_text_img = ''
        let idle_battery_icon_img = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_analog_clock_time_pointer_second = ''
        let idle_city_name_text = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main3Wa.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 106,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 155,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 155,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 106,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 377,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 391,
              y: 210,
              image_array: ["moon2_1.png","moon2_2.png","moon2_3.png","moon2_4.png","moon2_5.png","moon2_6.png","moon2_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 345,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_01 (1).png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 314,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 212,
              start_angle: 195,
              end_angle: 235,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 346,
              y: 307,
              image_array: ["goal1.png","goal2.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 166,
              year_startY: 284,
              year_sc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_tc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_en_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 287,
              month_sc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_tc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_en_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 284,
              day_sc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_tc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_en_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 65,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 65,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 250,
              src: 'BluetoothOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 194,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 271,
              week_en: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_tc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_sc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 235,
              am_sc_path: 'ha2.png',
              am_en_path: 'ha2.png',
              pm_x: 336,
              pm_y: 235,
              pm_sc_path: 'ha1.png',
              pm_en_path: 'ha1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 189,
              hour_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 227,
              minute_startY: 189,
              minute_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 342,
              second_startY: 190,
              second_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 251,
              src: 'ACT_01 (2).png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 36,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 185,
              src: 'Digital-shadow2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 212,
              start_angle: 305,
              end_angle: 345,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_04.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 234,
              second_cover_path: 'main w2.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 146,
              w: 95,
              h: 33,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 245,
              font_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'tem12.png',
              unit_tc: 'tem12.png',
              unit_en: 'tem12.png',
              negative_image: 'tem11.png',
              invalid_image: 'tem11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 187,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 103,
              y: 191,
              w: 50,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 281,
              y: 189,
              w: 47,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 197,
              y: 189,
              w: 42,
              h: 76,
              src: '0_Empty.png',
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sunrise_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 61,
              y: 148,
              w: 337,
              h: 28,
              src: '0_Empty.png',
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_spo2_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 187,
              y: 102,
              w: 86,
              h: 37,
              src: '0_Empty.png',
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 209,
              y: 63,
              w: 137,
              h: 33,
              src: '0_Empty.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 192,
              y: 310,
              w: 110,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sleep_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 379,
              y: 199,
              w: 52,
              h: 52,
              src: 'A-empty.png',
              type: hmUI.data_type.SLEEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 279,
              y: 101,
              w: 94,
              h: 38,
              src: '0_Empty.png',
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'main3Wa.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_pai_weekly_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 106,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.PAI_WEEKLY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 88,
              y: 155,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 307,
              y: 155,
              font_array: ["sun01.png","sun02.png","sun03.png","sun04.png","sun05.png","sun06.png","sun07.png","sun08.png","sun09.png","sun10.png"],
              padding: false,
              h_space: 1,
              dot_image: 'sun11.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_spo2_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 214,
              y: 106,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: false,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SPO2,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 239,
              y: 377,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 391,
              y: 210,
              image_array: ["moon2_1.png","moon2_2.png","moon2_3.png","moon2_4.png","moon2_5.png","moon2_6.png","moon2_7.png"],
              image_length: 7,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 345,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'ACT_14.png',
              unit_tc: 'ACT_14.png',
              unit_en: 'ACT_14.png',
              dot_image: 'ACT_01 (1).png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 230,
              y: 314,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 212,
              start_angle: 195,
              end_angle: 235,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 346,
              y: 307,
              image_array: ["goal1.png","goal2.png"],
              image_length: 2,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_year = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              year_startX: 166,
              year_startY: 284,
              year_sc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_tc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_en_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              year_zero: 0,
              year_space: 2,
              year_align: hmUI.align.LEFT,
              year_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 105,
              month_startY: 287,
              month_sc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_tc_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_en_array: ["month_icon_01.png","month_icon_02.png","month_icon_03.png","month_icon_04.png","month_icon_05.png","month_icon_06.png","month_icon_07.png","month_icon_08.png","month_icon_09.png","month_icon_10.png","month_icon_11.png","month_icon_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 70,
              day_startY: 284,
              day_sc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_tc_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_en_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              day_zero: 1,
              day_space: 2,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 231,
              y: 65,
              font_array: ["x01.png","x02.png","x03.png","x04.png","x05.png","x06.png","x07.png","x08.png","x09.png","x10.png"],
              padding: true,
              h_space: 1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_heart_rate_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 295,
              y: 65,
              image_array: ["Zone_01.png","Zone_02.png","Zone_03.png","Zone_04.png","Zone_05.png","Zone_06.png"],
              image_length: 6,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 398,
              y: 250,
              src: 'BluetoothOFF.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 394,
              y: 194,
              src: 'System_Alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 200,
              y: 271,
              week_en: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_tc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              week_sc: ["WEEK01.png","WEEK02.png","WEEK03.png","WEEK04.png","WEEK05.png","WEEK06.png","WEEK07.png"],
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 336,
              am_y: 235,
              am_sc_path: 'ha2.png',
              am_en_path: 'ha2.png',
              pm_x: 336,
              pm_y: 235,
              pm_sc_path: 'ha1.png',
              pm_en_path: 'ha1.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 100,
              hour_startY: 189,
              hour_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 227,
              minute_startY: 189,
              minute_array: ["h01.png","h02.png","h03.png","h04.png","h05.png","h06.png","h07.png","h08.png","h09.png","h10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 342,
              second_startY: 190,
              second_array: ["sa01.png","sa02.png","sa03.png","sa04.png","sa05.png","sa06.png","sa07.png","sa08.png","sa09.png","sa10.png"],
              second_zero: 1,
              second_space: 3,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 85,
              y: 251,
              src: 'ACT_01 (2).png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 227,
              y: 36,
              font_array: ["bat01.png","bat02.png","bat03.png","bat04.png","bat05.png","bat06.png","bat07.png","bat08.png","bat09.png","bat10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'bat11.png',
              unit_tc: 'bat11.png',
              unit_en: 'bat11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 69,
              y: 185,
              src: 'Digital-shadow2.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'Pointer_step_Batt.png',
              center_x: 227,
              center_y: 227,
              x: 9,
              y: 212,
              start_angle: 305,
              end_angle: 345,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'Hand_04.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 227,
              second_posY: 234,
              second_cover_path: 'main w2.png',
              second_cover_x: 0,
              second_cover_y: 0,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_city_name_text = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 180,
              y: 146,
              w: 95,
              h: 33,
              text_size: 18,
              char_space: 1,
              line_space: 0,
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.TOP,
              text_style: hmUI.text_style.NONE,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 32,
              y: 245,
              font_array: ["tem01.png","tem02.png","tem03.png","tem04.png","tem05.png","tem06.png","tem07.png","tem08.png","tem09.png","tem10.png"],
              padding: false,
              h_space: 2,
              unit_sc: 'tem12.png',
              unit_tc: 'tem12.png',
              unit_en: 'tem12.png',
              negative_image: 'tem11.png',
              invalid_image: 'tem11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 28,
              y: 187,
              image_array: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png","w08.png","w09.png","w10.png","w11.png","w12.png","w13.png","w14.png","w15.png","w16.png","w17.png","w18.png","w19.png","w20.png","w21.png","w22.png","w23.png","w24.png","w25.png","w26.png","w27.png","w28.png","w29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

              console.log('Wearther city name');
              const weatherSensor = hmSensor.createSensor(hmSensor.id.WEATHER);
              const weatherData = weatherSensor.getForecastWeather();
              normal_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

              console.log('Wearther city name');
              idle_city_name_text.setProperty(hmUI.prop.TEXT, weatherData.cityName);

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  