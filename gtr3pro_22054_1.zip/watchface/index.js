﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_temperature_icon_img = ''
        let normal_temperature_high_text_img = ''
        let normal_temperature_high_separator_img = ''
        let normal_temperature_low_text_img = ''
        let normal_temperature_low_separator_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_system_dnd_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_battery_text_text_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_date_img_date_day = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_image_progress_img_level = ''
        let normal_digital_clock_img_time_AmPm = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let normal_temperature_jumpable_img_click = ''
        let normal_heart_jumpable_img_click = ''
        let normal_step_jumpable_img_click = ''
        let idle_background_bg = ''
        let idle_step_current_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let idle_digital_clock_second_separator_img = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '0001BW.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 228,
              y: 341,
              src: 'S_no14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 327,
              font_array: ["S_no01.png","S_no02.png","S_no03.png","S_no04.png","S_no05.png","S_no06.png","S_no07.png","S_no08.png","S_no09.png","S_no10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'S_no13.png',
              unit_tc: 'S_no13.png',
              unit_en: 'S_no13.png',
              negative_image: 'S_no14.png',
              invalid_image: 'S_no12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_HIGH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_high_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 235,
              y: 336,
              src: 'S_no14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 377,
              y: 345,
              font_array: ["S_no01.png","S_no02.png","S_no03.png","S_no04.png","S_no05.png","S_no06.png","S_no07.png","S_no08.png","S_no09.png","S_no10.png"],
              padding: false,
              h_space: 3,
              unit_sc: 'S_no13.png',
              unit_tc: 'S_no13.png',
              unit_en: 'S_no13.png',
              negative_image: 'S_no14.png',
              invalid_image: 'S_no12.png',
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.WEATHER_LOW,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_low_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 222,
              y: 347,
              src: 'S_no14.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 314,
              y: 329,
              font_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              padding: false,
              h_space: 4,
              unit_sc: 'B-no13.png',
              unit_tc: 'B-no13.png',
              unit_en: 'B-no13.png',
              negative_image: 'B-no14.png',
              invalid_image: 'B-no12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 259,
              y: 328,
              image_array: ["Wea01.png","Wea02.png","Wea03.png","Wea04.png","Wea05.png","Wea06.png","Wea07.png","Wea08.png","Wea09.png","Wea10.png","Wea11.png","Wea12.png","Wea13.png","Wea14.png","Wea15.png","Wea16.png","Wea17.png","Wea18.png","Wea19.png","Wea20.png","Wea21.png","Wea22.png","Wea23.png","Wea24.png","Wea25.png","Wea26.png","Wea27.png","Wea28.png","Wea29.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_dnd_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 329,
              y: 80,
              src: 'sys-Dnd.png',
              type: hmUI.system_status.DISTURB,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 144,
              y: 73,
              src: 'sys-BT.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 417,
              y: 289,
              src: 'sys-alarm.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 316,
              y: 374,
              font_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              padding: false,
              h_space: 4,
              invalid_image: 'B-no12.png',
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 347,
              y: 165,
              font_array: ["W-no01.png","W-no02.png","W-no03.png","W-no04.png","W-no05.png","W-no06.png","W-no07.png","W-no08.png","W-no09.png","W-no10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 322,
              y: 128,
              image_array: ["batt01.png","batt02.png","batt03.png","batt04.png","batt05.png","batt06.png","batt07.png","batt08.png","batt09.png","batt10.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 226,
              day_startY: 104,
              day_sc_array: ["W-no01.png","W-no02.png","W-no03.png","W-no04.png","W-no05.png","W-no06.png","W-no07.png","W-no08.png","W-no09.png","W-no10.png"],
              day_tc_array: ["W-no01.png","W-no02.png","W-no03.png","W-no04.png","W-no05.png","W-no06.png","W-no07.png","W-no08.png","W-no09.png","W-no10.png"],
              day_en_array: ["W-no01.png","W-no02.png","W-no03.png","W-no04.png","W-no05.png","W-no06.png","W-no07.png","W-no08.png","W-no09.png","W-no10.png"],
              day_zero: 1,
              day_space: 4,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 165,
              y: 41,
              week_en: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png"],
              week_tc: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png"],
              week_sc: ["w01.png","w02.png","w03.png","w04.png","w05.png","w06.png","w07.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 93,
              month_startY: 169,
              month_sc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_tc_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_en_array: ["M01.png","M02.png","M03.png","M04.png","M05.png","M06.png","M07.png","M08.png","M09.png","M10.png","M11.png","M12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'p-mon.png',
              center_x: 111,
              center_y: 177,
              posX: 14,
              posY: 52,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 70,
              y: 283,
              font_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 63,
              y: 349,
              image_array: ["st01.png","st02.png","st03.png","st04.png","st05.png","st06.png","st07.png","st08.png","st09.png","st10.png"],
              image_length: 10,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time_AmPm = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              am_x: 247,
              am_y: 280,
              am_sc_path: 'C-AM.png',
              am_en_path: 'C-AM.png',
              pm_x: 247,
              pm_y: 280,
              pm_sc_path: 'C-PM.png',
              pm_en_path: 'C-PM.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 319,
              hour_startY: 283,
              hour_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 372,
              minute_startY: 283,
              minute_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 359,
              y: 282,
              src: 'B-no11.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: '0003.png',
              hour_centerX: 244,
              hour_centerY: 240,
              hour_posX: 29,
              hour_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: '0004.png',
              minute_centerX: 244,
              minute_centerY: 240,
              minute_posX: 29,
              minute_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '0005.png',
              second_centerX: 244,
              second_centerY: 240,
              second_posX: 29,
              second_posY: 223,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 247,
              y: 312,
              w: 53,
              h: 53,
              src: 'click.png',
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 248,
              y: 368,
              w: 53,
              h: 53,
              src: 'click.png',
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 172,
              y: 279,
              w: 66,
              h: 53,
              src: 'click.png',
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              color: '0xFF000000',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 202,
              y: 266,
              font_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              padding: false,
              h_space: 4,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 183,
              hour_startY: 220,
              hour_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              hour_zero: 1,
              hour_space: 4,
              hour_align: hmUI.align.LEFT,

              minute_startX: 236,
              minute_startY: 220,
              minute_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              minute_zero: 1,
              minute_space: 4,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 289,
              second_startY: 220,
              second_array: ["B-no01.png","B-no02.png","B-no03.png","B-no04.png","B-no05.png","B-no06.png","B-no07.png","B-no08.png","B-no09.png","B-no10.png"],
              second_zero: 1,
              second_space: 4,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 224,
              y: 220,
              src: 'B-no11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_second_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 277,
              y: 220,
              src: 'B-no11.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });


            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  