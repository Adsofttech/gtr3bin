﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_icon_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_step_icon_img = ''
        let normal_step_current_text_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''

        //--------- Start color change ---------
        let btncolor = ''
        let colornumber = 0
        let totalcolors = 1

        function click_Color() {
            colornumber=(colornumber+1) % (totalcolors+1);
            hmUI.showToast({text: "Background " + parseInt(colornumber) });

            normal_background_bg_img.setProperty(hmUI.prop.SRC, "background" + parseInt(colornumber) + ".png");
        }
        //--------- End color change ---------
		
        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'background0.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 67,
              y: 224,
              src: '00000028.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '000019STRELKA_MINI.png',
              center_x: 106,
              center_y: 236,
              x: 17,
              y: 56,
              start_angle: 0,
              end_angle: 360,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 316,
              y: 255,
              src: '00000027.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 287,
              y: 227,
              font_array: ["0012.png","0013.png","0014.png","0015.png","0016.png","0017.png","0018.png","0019.png","0020.png","0021.png"],
              padding: false,
              h_space: -5,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 156,
              y: 307,
              image_array: ["mooon_0.png","mooon_1.png","mooon_2.png","mooon_3.png","mooon_4.png","mooon_5.png","mooon_6.png","mooon_7.png","mooon_8.png","mooon_9.png","mooon_10.png","mooon_11.png","mooon_12.png","mooon_13.png","mooon_14.png","mooon_15.png","mooon_16.png","mooon_17.png","mooon_18.png","mooon_19.png","mooon_20.png","mooon_21.png","mooon_22.png","mooon_23.png","mooon_24.png","mooon_25.png","mooon_26.png","mooon_27.png","mooon_28.png","mooon_29.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour0HOURBL.png',
              hour_centerX: 240,
              hour_centerY: 240,
              hour_posX: 14,
              hour_posY: 161,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min0MINBL.png',
              minute_centerX: 240,
              minute_centerY: 240,
              minute_posX: 20,
              minute_posY: 239,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: '000000000022.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 19,
              second_posY: 237,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            // -------Begin Shortcut btncolorchange------
            btncolor = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 200,
              y: 392,
              text: '',
              w: 81,
              h: 88,
              normal_src: 'shortcut.png',
              press_src: 'shortcut.png',
              click_func: () => {
               click_Color();
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btncolor.setProperty(hmUI.prop.VISIBLE, true);
            // -------End Shortcut btncolorchange------



            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  