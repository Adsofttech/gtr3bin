﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_day = ''
        let normal_temperature_icon_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_digital_clock_img_time = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'past_4.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 220,
              y: 315,
              week_en: ["dn2_0.png","dn2_1.png","dn2_2.png","dn2_3.png","dn2_4.png","dn2_5.png","dn2_6.png"],
              week_tc: ["dn2_0.png","dn2_1.png","dn2_2.png","dn2_3.png","dn2_4.png","dn2_5.png","dn2_6.png"],
              week_sc: ["dn2_0.png","dn2_1.png","dn2_2.png","dn2_3.png","dn2_4.png","dn2_5.png","dn2_6.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 328,
              day_startY: 333,
              day_sc_array: ["dat3_0.png","dat3_1.png","dat3_2.png","dat3_3.png","dat3_4.png","dat3_5.png","dat3_6.png","dat3_7.png","dat3_8.png","dat3_9.png"],
              day_tc_array: ["dat3_0.png","dat3_1.png","dat3_2.png","dat3_3.png","dat3_4.png","dat3_5.png","dat3_6.png","dat3_7.png","dat3_8.png","dat3_9.png"],
              day_en_array: ["dat3_0.png","dat3_1.png","dat3_2.png","dat3_3.png","dat3_4.png","dat3_5.png","dat3_6.png","dat3_7.png","dat3_8.png","dat3_9.png"],
              day_zero: 1,
              day_space: 1,
              day_align: hmUI.align.LEFT,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 118,
              y: 290,
              src: 'sim_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 110,
              y: 320,
              image_array: ["wea_0_1.png","wea_1_1.png","wea_2_1.png","wea_3_1.png","wea_4_1.png","wea_5_1.png","wea_6_1.png","wea_7_1.png","wea_8_1.png","wea_9_1.png","wea_10_1.png","wea_11_1.png","wea_12_1.png","wea_13_1.png","wea_14_1.png","wea_15_1.png","wea_16_1.png","wea_17_1.png","wea_18_1.png","wea_19_1.png","wea_20_1.png","wea_21_1.png","wea_22_1.png","wea_23_1.png","wea_24_1.png","wea_25_1.png","wea_26_1.png","wea_27_1.png","wea_28_1.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 61,
              hour_startY: 126,
              hour_array: ["black80.png","black81.png","black82.png","black83.png","black84.png","black85.png","black86.png","black87.png","black88.png","black89.png"],
              hour_zero: 1,
              hour_space: -15,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 300,
              minute_startY: 147,
              minute_array: ["black7_0.png","black7_1.png","black7_2.png","black7_3.png","black7_4.png","black7_5.png","black7_6.png","black7_7.png","black7_8.png","black7_9.png"],
              minute_zero: 1,
              minute_space: -3,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });



            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 343,
              hour_startY: 224,
              hour_array: ["AODH_00_1_1.png","AODH_01_1_1.png","AODH_02_1_1.png","AODH_03_1_1.png","AODH_04_1_1.png","AODH_05_1_1.png","AODH_06_1_1.png","AODH_07_1_1.png","AODH_08_1_1.png","AODH_09_1_1.png"],
              hour_zero: 1,
              hour_space: -4,
              hour_angle: 0,
              hour_align: hmUI.align.LEFT,

              minute_startX: 414,
              minute_startY: 224,
              minute_array: ["AODH_00_1_1.png","AODH_01_1_1.png","AODH_02_1_1.png","AODH_03_1_1.png","AODH_04_1_1.png","AODH_05_1_1.png","AODH_06_1_1.png","AODH_07_1_1.png","AODH_08_1_1.png","AODH_09_1_1.png"],
              minute_zero: 1,
              minute_space: -4,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 405,
              y: 230,
              src: 'AODRAZ_1_1_1.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}