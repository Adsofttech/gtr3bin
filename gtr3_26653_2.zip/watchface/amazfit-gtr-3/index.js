try {
    (() => {
        var e = __$$hmAppManager$$__.currentApp;
    //-----01此处添加下列代码 代码块 开始位置 ------

    let secondPic = null;
    let now = null;
    let timer_sec_anim = null;
    let lastTime = 0;
    let animDuration = 1000;
    var secAnim = {
      "anim_rate": 'linear',
      "anim_duration": animDuration,
      "anim_from": 0,
      "anim_to": 360,
      "repeat_count": 1,
      "anim_fps": 25,
      "anim_key": "angle",
      "anim_status": 1,
    }
    function easeInAnim(){
            secondPic.setProperty(hmUI.prop.ANIM, {
                    "anim_rate": "easein",
                    "anim_duration": 200,
      "anim_from": 0,
                    "anim_to": 255,
                    "anim_fps": 30,
                    "anim_key": "alpha",
                });
    }
    /**
     * 在合适的层级调用此方法即可
     */
    function setSec() {
      if (now == null) {
        now = hmSensor.createSensor(hmSensor.id.TIME);
    }
      var screenType = hmSetting.getScreenType();
      if (screenType == hmSetting.screen_type.AOD) {
        stopSecAnim();
      } else {
        secondPic = hmUI.createWidget(hmUI.widget.IMG, {
          x: 0,
          y: 0,
			
	  /*更该02记录的数值*/
			
          w: 454,/*屏幕宽度  3p 480*/
          h: 454,/*屏幕宽度  3p 480*/
          pos_x: 454 / 2 - 30,/*旋转中心   替换-后面数值 02记录的数值*/
          pos_y: 454 / 2 - 227,/*旋转中心  替换-后面数值 02记录的数值*/
          center_x: 227, /*表盘旋转中心 3p 240*/
          center_y: 227,/*表盘旋转中心 3p 240*/
          src: '55.png',/*秒针图片 .png*/
          angle: 0,
          show_level: hmUI.show_level.ONLY_NORMAL,
        })
    }
     
      var vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
        resume_call: (function () {//划入表盘

          console.log('ui resume');
          if (timer_sec_anim != null && timer_sec_anim != 0) return;
          easeInAnim();
          easeInAnim();
          let duration = now.utc - lastTime;
          if (duration < animDuration) {
            duration = animDuration - duration;
      } else {
            duration = 0;
    }
          timer_sec_anim = timer.createTimer(duration, animDuration, (function (option) {
            lastTime = now.utc;
            startSecAnim();
          }));
        }),
        pause_call: (function () {
          console.log('ui pause');
        stopSecAnim();
        }),
                });
    }

    function startSecAnim() {
      let sec = now.second * 6;
      secAnim["anim_from"] = sec;
      secAnim["anim_to"] = sec + animDuration * 6 / 1000;

      secondPic.setProperty(hmUI.prop.ANIM, secAnim);
    }

    /**
     * onDestroy()中要调用一下这个方法
     */
    function stopSecAnim() {
      timer.stopTimer(timer_sec_anim);
      timer_sec_anim = 0;
    }

//-----01此处添加下列代码结束 代码块 结束位置------        
		const t = e.current,
            {
                px: n
            } = (new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(e, t)), e.app.__globals__);
        let g = "",
            r = "",
            _ = "",
            p = "";
        const o = Logger.getLogger("watchface6");
        t.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "2.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
                    x: 166,
                    y: 49,
                    image_array: ["3.png", "4.png", "5.png", "6.png", "7.png", "8.png", "9.png", "10.png", "11.png", "12.png", "13.png", "14.png", "15.png", "16.png", "17.png", "18.png", "19.png", "20.png", "21.png", "22.png", "23.png", "24.png", "25.png", "26.png", "27.png", "28.png", "29.png", "30.png", "31.png", "32.png"],
                    image_length: 30,
                    type: hmUI.data_type.MOON,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    src: "33.png",
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), g = hmUI.createWidget(hmUI.widget.TEXT, {
                    x: 187,
                    y: 118,
                    w: 80,
                    h: 30,
                    text: "[MON_Z]月[DAY_Z]",
                    color: "0xFFffffff",
                    text_size: 19,
                    text_style: hmUI.text_style.NONE,
                    align_h: hmUI.align.CENTER_H,
                    align_v: hmUI.align.CENTER_V,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.IMG_WEEK, {
                    x: 148,
                    y: 270,
                    week_sc: ["34.png", "35.png", "36.png", "37.png", "38.png", "39.png", "40.png"],
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 320,
                    y: 240,
                    type: hmUI.data_type.STEP,
                    font_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "51.png",
                    center_x: 345,
                    center_y: 227,
                    x: 14,
                    y: 75,
                    type: hmUI.data_type.STEP,
                    start_angle: -180,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                    x: 90,
                    y: 240,
                    type: hmUI.data_type.BATTERY,
                    font_array: ["41.png", "42.png", "43.png", "44.png", "45.png", "46.png", "47.png", "48.png", "49.png", "50.png"],
                    align_h: hmUI.align.CENTER_H,
                    h_space: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL,
                    padding: !1,
                    isCharacter: !1
                }), hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                    src: "52.png",
                    center_x: 107,
                    center_y: 227,
                    x: 14,
                    y: 75,
                    type: hmUI.data_type.BATTERY,
                    start_angle: -180,
                    end_angle: 120,
                    cover_x: 0,
                    cover_y: 0,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 30,
                    hour_posY: 227,
                    hour_path: "53.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 30,
                    minute_posY: 227,
                    minute_path: "54.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    second_centerX: 227,
                    second_centerY: 227,
                    second_posX: 1001,
                    second_posY: 1001,
                    second_path: "55.png",
                    second_cover_x: 0,
                    second_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_NORMAL
                }), 
				    setSec()
				hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,
                    h: 454,
                    src: "56.png",
                    show_level: hmUI.show_level.ONLY_AOD
                }), hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                    hour_centerX: 227,
                    hour_centerY: 227,
                    hour_posX: 32,
                    hour_posY: 227,
                    hour_path: "57.png",
                    hour_cover_x: 0,
                    hour_cover_y: 0,
                    minute_centerX: 227,
                    minute_centerY: 227,
                    minute_posX: 32,
                    minute_posY: 227,
                    minute_path: "58.png",
                    minute_cover_x: 0,
                    minute_cover_y: 0,
                    enable: !1,
                    show_level: hmUI.show_level.ONLY_AOD
                }), p || (p = hmSensor.createSensor(hmSensor.id.TIME)), p.addEventListener(p.event.DAYCHANGE, (function () {
                    r = hmSetting.getDateFormat(), _ = [() => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(p.month).padStart(2,"0")}月${String(p.day).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(p.day).padStart(2,"0")}月${String(p.month).padStart(2,"0")}`
                        })
                    }, () => {
                        g.setProperty(hmUI.prop.MORE, {
                            text: `${String(p.month).padStart(2,"0")}月${String(p.day).padStart(2,"0")}`
                        })
                    }], _[r]()
                })), hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: function () {
                        r = hmSetting.getDateFormat(), _ = [() => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(p.month).padStart(2,"0")}月${String(p.day).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(p.day).padStart(2,"0")}月${String(p.month).padStart(2,"0")}`
                            })
                        }, () => {
                            g.setProperty(hmUI.prop.MORE, {
                                text: `${String(p.month).padStart(2,"0")}月${String(p.day).padStart(2,"0")}`
                            })
                        }], _[r]()
                    }
                })
            }, onInit() {
                o.log("index page.js on init invoke")
            }, build() {
                this.init_view(), o.log("index page.js on ready invoke")
            }, onDestory() {
                o.log("index page.js on destory invoke")
            stopSecAnim()
			}
        })
    })()
} catch (e) {
    console.log(e)
}