﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        const logger = Logger.getLogger('watchface_SashaCX75');
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_pai_icon_img = ''
        let normal_image_img = ''
        let normal_system_disconnect_img = ''
        let normal_system_clock_img = ''
        let normal_sun_icon_img = ''
        let normal_sun_current_text_img = ''
        let normal_date_img_date_day = ''
        let normal_date_day_separator_img = ''
        let normal_battery_pointer_progress_img_pointer = ''
        let normal_battery_text_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_month_pointer_progress_date_pointer = ''
        let normal_calorie_current_text_img = ''
        let normal_distance_text_text_img = ''
        let normal_step_current_text_img = ''
        let normal_heart_rate_text_text_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_pai_icon_img = ''
        let idle_image_img = ''
        let idle_system_disconnect_img = ''
        let idle_sun_icon_img = ''
        let idle_sun_current_text_img = ''
        let idle_date_img_date_day = ''
        let idle_battery_pointer_progress_img_pointer = ''
        let idle_battery_text_text_img = ''
        let idle_date_img_date_week_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_calorie_current_text_img = ''
        let idle_distance_text_text_img = ''
        let idle_step_current_text_img = ''
        let idle_heart_rate_text_text_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let idle_date_img_date_month = ''
        let idle_date_month_separator_img = ''
        //let normal_temperature_jumpable_img_click = ''
        //let normal_stress_jumpable_img_click = ''
        //let normal_pai_jumpable_img_click = ''

        const curTime = hmSensor.createSensor(hmSensor.id.TIME);
                //------------------------ автозамена иконок погоды -----------------------------------
                
                let weather_icons = ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_1n.png","w_3n.png"]
                
                let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
                let weatherData = weather.getForecastWeather();
                let forecastData = weatherData.forecastData;
                let sunData = weatherData.tideData;
                let today = '';
                let sunriseMins = '';
                let sunsetMins = '';
                let sunriseMins_def = 8 * 60;			// время восхода
                let sunsetMins_def = 20 * 60;			// и заката по умолчанию
                
                let curMins = '';
                
                let isDayIcons = true;
                let wiReplacement = [0, 1, 2, 3, 14];		// индексы иконок для замены день-ночь
                
                function autoToggleWeatherIcons() {
                
                weatherData = weather.getForecastWeather();
                sunData = weatherData.tideData;
                if (sunData.count > 0){
                today = sunData.data[0];
                sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
                sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
                } else {
                sunriseMins = sunriseMins_def;
                sunsetMins = sunsetMins_def;
                }
                
                curMins = curTime.hour * 60 + curTime.minute;
                let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);
                
                if(isDayNow){
                if(!isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + ".png";
                  }
                  isDayIcons = true;
                }
                } else {
                if(isDayIcons){
                  for (let i = 0; i < wiReplacement.length; i++) {
                    weather_icons[wiReplacement[i]] = "w_" + wiReplacement[i].toString() + "n.png";
                  }
                  isDayIcons = false;
                }
                }
                }
                
                //------------------------ автозамена иконок погоды ----------------------------------- \\		

       // смена безеля
       //let bezel_img = ''
       let btn_bezel = ''
       let bezel_num = 1
       let bezel_all = 9
    
       function click_Bezel() {
           if(bezel_num>=bezel_all) {bezel_num=1;}
           else { bezel_num=bezel_num+1;}
           hmUI.showToast({text: "<Безель> " + parseInt(bezel_num) });
           normal_background_bg_img.setProperty(hmUI.prop.SRC, "bezel_" + parseInt(bezel_num) + ".png");
       }    

       let longPress_Timer = null;
       let longPressDelay = 850;
       //let btn_cal = ''
       
       function showAppScreen1(){
        //vibro();
        hmApp.startApp({ url: 'LowBatteryScreen', native: true });
       }

        // смена маски
        //let bot_circle_btn = ''
        //let mask_img = ''
        let btn_mask = ''
        let mask_num = 1
        let mask_all = 10
            
       function click_mask() {
         if(mask_num>=mask_all) {mask_num=1;}
          else { mask_num=mask_num+1;}
           hmUI.showToast({text: "<Маска> " + parseInt(mask_num) });
           normal_image_img.setProperty(hmUI.prop.SRC, "point_" + parseInt(mask_num) + ".png");
       }

       let everyHourVibro = true		// включен/отключен часовой сигнал
       let checkBT = true				// включен/отключен контроль потери связи
       
       let switch_checkBT;
       let switch_hourlyVibro;
       
       //const curTime = hmSensor.createSensor(hmSensor.id.TIME);
           const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
           let stopVibro_Timer = null;
       
       function vibro(scene = 25) {
         let stopDelay = 50;
         vibrate.stop();
         vibrate.scene = scene;
         if(scene < 23 || scene > 25) stopDelay = 1220;
         vibrate.start();
         stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
           }		
   
       function stopVibro(){
         vibrate.stop();
         timer.stopTimer(stopVibro_Timer);
       }
   
       
   //--------------------- контроль потери связи  ---------------------
       function checkConnection(check = true) {
         hmBle.removeListener;
         if (check){
           hmBle.addListener(function (status) {
             if(!status && checkBT) {
               hmUI.showToast({text: "Нет связи!!!"});
               vibro(9);
             }
             if(status && checkBT) {
               hmUI.showToast({text: "Снова на связи!"});
               vibro(0);
             }
           })			
         } 
       }
   
   //----------------- контроль потери связи: включение/отключение  ------------------
       function toggleСheckConnection() {
         checkBT = !checkBT;
         hmFS.SysProSetBool('nsw_checkBT', checkBT);
         vibro();
         checkConnection(checkBT);
         switch_checkBT.setProperty(hmUI.prop.SRC, checkBT ? 'slider1_on.png' : 'slider1_off.png');
         hmUI.showToast({text: "Контроль потери связи " + (checkBT ? "включен" : "отключен")});
           }
   
   //--------------------- вибрация каждый час  ---------------------
       function setEveryHourVibro() {
         curTime.addEventListener(curTime.event.MINUTEEND, function () {
             if (everyHourVibro && !(curTime.minute % 60)) {
               vibro(27);
               hmUI.showToast({text: "Новый час!!!"});
             }
         });
           }
   
   //----------------- вибрация каждый час: включение/отключение  ------------------
       function toggleEveryHourVibro() {
         everyHourVibro = !everyHourVibro;
         vibro();
         hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         switch_hourlyVibro.setProperty(hmUI.prop.SRC, everyHourVibro ? 'slider_on.png' : 'slider_off.png'); 
         hmUI.showToast({text: "Ежечасная вибрация " + (everyHourVibro ? "включена" : "отключена")});
           }
   
   
   
       function loadSettings() {		// получаем сохраненные значения переключателей из системных переменных
         
         if (hmFS.SysProGetBool('nsw_checkBT') === undefined) {
           checkBT = false;
           hmFS.SysProSetBool('nsw_checkBT', checkBT);
         } else {
           checkBT = hmFS.SysProGetBool('nsw_checkBT');
         }
         
         if (hmFS.SysProGetBool('nsw_hourlyVibro') === undefined) {
           everyHourVibro = false;
           hmFS.SysProSetBool('nsw_hourlyVibro', everyHourVibro);
         } else {
           everyHourVibro = hmFS.SysProGetBool('nsw_hourlyVibro');
         }
     
       }

        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'bezel_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'point_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 376,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 328,
              y: 339,
              src: '0076.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 236,
              src: 'vs_2.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 236,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'wnum_11.png',
              dot_image: 'wnum_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 210,
              day_startY: 47,
              day_sc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_tc_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_en_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              day_zero: 0,
              day_space: 0,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_day_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 153,
              y: 61,
              src: 'date_p_1.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 104,
              center_y: 227,
              x: 57,
              y: 57,
              start_angle: -142,
              end_angle: 138,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 252,
              font_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 286,
              week_en: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_tc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              week_sc: ["dn_1.png","dn_2.png","dn_3.png","dn_4.png","dn_5.png","dn_6.png","dn_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 358,
              y: 233,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 183,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'wnum_12.png',
              unit_tc: 'wnum_12.png',
              unit_en: 'wnum_12.png',
              negative_image: 'wnum_11.png',
              invalid_image: 'wnum_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            autoToggleWeatherIcons();

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 176,
              image_array: weather_icons,
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_month_pointer_progress_date_pointer = hmUI.createWidget(hmUI.widget.DATE_POINTER, {
              src: 'mes_p_1.png',
              center_x: 227,
              center_y: 227,
              posX: 10,
              posY: 227,
              start_angle: -15,
              end_angle: 345,
              type: hmUI.date.MONTH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 83,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 121,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'km_1.png',
              unit_tc: 'km_1.png',
              unit_en: 'km_1.png',
              dot_image: 'num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 121,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 83,
              font_array: ["num_1.png","num_2.png","num_3.png","num_4.png","num_5.png","num_6.png","num_7.png","num_8.png","num_9.png","num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 134,
              hour_startY: 316,
              hour_array: ["dtnum_1.png","dtnum_2.png","dtnum_3.png","dtnum_4.png","dtnum_5.png","dtnum_6.png","dtnum_7.png","dtnum_8.png","dtnum_9.png","dtnum_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'dtnum_11.png',
              hour_unit_tc: 'dtnum_11.png',
              hour_unit_en: 'dtnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["dtnum_1.png","dtnum_2.png","dtnum_3.png","dtnum_4.png","dtnum_5.png","dtnum_6.png","dtnum_7.png","dtnum_8.png","dtnum_9.png","dtnum_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_unit_sc: 'dtnum_11.png',
              minute_unit_tc: 'dtnum_11.png',
              minute_unit_en: 'dtnum_11.png',
              minute_align: hmUI.align.CENTER_H,

              second_startX: 0,
              second_startY: 0,
              second_array: ["dtnum_1.png","dtnum_2.png","dtnum_3.png","dtnum_4.png","dtnum_5.png","dtnum_6.png","dtnum_7.png","dtnum_8.png","dtnum_9.png","dtnum_10.png"],
              second_zero: 1,
              second_space: 0,
              second_angle: 0,
              second_follow: 1,
              second_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 30,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 30,
              minute_posY: 227,
              minute_cover_path: 'sec_p_1.png',
              minute_cover_x: 212,
              minute_cover_y: 212,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'sec_1.png',
              second_centerX: 227,
              second_centerY: 227,
              second_posX: 26,
              second_posY: 227,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            btn_bezel = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 61,
              y: 180,
              text: '',
              w: 95,
              h: 95,
              normal_src: '',
              press_src: '',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_bezel.setProperty(hmUI.prop.VISIBLE, true);

            btn_bezel.addEventListener(hmUI.event.CLICK_DOWN, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              longPress_Timer = timer.createTimer(longPressDelay, 0, showAppScreen1, {});
      
            });
            btn_bezel.addEventListener(hmUI.event.CLICK_UP, function () {
              if(longPress_Timer) timer.stopTimer(longPress_Timer);
              click_mask();
            });
      
            btn_mask = hmUI.createWidget(hmUI.widget.BUTTON, {
              x: 180,
              y: 180,
              text: '',
              w: 95,
              h: 95,
              normal_src: '',
              press_src: '',
              click_func: () => {
                  click_Bezel();
                  vibro(25);
              },
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            btn_mask.setProperty(hmUI.prop.VISIBLE, true);
 
      // кнопка включения/отключения ежечасного сигнала
      switch_hourlyVibro = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 91,
        w: 76,
        h: 76,
        src: everyHourVibro ? 'slider_on.png' : 'slider_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
          switch_hourlyVibro.addEventListener(hmUI.event.CLICK_UP, function () {
          toggleEveryHourVibro();
       });


      // кнопка включения/отключения котроля потери связи
      switch_checkBT = hmUI.createWidget(hmUI.widget.IMG, {
        x: 0,
        y: 288,
        w: 76,
        h: 76,
        src: checkBT ? 'slider1_on.png' : 'slider1_off.png',
        show_level: hmUI.show_level.ONLY_NORMAL,
      });
        switch_checkBT.addEventListener(hmUI.event.CLICK_UP, function () {
        toggleСheckConnection();
      });

            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 454,
              h: 454,
              src: 'aod_bezel.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_pai_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'mask_aod.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_image_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'point_9.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_system_disconnect_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 187,
              y: 376,
              src: 'btoff.png',
              type: hmUI.system_status.DISCONNECT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 333,
              y: 236,
              src: 'vs_2.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_sun_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 266,
              y: 236,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              invalid_image: 'wnum_11.png',
              dot_image: 'wnum_13.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 188,
              day_startY: 47,
              day_sc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_tc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_en_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              day_zero: 1,
              day_space: 0,
              day_unit_sc: 'aiod_num_11.png',
              day_unit_tc: 'aiod_num_11.png',
              day_unit_en: 'aiod_num_11.png',
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: 'pointer_1.png',
              center_x: 104,
              center_y: 227,
              x: 57,
              y: 57,
              start_angle: -142,
              end_angle: 138,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 91,
              y: 252,
              font_array: ["smnum_1.png","smnum_2.png","smnum_3.png","smnum_4.png","smnum_5.png","smnum_6.png","smnum_7.png","smnum_8.png","smnum_9.png","smnum_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 134,
              y: 286,
              week_en: ["aiod_dn_1.png","aiod_dn_2.png","aiod_dn_3.png","aiod_dn_4.png","aiod_dn_5.png","aiod_dn_6.png","aiod_dn_7.png"],
              week_tc: ["aiod_dn_1.png","aiod_dn_2.png","aiod_dn_3.png","aiod_dn_4.png","aiod_dn_5.png","aiod_dn_6.png","aiod_dn_7.png"],
              week_sc: ["aiod_dn_1.png","aiod_dn_2.png","aiod_dn_3.png","aiod_dn_4.png","aiod_dn_5.png","aiod_dn_6.png","aiod_dn_7.png"],
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 358,
              y: 233,
              image_array: ["m01.png","m02.png","m03.png","m04.png","m05.png","m06.png","m07.png","m08.png","m09.png","m10.png","m11.png","m12.png","m13.png","m14.png","m15.png","m16.png","m17.png","m18.png","m19.png","m20.png","m21.png","m22.png","m23.png","m24.png","m25.png","m26.png","m27.png","m28.png","m29.png","m30.png"],
              image_length: 30,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 295,
              y: 183,
              font_array: ["wnum_1.png","wnum_2.png","wnum_3.png","wnum_4.png","wnum_5.png","wnum_6.png","wnum_7.png","wnum_8.png","wnum_9.png","wnum_10.png"],
              padding: false,
              h_space: 1,
              unit_sc: 'wnum_12.png',
              unit_tc: 'wnum_12.png',
              unit_en: 'wnum_12.png',
              negative_image: 'wnum_11.png',
              invalid_image: 'wnum_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 365,
              y: 176,
              image_array: ["w_0.png","w_1.png","w_2.png","w_3.png","w_4.png","w_5.png","w_6.png","w_7.png","w_8.png","w_9.png","w_10.png","w_11.png","w_12.png","w_13.png","w_14.png","w_15.png","w_16.png","w_17.png","w_18.png","w_19.png","w_20.png","w_21.png","w_22.png","w_23.png","w_24.png","w_25.png","w_0n.png","w_14n.png","w_1n.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 136,
              y: 83,
              font_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_distance_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 219,
              y: 121,
              font_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              padding: false,
              h_space: 0,
              unit_sc: 'aiod_km_1.png',
              unit_tc: 'aiod_km_1.png',
              unit_en: 'aiod_km_1.png',
              dot_image: 'aiod_num_11.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.DISTANCE,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 127,
              y: 121,
              font_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_heart_rate_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 253,
              y: 83,
              font_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.HEART,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 165,
              hour_startY: 316,
              hour_array: ["aiod_dtnum_1.png","aiod_dtnum_2.png","aiod_dtnum_3.png","aiod_dtnum_4.png","aiod_dtnum_5.png","aiod_dtnum_6.png","aiod_dtnum_7.png","aiod_dtnum_8.png","aiod_dtnum_9.png","aiod_dtnum_10.png"],
              hour_zero: 1,
              hour_space: 0,
              hour_angle: 0,
              hour_unit_sc: 'aiod_dtnum_11.png',
              hour_unit_tc: 'aiod_dtnum_11.png',
              hour_unit_en: 'aiod_dtnum_11.png',
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 0,
              minute_startY: 0,
              minute_array: ["aiod_dtnum_1.png","aiod_dtnum_2.png","aiod_dtnum_3.png","aiod_dtnum_4.png","aiod_dtnum_5.png","aiod_dtnum_6.png","aiod_dtnum_7.png","aiod_dtnum_8.png","aiod_dtnum_9.png","aiod_dtnum_10.png"],
              minute_zero: 1,
              minute_space: 0,
              minute_angle: 0,
              minute_follow: 1,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              hour_path: 'hour_1.png',
              hour_centerX: 227,
              hour_centerY: 227,
              hour_posX: 30,
              hour_posY: 227,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              minute_path: 'min_1.png',
              minute_centerX: 227,
              minute_centerY: 227,
              minute_posX: 30,
              minute_posY: 227,
              minute_cover_path: 'sec_p_1.png',
              minute_cover_x: 212,
              minute_cover_y: 212,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 233,
              month_startY: 47,
              month_sc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              month_tc_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              month_en_array: ["aiod_num_1.png","aiod_num_2.png","aiod_num_3.png","aiod_num_4.png","aiod_num_5.png","aiod_num_6.png","aiod_num_7.png","aiod_num_8.png","aiod_num_9.png","aiod_num_10.png"],
              month_zero: 1,
              month_space: 0,
              month_align: hmUI.align.CENTER_H,
              month_is_character: false,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_month_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              src: 'A100_066.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });


            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                //scale_call();
                stopVibro();
                checkConnection(checkBT);
                autoToggleWeatherIcons();

              }),
              pause_call: (function () {
                stopVibro();

              }),

            });
            setEveryHourVibro();



                //dynamic modify end
            },
            onInit() {
              loadSettings();

                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}