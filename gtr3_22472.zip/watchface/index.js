try {
    (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;

        var __$$module$$__ = __$$app$$__.current;
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        /*
    * huamiOS bundle tool v1.0.17
    * Copyright © Huami. All Rights Reserved
    */
        'use strict';

        console.log("----->>>current")
        console.log(__$$hmAppManager$$__.currentApp.pid)
        console.log(__$$hmAppManager$$__.currentApp.current)
        const ASCII_START = 65; //A
        const rootPath = "images/";
        let worldCount = 0

        let img_bg = null

        let world_clock = null;
        let timePointer = null;
        let worldPointer = null;
        let timeSec = null;
        let timeZone = null;
        let timeHourImg = null;
        let gmtImg = null;
        let dataArr = null;
        const cityArrayImg = new Array(3);
        const ASSIC_MAX_COUNT = 26;
        const ASCIIARRAY = new Array(ASSIC_MAX_COUNT);

        function setJsWidgetVisible(widget,visible){
            if(widget != null){
                widget.setProperty(hmUI.prop.VISIBLE, visible);
            }
        }
        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            
            showTimeZone(timeZoneHour) {
                var path = rootPath + "img/jian.png";
                if (timeZoneHour > 0) {
                    path = rootPath + "img/jia.png";
                } 
                var path2 = rootPath + "hour/" + Math.abs(timeZoneHour) + ".png";
                timeZone.setProperty(hmUI.prop.SRC, path);
                timeHourImg.setProperty(hmUI.prop.SRC, path2);
            },
            showCity(cityCode) {
                let index = 0;
                let maxWidth = 0;
                let path = 0;
                let sizeArray = new Array(3);
                if(cityCode=='undefined')
                {
                    cityCode="AAA";
                }
                for (let char of cityCode) {
                    const charCode = char.charCodeAt();
                    if (charCode < ASCII_START) {
                        continue;
                    }
                    if (index >= 3) {
                        break;
                    }
                    path = ASCIIARRAY[charCode - ASCII_START];
                    const imageInfo = hmUI.getImageInfo(path);
                    sizeArray[index] = imageInfo.width;
                    maxWidth += imageInfo.width;
                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);
                }
                const bMWidth = 132;
                const baseX = 174;
                let startX = baseX + (bMWidth - maxWidth) / 2;
                for (var i = 0; i < 3; i++) {
                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                    startX += sizeArray[i];
                }

            },
            setWorldAngle(hour,min) {
                var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
            
                worldPointer.setProperty(hmUI.prop.ANGLE, angle);

            },

            init_view() {
                let assicIndex = 0;
                for (var i = ASCII_START; i < ASCII_START + 26; i++) {
                    const path = rootPath + "cityCode/" + String.fromCharCode(i) + ".png";
                    ASCIIARRAY[assicIndex++] = path;
                 
                }
                dataArr = [
                    rootPath + "data/0.png",
                    rootPath + "data/1.png",
                    rootPath + "data/2.png",
                    rootPath + "data/3.png",
                    rootPath + "data/4.png",
                    rootPath + "data/5.png",
                    rootPath + "data/6.png",
                    rootPath + "data/7.png",
                    rootPath + "data/8.png",
                    rootPath + "data/9.png",
                ]

                
                var screenType = hmSetting.getScreenType();

                world_clock = hmSensor.createSensor(hmSensor.id.WORLD_CLOCK);
                if (screenType == hmSetting.screen_type.AOD) {
                    img_bg = hmUI.createWidget(hmUI.widget.FILL_RECT, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        color: 0x000000,
                        show_level: hmUI.show_level.ONAL_AOD,
                    })
                } else {
                    img_bg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 0,
                        y: 0,
                        w: 454,
                        h: 454,
                        src: rootPath + "img/bg.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                }   

                     gmtImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 174,
                        y: 348,
                        w: 58,
                        h: 33,
                        src: rootPath + "img/GMT.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });

                    let calPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        center_x: 107,
                        center_y: 227,
                        x: 9,
                        y: 64,
                        start_angle: 0,
                        end_angle: 360,
                        type: hmUI.data_type.CAL,
                        src: rootPath + "img/pointer.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let calTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 71,
                        y: 245,
                        type: hmUI.data_type.CAL,
                        font_array: dataArr,
                        h_space: -2, //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        //invalid_image:"none.png",// 无数据时显示的图片
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let stepPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        center_x: 227,
                        center_y: 105,
                        x: 9,
                        y: 64,
                        start_angle: 0,
                        end_angle: 360,
                        type: hmUI.data_type.STEP,
                        src: rootPath + "img/pointer.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let stepTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 183,
                        y: 118,
                        type: hmUI.data_type.STEP,
                        font_array: dataArr,
                        h_space: -3, //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    let paiPointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
                        center_x: 346,
                        center_y: 227,
                        x: 9,
                        y: 64,
                        start_angle: 0,
                        end_angle: 360,
                        type: hmUI.data_type.PAI_DAILY,
                        src: rootPath + "img/pointer.png",
                        show_level: hmUI.show_level.ONLY_NORMAL,
                        
                    });
                    let paiTxt = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
                        x: 320,
                        y: 245,
                        type: hmUI.data_type.PAI_DAILY,
                        font_array: dataArr,
                        h_space: 0, //图片间隔
                        align_h: hmUI.align.CENTER_H,
                        padding: false, //是否补零 true为补零
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
  
                    //world  clock=-----------------
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i] = hmUI.createWidget(hmUI.widget.IMG, {
                            x: 196,
                            y: 300,
                            // w: 11,
                            // h: 28,
                            show_level: hmUI.show_level.ONLY_NORMAL,
                        });
                    }
                    timeZone = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 231,
                        y: 348,
                        w: 18,
                        h: 32,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                    timeHourImg = hmUI.createWidget(hmUI.widget.IMG, {
                        x: 250,
                        y: 347,
                        w: 27,
                        h: 33,
                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                var noData = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 231,
                    y: 348,
                    w: 26,
                    h: 26,  
                    src: rootPath + "img/nodata.png",
                    show_level: hmUI.show_level.ONLY_NORMAL,
                })
                noData.addEventListener(hmUI.event.CLICK_UP, (function (info) {    

                    hmApp.startApp({url:"WorldClockScreen",native:true});
                }));
               
                 worldPointer = hmUI.createWidget(hmUI.widget.IMG, {
                    x: 0,
                    y: 0,
                    w: 454,//display screen width
                    h: 454,//display screen height
                    pos_x: 227 - 13,
                    pos_y: 227 - 215,
                    center_x: 227,
                    center_y: 227,
                    angle: 0,
                    src: rootPath + "img/worldPointer.png",
                }); 
                   
               
                world_clock.init();
                worldCount = world_clock.getWorldClockCount();
               
                if (worldCount >0) {
                    noData.setProperty(hmUI.prop.VISIBLE, false);
                    setJsWidgetVisible(worldPointer,true);
                    setJsWidgetVisible(timeZone,true);
                    setJsWidgetVisible(timeHourImg,true);
                    setJsWidgetVisible(gmtImg,true);
                    let worldData = world_clock.getWorldClockInfo(0); 
                    if (screenType != hmSetting.screen_type.AOD) {
                        this.showCity(worldData.cityCode);
                        //this.showCity("AKL");
                        this.showTimeZone(worldData.timeZoneHour);
                    }
                    this.setWorldAngle(worldData.hour,worldData.minute);
                } else {
                    for (var i = 0; i < 3; i++) {
                        cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                    }
                    worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                    timeZone.setProperty(hmUI.prop.VISIBLE,false);
                    timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                    gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                    noData.setProperty(hmUI.prop.VISIBLE, true);
                }
                world_clock.uninit();
                if (screenType == hmSetting.screen_type.AOD) {
                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {


                        hour_centerX: 227,
                        hour_centerY: 227,
                        hour_posX: 19,
                        hour_posY: 162,
                        hour_path: rootPath + "img/hour.png",
    
                        minute_centerX: 227,
                        minute_centerY: 227,
                        minute_posX: 19,
                        minute_posY: 208,
                        minute_path: rootPath + "img/min.png",
    
                        show_level: hmUI.show_level.ONAL_AOD,
                    });

                } else {
                    timePointer = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
                        hour_centerX: 227,
                        hour_centerY: 227,
                        hour_posX: 19,
                        hour_posY: 162,
                        hour_path: rootPath + "img/hour.png",
    
                        minute_centerX: 227,
                        minute_centerY: 227,
                        minute_posX: 19,
                        minute_posY: 208,
                        minute_path: rootPath + "img/min.png",
  
                        second_centerX: 227,
                        second_centerY: 227,
                        second_posX: 14,
                        second_posY: 209,
                        second_path: rootPath + "img/sec.png",

                        show_level: hmUI.show_level.ONLY_NORMAL,
                    });
                };
                const vDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
                    resume_call: (function () { 
                        world_clock.init();
                        worldCount = world_clock.getWorldClockCount();
                        if (worldCount > 0) {
                            noData.setProperty(hmUI.prop.VISIBLE, false);
                            worldPointer.setProperty(hmUI.prop.VISIBLE, true);
                            timeZone.setProperty(hmUI.prop.VISIBLE,true);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,true);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,true);
                            let worldData = world_clock.getWorldClockInfo(0);
                            var hour = worldData.hour;
                            var min =  worldData.minute;
                            var angle = 15 * hour + min * 0.25;  //min= 360/24/60=0.25; hour= 360/24=15;
                           
                            worldPointer.setProperty(hmUI.prop.ANGLE, angle);
                            if (!(screenType == hmSetting.screen_type.AOD)) {
                                let index = 0;
                                let maxWidth = 0;
                                let path = 0;
                                let sizeArray = new Array(3);
                
                                for (let char of worldData.cityCode) {
                                    const charCode = char.charCodeAt();
                                    if (charCode < ASCII_START) {
                                        continue;
                                    }
                                    if (index >= 3) {
                                        break;
                                    }
                                    path = ASCIIARRAY[charCode - ASCII_START];
                                    const imageInfo = hmUI.getImageInfo(path);
                                    sizeArray[index] = imageInfo.width;
                                    maxWidth += imageInfo.width;
                                    cityArrayImg[index].setProperty(hmUI.prop.VISIBLE,true);
                                    cityArrayImg[index++].setProperty(hmUI.prop.SRC, ASCIIARRAY[charCode - ASCII_START]);

                                }
                                const bMWidth = 132;
                                const baseX = 164;
                                let startX = baseX + (bMWidth - maxWidth) / 2;
                                for (var i = 0; i < 3; i++) {
                                    cityArrayImg[i].setProperty(hmUI.prop.X, startX);
                                    startX += sizeArray[i];
                                }
                                // this.showTimeZone(worldData.timeZoneHour);
                                path = rootPath + "img/jian.png";
                                if (worldData.timeZoneHour > 0) {
                                    path = rootPath + "img/jia.png";
                                } 
                                var path2 = rootPath + "hour/" + Math.abs(worldData.timeZoneHour) + ".png";
                                timeZone.setProperty(hmUI.prop.SRC, path);
                                timeHourImg.setProperty(hmUI.prop.SRC, path2);
                            }
                        }else{
                            for (var i = 0; i < 3; i++) {
                                cityArrayImg[i].setProperty(hmUI.prop.VISIBLE, false);
                            }
                            worldPointer.setProperty(hmUI.prop.VISIBLE, false);
                            timeZone.setProperty(hmUI.prop.VISIBLE,false);
                            timeHourImg.setProperty(hmUI.prop.VISIBLE,false);
                            gmtImg.setProperty(hmUI.prop.VISIBLE,false);
                            noData.setProperty(hmUI.prop.VISIBLE, true);
                        }
                        world_clock.uninit();
                    }),
                    pause_call: (function () {
                        console.log('ui pause');
                    }),

                });
            },

            onInit() {
                console.log('index page.js on init invoke')

                this.init_view();



            },

            onReady() {
                console.log('index page.js on ready invoke')
            },

            onShow() {
                console.log('index page.js on show invoke')
            },

            onHide() {
                console.log('index page.js on hide invoke')
            },

            onDestory() {
                console.log('index page.js on destory invoke');
              
            },
        });
        /*
        * end js
        */
    })()
} catch (e) {
    console.log(e)
}
