﻿
    /*
    ** Watch_Face_Editor tool
    ** watchface js version v1.0.1
    ** Copyright © CashaCX75. All Rights Reserved
    */

    try {

      (() => {

        var __$$app$$__ = __$$hmAppManager$$__.currentApp;
        var __$$module$$__ = __$$app$$__.current;
        //drink is a name,can modify
        var h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__), 'drink');

        'use strict';

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_moon_image_progress_img_level = ''
        let normal_fat_burning_current_text_img = ''
        let normal_battery_circle_scale = ''
        let normal_battery_text_text_img = ''
        let normal_temperature_current_text_img = ''
        let normal_weather_image_progress_img_level = ''
        let normal_stand_current_text_img = ''
        let normal_calorie_current_text_img = ''
        let normal_calorie_circle_scale = ''
        let normal_step_pointer_progress_img_pointer = ''
        let normal_step_current_text_img = ''
        let normal_step_circle_scale = ''
        let normal_step_icon_img = ''
        let normal_digital_clock_img_time = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_background_bg_img = ''
        let idle_moon_image_progress_img_level = ''
        let idle_fat_burning_current_text_img = ''
        let idle_battery_circle_scale = ''
        let idle_battery_text_text_img = ''
        let idle_temperature_current_text_img = ''
        let idle_weather_image_progress_img_level = ''
        let idle_stand_current_text_img = ''
        let idle_calorie_current_text_img = ''
        let idle_calorie_circle_scale = ''
        let idle_step_pointer_progress_img_pointer = ''
        let idle_step_current_text_img = ''
        let idle_step_circle_scale = ''
        let idle_step_icon_img = ''
        let idle_digital_clock_img_time = ''
        let idle_analog_clock_time_pointer_second = ''


        //dynamic modify end

        //not required
        const logger = DeviceRuntimeCore.HmLogger.getLogger("yeguang");

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({

          init_view() {

            //dynamic modify start
                    
            
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '20220901_003133[1].png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 67,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png"],
              image_length: 10,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 408,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 418,
              // start_angle: 6,
              // end_angle: 354,
              // radius: 38,
              // line_width: 4,
              // color: 0xFF06D68C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            if (screenType != hmSetting.screen_type.AOD) {
              normal_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
            battery.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 401,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 336,
              font_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 279,
              image_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 408,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 340,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 351,
              // center_y: 357,
              // start_angle: 0,
              // end_angle: 180,
              // radius: 39,
              // line_width: 5,
              // color: 0xFFCC09A5,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);
            calorie.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0079.png',
              center_x: 240,
              center_y: 240,
              x: 220,
              y: 0,
              start_angle: -47,
              end_angle: -18,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 340,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 0,
              // center_y: 0,
              // start_angle: 0,
              // end_angle: 180,
              // radius: 100,
              // line_width: 5,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            
            if (screenType != hmSetting.screen_type.AOD) {
              normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 338,
              src: '37a.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 152,
              hour_array: ["a0000_(1).png","a0000_(2).png","a0000_(3).png","a0000_(4).png","a0000_(5).png","a0000_(6).png","a0000_(7).png","a0000_(8).png","a0000_(9).png","a0000_(91).png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 66,
              minute_startY: 241,
              minute_array: ["a0000_(1).png","a0000_(2).png","a0000_(3).png","a0000_(4).png","a0000_(5).png","a0000_(6).png","a0000_(7).png","a0000_(8).png","a0000_(9).png","a0000_(91).png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 185,
              second_startY: 225,
              second_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'moii_(38).png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 240,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: '20220901_003133[1].png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_moon_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 220,
              y: 67,
              image_array: ["moon_01.png","moon_02.png","moon_03.png","moon_04.png","moon_05.png","moon_06.png","moon_07.png","moon_08.png","moon_09.png","moon_10.png"],
              image_length: 10,
              type: hmUI.data_type.MOON,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_fat_burning_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 137,
              y: 408,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.FAT_BURNING,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 241,
              // center_y: 418,
              // start_angle: 6,
              // end_angle: 354,
              // radius: 38,
              // line_width: 4,
              // color: 0xFF06D68C,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.BATTERY,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_battery_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_battery_text_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 216,
              y: 401,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -1,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 223,
              y: 336,
              font_array: ["z0.png","z1.png","z2.png","z3.png","z4.png","z5.png","z6.png","z7.png","z8.png","z9.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_weather_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 216,
              y: 279,
              image_array: ["88.png","89.png","90.png","91.png","92.png","93.png","94.png","95.png","96.png","97.png","98.png","99.png","100.png","101.png","102.png","103.png","104.png","105.png","106.png","107.png","108.png","109.png","110.png","111.png","112.png","113.png","114.png","115.png","116.png"],
              image_length: 29,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_stand_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 278,
              y: 408,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: 0,
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.STAND,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_calorie_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 311,
              y: 340,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.RIGHT,
              type: hmUI.data_type.CAL,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_cal_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 351,
              // center_y: 357,
              // start_angle: 0,
              // end_angle: 180,
              // radius: 39,
              // line_width: 5,
              // color: 0xFFCC09A5,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.CAL,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_calorie_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_pointer_progress_img_pointer = hmUI.createWidget(hmUI.widget.IMG_POINTER, {
              src: '0079.png',
              center_x: 240,
              center_y: 240,
              x: 220,
              y: 0,
              start_angle: -47,
              end_angle: -18,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_step_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 104,
              y: 340,
              font_array: ["0031.png","0032.png","0033.png","0034.png","0035.png","0036.png","0037.png","0038.png","0039.png","0040.png"],
              padding: false,
              h_space: -3,
              align_h: hmUI.align.LEFT,
              type: hmUI.data_type.STEP,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            // idle_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 0,
              // center_y: 0,
              // start_angle: 0,
              // end_angle: 180,
              // radius: 100,
              // line_width: 5,
              // color: 0xFFFF8C00,
              // mirror: False,
              // inversion: False,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONAL_AOD,
            // });

            
            if (screenType == hmSetting.screen_type.AOD) {
              idle_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC);
            };

            idle_step_icon_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 70,
              y: 338,
              src: '37a.png',
              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 35,
              hour_startY: 152,
              hour_array: ["a0000_(1).png","a0000_(2).png","a0000_(3).png","a0000_(4).png","a0000_(5).png","a0000_(6).png","a0000_(7).png","a0000_(8).png","a0000_(9).png","a0000_(91).png"],
              hour_zero: 1,
              hour_space: 1,
              hour_align: hmUI.align.RIGHT,

              minute_startX: 66,
              minute_startY: 241,
              minute_array: ["a0000_(1).png","a0000_(2).png","a0000_(3).png","a0000_(4).png","a0000_(5).png","a0000_(6).png","a0000_(7).png","a0000_(8).png","a0000_(9).png","a0000_(91).png"],
              minute_zero: 1,
              minute_space: 1,
              minute_follow: 0,
              minute_align: hmUI.align.LEFT,

              second_startX: 185,
              second_startY: 225,
              second_array: ["small_0.png","small_1.png","small_2.png","small_3.png","small_4.png","small_5.png","small_6.png","small_7.png","small_8.png","small_9.png"],
              second_zero: 1,
              second_space: 0,
              second_follow: 0,
              second_align: hmUI.align.LEFT,

              show_level: hmUI.show_level.ONAL_AOD,
            });

            idle_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'moii_(38).png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 8,
              second_posY: 240,
              show_level: hmUI.show_level.ONAL_AOD,
            });

            function scale_call() {

                console.log('update scales BATTERY');
                
                let valueBattery = battery.current;
                let targetBattery = 100;
                let progressBattery = valueBattery/targetBattery;
                if (progressBattery > 1) progressBattery = 1;
                let progress_cs_normal_battery = progressBattery;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_battery_circle_scale
                  // initial parameters
                  let start_angle_normal_battery = -84;
                  let end_angle_normal_battery = 264;
                  let center_x_normal_battery = 241;
                  let center_y_normal_battery = 418;
                  let radius_normal_battery = 38;
                  let line_width_cs_normal_battery = 4;
                  let color_cs_normal_battery = 0xFF06D68C;
                  
                  // calculated parameters
                  let arcX_normal_battery = center_x_normal_battery - radius_normal_battery;
                  let arcY_normal_battery = center_y_normal_battery - radius_normal_battery;
                  let CircleWidth_normal_battery = 2 * radius_normal_battery;
                  let angle_offset_normal_battery = end_angle_normal_battery - start_angle_normal_battery;
                  angle_offset_normal_battery = angle_offset_normal_battery * progress_cs_normal_battery;
                  let end_angle_normal_battery_draw = start_angle_normal_battery + angle_offset_normal_battery;
                  
                  normal_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_battery,
                    y: arcY_normal_battery,
                    w: CircleWidth_normal_battery,
                    h: CircleWidth_normal_battery,
                    start_angle: start_angle_normal_battery,
                    end_angle: end_angle_normal_battery_draw,
                    color: color_cs_normal_battery,
                    line_width: line_width_cs_normal_battery,
                  });
                };

                console.log('update scales CALORIE');
                
                let valueCalories = calorie.current;
                let targetCalories = calorie.target;
                let progressCalories = valueCalories/targetCalories;
                if (progressCalories > 1) progressCalories = 1;
                let progress_cs_normal_calorie = progressCalories;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_calorie_circle_scale
                  // initial parameters
                  let start_angle_normal_calorie = -90;
                  let end_angle_normal_calorie = 90;
                  let center_x_normal_calorie = 351;
                  let center_y_normal_calorie = 357;
                  let radius_normal_calorie = 39;
                  let line_width_cs_normal_calorie = 5;
                  let color_cs_normal_calorie = 0xFFCC09A5;
                  
                  // calculated parameters
                  let arcX_normal_calorie = center_x_normal_calorie - radius_normal_calorie;
                  let arcY_normal_calorie = center_y_normal_calorie - radius_normal_calorie;
                  let CircleWidth_normal_calorie = 2 * radius_normal_calorie;
                  let angle_offset_normal_calorie = end_angle_normal_calorie - start_angle_normal_calorie;
                  angle_offset_normal_calorie = angle_offset_normal_calorie * progress_cs_normal_calorie;
                  let end_angle_normal_calorie_draw = start_angle_normal_calorie + angle_offset_normal_calorie;
                  
                  normal_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_calorie,
                    y: arcY_normal_calorie,
                    w: CircleWidth_normal_calorie,
                    h: CircleWidth_normal_calorie,
                    start_angle: start_angle_normal_calorie,
                    end_angle: end_angle_normal_calorie_draw,
                    color: color_cs_normal_calorie,
                    line_width: line_width_cs_normal_calorie,
                  });
                };

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale
                  // initial parameters
                  let start_angle_normal_step = -90;
                  let end_angle_normal_step = 90;
                  let center_x_normal_step = 0;
                  let center_y_normal_step = 0;
                  let radius_normal_step = 100;
                  let line_width_cs_normal_step = 5;
                  let color_cs_normal_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_normal_step = center_x_normal_step - radius_normal_step;
                  let arcY_normal_step = center_y_normal_step - radius_normal_step;
                  let CircleWidth_normal_step = 2 * radius_normal_step;
                  let angle_offset_normal_step = end_angle_normal_step - start_angle_normal_step;
                  angle_offset_normal_step = angle_offset_normal_step * progress_cs_normal_step;
                  let end_angle_normal_step_draw = start_angle_normal_step + angle_offset_normal_step;
                  
                  normal_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_normal_step,
                    y: arcY_normal_step,
                    w: CircleWidth_normal_step,
                    h: CircleWidth_normal_step,
                    start_angle: start_angle_normal_step,
                    end_angle: end_angle_normal_step_draw,
                    color: color_cs_normal_step,
                    line_width: line_width_cs_normal_step,
                  });
                };

                console.log('update scales BATTERY');
                let progress_cs_idle_battery = progressBattery;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_battery_circle_scale
                  // initial parameters
                  let start_angle_idle_battery = -84;
                  let end_angle_idle_battery = 264;
                  let center_x_idle_battery = 241;
                  let center_y_idle_battery = 418;
                  let radius_idle_battery = 38;
                  let line_width_cs_idle_battery = 4;
                  let color_cs_idle_battery = 0xFF06D68C;
                  
                  // calculated parameters
                  let arcX_idle_battery = center_x_idle_battery - radius_idle_battery;
                  let arcY_idle_battery = center_y_idle_battery - radius_idle_battery;
                  let CircleWidth_idle_battery = 2 * radius_idle_battery;
                  let angle_offset_idle_battery = end_angle_idle_battery - start_angle_idle_battery;
                  angle_offset_idle_battery = angle_offset_idle_battery * progress_cs_idle_battery;
                  let end_angle_idle_battery_draw = start_angle_idle_battery + angle_offset_idle_battery;
                  
                  idle_battery_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_battery,
                    y: arcY_idle_battery,
                    w: CircleWidth_idle_battery,
                    h: CircleWidth_idle_battery,
                    start_angle: start_angle_idle_battery,
                    end_angle: end_angle_idle_battery_draw,
                    color: color_cs_idle_battery,
                    line_width: line_width_cs_idle_battery,
                  });
                };

                console.log('update scales CALORIE');
                let progress_cs_idle_calorie = progressCalories;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_calorie_circle_scale
                  // initial parameters
                  let start_angle_idle_calorie = -90;
                  let end_angle_idle_calorie = 90;
                  let center_x_idle_calorie = 351;
                  let center_y_idle_calorie = 357;
                  let radius_idle_calorie = 39;
                  let line_width_cs_idle_calorie = 5;
                  let color_cs_idle_calorie = 0xFFCC09A5;
                  
                  // calculated parameters
                  let arcX_idle_calorie = center_x_idle_calorie - radius_idle_calorie;
                  let arcY_idle_calorie = center_y_idle_calorie - radius_idle_calorie;
                  let CircleWidth_idle_calorie = 2 * radius_idle_calorie;
                  let angle_offset_idle_calorie = end_angle_idle_calorie - start_angle_idle_calorie;
                  angle_offset_idle_calorie = angle_offset_idle_calorie * progress_cs_idle_calorie;
                  let end_angle_idle_calorie_draw = start_angle_idle_calorie + angle_offset_idle_calorie;
                  
                  idle_calorie_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_calorie,
                    y: arcY_idle_calorie,
                    w: CircleWidth_idle_calorie,
                    h: CircleWidth_idle_calorie,
                    start_angle: start_angle_idle_calorie,
                    end_angle: end_angle_idle_calorie_draw,
                    color: color_cs_idle_calorie,
                    line_width: line_width_cs_idle_calorie,
                  });
                };

                console.log('update scales STEP');
                let progress_cs_idle_step = progressStep;

                if (screenType == hmSetting.screen_type.AOD) {

                  // idle_step_circle_scale
                  // initial parameters
                  let start_angle_idle_step = -90;
                  let end_angle_idle_step = 90;
                  let center_x_idle_step = 0;
                  let center_y_idle_step = 0;
                  let radius_idle_step = 100;
                  let line_width_cs_idle_step = 5;
                  let color_cs_idle_step = 0xFFFF8C00;
                  
                  // calculated parameters
                  let arcX_idle_step = center_x_idle_step - radius_idle_step;
                  let arcY_idle_step = center_y_idle_step - radius_idle_step;
                  let CircleWidth_idle_step = 2 * radius_idle_step;
                  let angle_offset_idle_step = end_angle_idle_step - start_angle_idle_step;
                  angle_offset_idle_step = angle_offset_idle_step * progress_cs_idle_step;
                  let end_angle_idle_step_draw = start_angle_idle_step + angle_offset_idle_step;
                  
                  idle_step_circle_scale.setProperty(hmUI.prop.MORE, {
                    x: arcX_idle_step,
                    y: arcY_idle_step,
                    w: CircleWidth_idle_step,
                    h: CircleWidth_idle_step,
                    start_angle: start_angle_idle_step,
                    end_angle: end_angle_idle_step_draw,
                    color: color_cs_idle_step,
                    line_width: line_width_cs_idle_step,
                  });
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                scale_call();
              }),
            });

            //dynamic modify end
          },

          onInit() {
            console.log('index page.js on init invoke')

            this.init_view()

          },

          onReady() {
            console.log('index page.js on ready invoke')
          },

          onShow() {
            console.log('index page.js on show invoke')
          },

          onHide() {
            console.log('index page.js on hide invoke')
          },

          onDestory() {
            console.log('index page.js on destory invoke')
          },
        });

      })()
    } catch (e) {
      console.log(e)
    }
  